import { applyMove, detectOpeningName, INITIAL_FEN } from './chessRules';
import {
  INITIAL_SHASHKI_STATE_KEY,
  deserializeShashkiState,
  serializeShashkiState,
  applyInteractiveShashkiStep,
  type ShashkiChainState,
} from './shashkiRules';
import {
  TIME_CONTROLS,
  type GameOutcome,
  type GameVariant,
  type MoveRecord,
  type PieceColor,
  type PromotionPiece,
  type RoomPublicState,
  type SidePreference,
  type TimeControlKey,
} from './types';

interface InternalSeat {
  name: string;
  token: string;
  connected: boolean;
}

interface InternalRoom {
  roomCode: string;
  variant: GameVariant;
  status: 'waiting' | 'playing' | 'finished';
  fen: string;
  turn: PieceColor;
  moves: MoveRecord[];
  timeControl: TimeControlKey;
  clocks: { w: number; b: number };
  lastMoveAt: number | null;
  players: {
    w: InternalSeat | null;
    b: InternalSeat | null;
  };
  spectatorTokens: Set<string>;
  drawOfferFrom: PieceColor | null;
  rematchVotes: Set<PieceColor>;
  outcome: GameOutcome | null;
  openingName: string;
  shashkiChain: ShashkiChainState | null;
  createdAt: number;
  lastActivityAt: number;
}

export interface RoomActionResult {
  ok: boolean;
  room?: RoomPublicState;
  role?: PieceColor | 'spectator';
  rematchStarted?: boolean;
  error?: string;
}

function generateRoomCode(existing: Set<string>, rng: () => number = Math.random): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  for (let attempt = 0; attempt < 20; attempt++) {
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars[Math.floor(rng() * chars.length)];
    }
    if (!existing.has(code)) return code;
  }
  return `SH${Date.now().toString(36).toUpperCase().slice(-4)}`;
}

export class RoomManager {
  private rooms = new Map<string, InternalRoom>();
  private queue: Array<{
    playerName: string;
    playerToken: string;
    variant: GameVariant;
    timeControl: TimeControlKey;
  }> = [];

  private toPublicState(room: InternalRoom, now: number = Date.now()): RoomPublicState {
    const clocks = { ...room.clocks };
    if (
      room.status === 'playing' &&
      room.timeControl !== 'unlimited' &&
      room.lastMoveAt !== null &&
      room.moves.length > 0
    ) {
      const elapsed = Math.max(0, now - room.lastMoveAt);
      clocks[room.turn] = Math.max(0, clocks[room.turn] - elapsed);
    }

    return {
      roomCode: room.roomCode,
      variant: room.variant,
      status: room.status,
      fen: room.fen,
      turn: room.turn,
      moves: room.moves,
      timeControl: room.timeControl,
      clocks,
      lastMoveAt: room.lastMoveAt,
      players: {
        w: room.players.w
          ? { name: room.players.w.name, connected: room.players.w.connected }
          : null,
        b: room.players.b
          ? { name: room.players.b.name, connected: room.players.b.connected }
          : null,
      },
      spectatorCount: room.spectatorTokens.size,
      drawOfferFrom: room.drawOfferFrom,
      rematchVotes: Array.from(room.rematchVotes),
      outcome: room.outcome,
      openingName: room.openingName,
      shashkiChain: room.variant === 'shashki' ? room.shashkiChain : null,
    };
  }

  public getRoomCount(): number {
    return this.rooms.size;
  }

  public createRoom(params: {
    playerName: string;
    playerToken: string;
    variant?: GameVariant;
    timeControl: TimeControlKey;
    sidePreference: SidePreference;
    now?: number;
    rng?: () => number;
  }): { room: RoomPublicState; role: PieceColor } {
    const now = params.now ?? Date.now();
    const rng = params.rng ?? Math.random;
    const variant = params.variant ?? 'chess';
    const roomCode = generateRoomCode(new Set(this.rooms.keys()), rng);
    const tc = TIME_CONTROLS[params.timeControl] ?? TIME_CONTROLS['10+0'];
    const isShashki = variant === 'shashki';

    let role: PieceColor;
    if (params.sidePreference === 'w' || params.sidePreference === 'b') {
      role = params.sidePreference;
    } else {
      role = rng() < 0.5 ? 'w' : 'b';
    }

    const cleanName = params.playerName.trim().slice(0, 24) || 'Oyuncu 1';
    const room: InternalRoom = {
      roomCode,
      variant,
      status: 'waiting',
      fen: isShashki ? INITIAL_SHASHKI_STATE_KEY : INITIAL_FEN,
      turn: 'w',
      moves: [],
      timeControl: tc.key,
      clocks: { w: tc.initialMs, b: tc.initialMs },
      lastMoveAt: null,
      players: {
        w: role === 'w' ? { name: cleanName, token: params.playerToken, connected: true } : null,
        b: role === 'b' ? { name: cleanName, token: params.playerToken, connected: true } : null,
      },
      spectatorTokens: new Set(),
      drawOfferFrom: null,
      rematchVotes: new Set(),
      outcome: null,
      openingName: isShashki ? 'Klasik Şaşki (8×8)' : 'Başlangıç Konumu',
      shashkiChain: null,
      createdAt: now,
      lastActivityAt: now,
    };

    this.rooms.set(roomCode, room);
    return { room: this.toPublicState(room, now), role };
  }

  public joinRoom(params: {
    roomCode: string;
    playerName: string;
    playerToken: string;
    now?: number;
  }): RoomActionResult {
    const now = params.now ?? Date.now();
    const normalizedCode = params.roomCode.trim().toUpperCase();
    const room = this.rooms.get(normalizedCode);
    if (!room) {
      return { ok: false, error: 'Oda bulunamadı. Kodu kontrol edin.' };
    }
    if (!params.playerToken.trim()) {
      return { ok: false, error: 'Geçersiz oyuncu kimliği.' };
    }

    const cleanName = params.playerName.trim().slice(0, 24) || 'Oyuncu';
    room.lastActivityAt = now;

    if (room.players.w?.token === params.playerToken) {
      room.players.w.connected = true;
      room.players.w.name = cleanName || room.players.w.name;
      return { ok: true, room: this.toPublicState(room, now), role: 'w' };
    }
    if (room.players.b?.token === params.playerToken) {
      room.players.b.connected = true;
      room.players.b.name = cleanName || room.players.b.name;
      return { ok: true, room: this.toPublicState(room, now), role: 'b' };
    }

    if (!room.players.w) {
      room.players.w = { name: cleanName, token: params.playerToken, connected: true };
      if (room.players.b && room.status === 'waiting') {
        room.status = 'playing';
      }
      return { ok: true, room: this.toPublicState(room, now), role: 'w' };
    }
    if (!room.players.b) {
      room.players.b = { name: cleanName, token: params.playerToken, connected: true };
      if (room.players.w && room.status === 'waiting') {
        room.status = 'playing';
      }
      return { ok: true, room: this.toPublicState(room, now), role: 'b' };
    }

    room.spectatorTokens.add(params.playerToken);
    return { ok: true, room: this.toPublicState(room, now), role: 'spectator' };
  }

  public enqueueMatchmaking(params: {
    playerName: string;
    playerToken: string;
    variant?: GameVariant;
    timeControl: TimeControlKey;
    now?: number;
    rng?: () => number;
  }):
    | { matched: false; queuePosition: number }
    | {
        matched: true;
        room: RoomPublicState;
        whiteToken: string;
        blackToken: string;
      } {
    const cleanName = params.playerName.trim().slice(0, 24) || 'Oyuncu';
    const variant = params.variant ?? 'chess';
    this.queue = this.queue.filter((q) => q.playerToken !== params.playerToken);

    const opponentIdx = this.queue.findIndex(
      (q) => q.timeControl === params.timeControl && q.variant === variant,
    );
    if (opponentIdx === -1) {
      this.queue.push({
        playerName: cleanName,
        playerToken: params.playerToken,
        variant,
        timeControl: params.timeControl,
      });
      return { matched: false, queuePosition: this.queue.length };
    }

    const [opponent] = this.queue.splice(opponentIdx, 1);
    const rng = params.rng ?? Math.random;
    const now = params.now ?? Date.now();
    const opponentIsWhite = rng() < 0.5;

    const created = this.createRoom({
      playerName: opponent.playerName,
      playerToken: opponent.playerToken,
      variant,
      timeControl: params.timeControl,
      sidePreference: opponentIsWhite ? 'w' : 'b',
      now,
      rng,
    });

    const joined = this.joinRoom({
      roomCode: created.room.roomCode,
      playerName: cleanName,
      playerToken: params.playerToken,
      now,
    });

    const room = joined.room!;
    const whiteToken = opponentIsWhite ? opponent.playerToken : params.playerToken;
    const blackToken = opponentIsWhite ? params.playerToken : opponent.playerToken;

    return { matched: true, room, whiteToken, blackToken };
  }

  public cancelMatchmaking(playerToken: string): void {
    this.queue = this.queue.filter((q) => q.playerToken !== playerToken);
  }

  public getPlayerRole(roomCode: string, playerToken: string): PieceColor | 'spectator' | null {
    const room = this.rooms.get(roomCode.trim().toUpperCase());
    if (!room) return null;
    if (room.players.w?.token === playerToken) return 'w';
    if (room.players.b?.token === playerToken) return 'b';
    if (room.spectatorTokens.has(playerToken)) return 'spectator';
    return null;
  }

  public getRoomState(roomCode: string, now: number = Date.now()): RoomPublicState | null {
    const room = this.rooms.get(roomCode.trim().toUpperCase());
    return room ? this.toPublicState(room, now) : null;
  }

  public getRoomPlayerTokens(roomCode: string): { w: string | null; b: string | null } | null {
    const room = this.rooms.get(roomCode.trim().toUpperCase());
    if (!room) return null;
    return {
      w: room.players.w?.token ?? null,
      b: room.players.b?.token ?? null,
    };
  }

  public makeMove(params: {
    roomCode: string;
    playerToken: string;
    from: string;
    to: string;
    promotion?: PromotionPiece;
    now?: number;
  }): RoomActionResult {
    const now = params.now ?? Date.now();
    const room = this.rooms.get(params.roomCode.trim().toUpperCase());
    if (!room) return { ok: false, error: 'Oda bulunamadı.' };
    if (room.status !== 'playing') {
      return { ok: false, error: 'Oyun henüz başlamadı veya sona erdi.' };
    }

    const role = this.getPlayerRole(room.roomCode, params.playerToken);
    if (role !== 'w' && role !== 'b') {
      return { ok: false, error: 'Bu odada oyuncu değilsiniz.' };
    }
    if (role !== room.turn) {
      return { ok: false, error: 'Hamle sırası rakipte.' };
    }

    room.lastActivityAt = now;

    if (room.timeControl !== 'unlimited' && room.lastMoveAt !== null && room.moves.length > 0) {
      const elapsed = Math.max(0, now - room.lastMoveAt);
      const remaining = room.clocks[role] - elapsed;
      if (remaining <= 0) {
        room.clocks[role] = 0;
        room.status = 'finished';
        const winner: PieceColor = role === 'w' ? 'b' : 'w';
        room.outcome = {
          winner,
          reason: 'timeout',
          message: `${role === 'w' ? 'Beyaz' : 'Siyah'} oyuncunun süresi doldu. ${winner === 'w' ? 'Beyaz' : 'Siyah'} kazandı!`,
        };
        return { ok: true, room: this.toPublicState(room, now), role };
      }
      room.clocks[role] = remaining;
    }

    if (room.variant === 'shashki') {
      const shashkiState = deserializeShashkiState(room.fen);
      const stepRes = applyInteractiveShashkiStep(
        shashkiState,
        params.from,
        params.to,
        room.shashkiChain,
        room.moves.length,
        room.moves.map((m) => m.fen),
      );
      if (!stepRes.valid) {
        return { ok: false, error: 'Geçersiz Şaşki hamlesi.' };
      }

      if (stepRes.completed) {
        if (room.timeControl !== 'unlimited' && room.moves.length > 0) {
          room.clocks[role] += TIME_CONTROLS[room.timeControl].incrementMs;
        }
        room.fen = stepRes.stateKey!;
        room.turn = stepRes.nextState.turn;
        room.moves = [...room.moves, stepRes.moveRecord!];
        room.shashkiChain = null;
        room.openingName = 'Klasik Şaşki (8×8)';
        if (stepRes.outcome) {
          room.status = 'finished';
          room.outcome = stepRes.outcome;
        }
      } else {
        room.fen = serializeShashkiState(stepRes.nextState);
        room.shashkiChain = stepRes.nextChain;
      }
      room.lastMoveAt = now;
      room.drawOfferFrom = null;

      return { ok: true, room: this.toPublicState(room, now), role };
    }

    const applied = applyMove(
      room.fen,
      { from: params.from, to: params.to, promotion: params.promotion },
      room.moves.length,
      room.moves.map((m) => m.fen),
    );

    if (!applied.valid || !applied.move) {
      return { ok: false, error: applied.error ?? 'Geçersiz hamle.' };
    }

    if (room.timeControl !== 'unlimited' && room.moves.length > 0) {
      room.clocks[role] += TIME_CONTROLS[room.timeControl].incrementMs;
    }

    room.fen = applied.fen;
    room.turn = applied.turn;
    room.moves = [...room.moves, applied.move];
    room.lastMoveAt = now;
    room.drawOfferFrom = null;
    room.openingName = detectOpeningName(room.moves.map((m) => m.san));

    if (applied.outcome) {
      room.status = 'finished';
      room.outcome = applied.outcome;
    }

    return { ok: true, room: this.toPublicState(room, now), role };
  }

  public resign(params: {
    roomCode: string;
    playerToken: string;
    now?: number;
  }): RoomActionResult {
    const now = params.now ?? Date.now();
    const room = this.rooms.get(params.roomCode.trim().toUpperCase());
    if (!room) return { ok: false, error: 'Oda bulunamadı.' };
    if (room.status !== 'playing') return { ok: false, error: 'Aktif oyun yok.' };

    const role = this.getPlayerRole(room.roomCode, params.playerToken);
    if (role !== 'w' && role !== 'b') return { ok: false, error: 'Yetkisiz işlem.' };

    room.lastActivityAt = now;
    const winner: PieceColor = role === 'w' ? 'b' : 'w';
    room.status = 'finished';
    room.outcome = {
      winner,
      reason: 'resignation',
      message: `${role === 'w' ? 'Beyaz' : 'Siyah'} terk etti. ${winner === 'w' ? 'Beyaz' : 'Siyah'} kazandı!`,
    };
    return { ok: true, room: this.toPublicState(room, now), role };
  }

  public offerDraw(params: {
    roomCode: string;
    playerToken: string;
    now?: number;
  }): RoomActionResult {
    const now = params.now ?? Date.now();
    const room = this.rooms.get(params.roomCode.trim().toUpperCase());
    if (!room || room.status !== 'playing') return { ok: false, error: 'Aktif oyun yok.' };
    const role = this.getPlayerRole(room.roomCode, params.playerToken);
    if (role !== 'w' && role !== 'b') return { ok: false, error: 'Yetkisiz işlem.' };

    room.lastActivityAt = now;
    room.drawOfferFrom = role;
    return { ok: true, room: this.toPublicState(room, now), role };
  }

  public respondDraw(params: {
    roomCode: string;
    playerToken: string;
    accept: boolean;
    now?: number;
  }): RoomActionResult {
    const now = params.now ?? Date.now();
    const room = this.rooms.get(params.roomCode.trim().toUpperCase());
    if (!room || room.status !== 'playing') return { ok: false, error: 'Aktif oyun yok.' };
    const role = this.getPlayerRole(room.roomCode, params.playerToken);
    if (role !== 'w' && role !== 'b') return { ok: false, error: 'Yetkisiz işlem.' };
    if (!room.drawOfferFrom || room.drawOfferFrom === role) {
      return { ok: false, error: 'Yanıtlanacak beraberlik teklifi yok.' };
    }

    room.lastActivityAt = now;
    if (params.accept) {
      room.status = 'finished';
      room.drawOfferFrom = null;
      room.outcome = {
        winner: 'draw',
        reason: 'agreement',
        message: 'Oyuncuların anlaşmasıyla oyun berabere sonuçlandı.',
      };
    } else {
      room.drawOfferFrom = null;
    }
    return { ok: true, room: this.toPublicState(room, now), role };
  }

  public voteRematch(params: {
    roomCode: string;
    playerToken: string;
    now?: number;
  }): RoomActionResult {
    const now = params.now ?? Date.now();
    const room = this.rooms.get(params.roomCode.trim().toUpperCase());
    if (!room || room.status !== 'finished') {
      return { ok: false, error: 'Rövanş için oyun bitmiş olmalı.' };
    }
    const role = this.getPlayerRole(room.roomCode, params.playerToken);
    if (role !== 'w' && role !== 'b') return { ok: false, error: 'Yetkisiz işlem.' };

    room.lastActivityAt = now;
    room.rematchVotes.add(role);
    let rematchStarted = false;
    if (room.rematchVotes.has('w') && room.rematchVotes.has('b')) {
      const prevWhite = room.players.w;
      const prevBlack = room.players.b;
      const tc = TIME_CONTROLS[room.timeControl];
      room.players = { w: prevBlack, b: prevWhite };
      room.status = 'playing';
      const isShashki = room.variant === 'shashki';
      room.fen = isShashki ? INITIAL_SHASHKI_STATE_KEY : INITIAL_FEN;
      room.turn = 'w';
      room.moves = [];
      room.clocks = { w: tc.initialMs, b: tc.initialMs };
      room.lastMoveAt = null;
      room.drawOfferFrom = null;
      room.rematchVotes.clear();
      room.outcome = null;
      room.openingName = isShashki ? 'Klasik Şaşki (8×8)' : 'Başlangıç Konumu';
      room.shashkiChain = null;
      rematchStarted = true;
    }

    return { ok: true, room: this.toPublicState(room, now), role, rematchStarted };
  }

  public leaveRoom(
    roomCode: string,
    playerToken: string,
    now: number = Date.now(),
  ): RoomPublicState | null {
    const normalized = roomCode.trim().toUpperCase();
    const room = this.rooms.get(normalized);
    if (!room) return null;

    if (room.status === 'waiting') {
      const onlyWhiteLeaving = room.players.w?.token === playerToken && !room.players.b;
      const onlyBlackLeaving = room.players.b?.token === playerToken && !room.players.w;
      if (onlyWhiteLeaving || onlyBlackLeaving) {
        this.rooms.delete(normalized);
        return null;
      }
    }

    return this.setConnectionStatus(normalized, playerToken, false, now);
  }

  public setConnectionStatus(
    roomCode: string,
    playerToken: string,
    connected: boolean,
    now: number = Date.now(),
  ): RoomPublicState | null {
    const room = this.rooms.get(roomCode.trim().toUpperCase());
    if (!room) return null;
    room.lastActivityAt = now;
    if (room.players.w?.token === playerToken) {
      room.players.w.connected = connected;
    } else if (room.players.b?.token === playerToken) {
      room.players.b.connected = connected;
    } else if (!connected) {
      room.spectatorTokens.delete(playerToken);
    }
    return this.toPublicState(room, now);
  }

  public pruneStaleRooms(
    now: number = Date.now(),
    maxIdleMs: number = 2 * 60 * 60 * 1000,
    waitingEmptyGraceMs: number = 15 * 60 * 1000,
  ): number {
    let removed = 0;
    for (const [code, room] of this.rooms.entries()) {
      const anyConnected =
        Boolean(room.players.w?.connected) ||
        Boolean(room.players.b?.connected) ||
        room.spectatorTokens.size > 0;
      if (anyConnected) continue;

      const idleMs = now - room.lastActivityAt;
      if (
        (room.status === 'waiting' && idleMs > waitingEmptyGraceMs) ||
        idleMs > maxIdleMs
      ) {
        this.rooms.delete(code);
        removed++;
      }
    }
    return removed;
  }

  public sweepExpiredClocks(now: number = Date.now()): RoomPublicState[] {
    const updated: RoomPublicState[] = [];
    for (const room of this.rooms.values()) {
      if (
        room.status === 'playing' &&
        room.timeControl !== 'unlimited' &&
        room.lastMoveAt !== null &&
        room.moves.length > 0
      ) {
        const elapsed = Math.max(0, now - room.lastMoveAt);
        const activeClock = room.clocks[room.turn] - elapsed;
        if (activeClock <= 0) {
          room.clocks[room.turn] = 0;
          room.status = 'finished';
          room.lastActivityAt = now;
          const winner: PieceColor = room.turn === 'w' ? 'b' : 'w';
          room.outcome = {
            winner,
            reason: 'timeout',
            message: `${room.turn === 'w' ? 'Beyaz' : 'Siyah'} oyuncunun süresi doldu. ${winner === 'w' ? 'Beyaz' : 'Siyah'} kazandı!`,
          };
          updated.push(this.toPublicState(room, now));
        }
      }
    }
    return updated;
  }
}
