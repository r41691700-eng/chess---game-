import type { GameOutcome, PieceType, TimeControlKey } from './types';
import type { AppThemeId } from './themes';

export type Language = 'tr' | 'en' | 'ru' | 'az';

export interface LanguageOption {
  id: Language;
  shortLabel: string;
  nativeLabel: string;
}

export const LANGUAGES: LanguageOption[] = [
  { id: 'tr', shortLabel: 'TR', nativeLabel: 'Türkçe' },
  { id: 'en', shortLabel: 'EN', nativeLabel: 'English' },
  { id: 'ru', shortLabel: 'RU', nativeLabel: 'Русский' },
  { id: 'az', shortLabel: 'AZ', nativeLabel: 'Azərbaycanca' },
];

const LANG_STORAGE_KEY = 'sahmat_lang_v1';

export function getSavedLanguage(): Language {
  if (typeof window === 'undefined') return 'tr';
  try {
    const raw = localStorage.getItem(LANG_STORAGE_KEY);
    if (raw === 'tr' || raw === 'en' || raw === 'ru' || raw === 'az') {
      return raw;
    }
  } catch {
    // ignore storage errors
  }
  return 'tr';
}

export function saveLanguage(lang: Language): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(LANG_STORAGE_KEY, lang);
  } catch {
    // ignore storage errors
  }
}

export interface Translations {
  appSubtitle: string;
  languageLabel: string;
  languageAriaLabel: string;
  settings: string;
  openSettingsAria: string;
  closeSettingsAria: string;
  modeTablistAria: string;
  modeBot: string;
  modeShashki: string;
  modeOnline: string;
  chessGameLabel: string;
  timeControlLabel: string;
  timeControls: Record<TimeControlKey, string>;
  difficultyLabel: string;
  diffEasy: string;
  diffMedium: string;
  diffHard: string;
  sideSelectionLabel: string;
  sidePrefOnlineLabel: string;
  white: string;
  black: string;
  random: string;
  startGame: string;
  playerNameLabel: string;
  playerNamePlaceholder: string;
  defaultPlayerName: string;
  searchingOpponent: string;
  cancel: string;
  quickMatch: string;
  createPrivateRoom: string;
  joinByCodeLabel: string;
  joinByCodePlaceholder: string;
  joinButton: string;
  menuFooterHint: string;

  // Theme Selector
  themeGroupAria: string;
  themeBgLabel: string;
  themeCustom: string;
  themeCustomShort: string;
  themeCustomTitle: string;
  themeCustomPickerAria: string;
  themeColorPrefix: string;
  themes: Record<Exclude<AppThemeId, 'custom'>, string>;

  // Settings Modal
  settingsDialogAria: string;
  settingsLanguageSection: string;
  settingsAudioSection: string;
  sfxLabel: string;
  sfxDesc: string;
  sfxVolumeAria: string;
  musicLabel: string;
  musicDesc: string;
  musicVolumeAria: string;
  settingsBoardSection: string;
  legalMovesLabel: string;
  legalMovesDesc: string;
  coordsLabel: string;
  coordsDesc: string;
  animatePiecesLabel: string;
  animatePiecesDesc: string;
  autoQueenLabel: string;
  autoQueenDesc: string;
  settingsThemeSection: string;
  resetDefaults: string;
  done: string;

  // In-game / HUD / Board
  onlineLabel: string;
  roomLabel: string;
  spectatorLabel: string;
  player1: string;
  player2: string;
  waitingOpponent: string;
  botPlayerLabel: (diffLabel: string) => string;
  youBadge: string;
  disconnectedBadge: string;
  turnPill: string;

  // Move History Panel
  moveHistoryAria: string;
  moveHistoryTitle: string;
  moveCount: (count: number) => string;
  gameOverStatus: string;
  reviewMoveStatus: (ply: number) => string;
  checkTurnStatus: (isWhite: boolean) => string;
  turnStatus: (isWhite: boolean) => string;
  backToLive: string;
  drawOfferReceived: string;
  accept: string;
  decline: string;
  noMovesYet: string;
  noMovesHint: string;
  navFirstAria: string;
  navPrevAria: string;
  navNextAria: string;
  navLastAria: string;
  flipBoard: string;
  drawOffer: string;
  drawOfferSent: string;
  resign: string;
  newGame: string;
  mainMenu: string;

  // Board / Pieces
  pieces: Record<PieceType, string>;
  emptySquare: string;
  captureMove: string;
  legalMove: string;

  // Modals
  promotionAria: string;
  promotionTitle: string;
  promotionDesc: string;
  dismissPromo: string;
  gameOverAria: string;
  gameDrawTitle: string;
  whiteWonTitle: string;
  blackWonTitle: string;
  totalMovesLabel: string;
  openingLabel: string;
  waitingRematch: (count: number) => string;
  requestRematch: (count: number) => string;
  playAgain: string;
  inspectBoard: string;
  waitingBannerPrefix: string;
  inviteLink: string;
  copied: string;

  // Şaşki
  shashkiTitle: string;
  shashkiOpponentLabel: string;
  shashkiBotPlayerLabel: (diffLabel: string) => string;
  shashkiClassicLabel: string;
  shashkiManPiece: string;
  shashkiKingPiece: string;
  shashkiMandatoryCaptureStatus: (isWhite: boolean) => string;
  shashkiChainCaptureStatus: (isWhite: boolean) => string;
  shashkiVariantLabel: string;

  // Errors & Outcomes
  wsWaitError: string;
  outcomeMessages: {
    checkmate: (winner: 'w' | 'b') => string;
    stalemate: string;
    threefold: string;
    insufficient: string;
    fiftyMove: string;
    noPieces: (winner: 'w' | 'b') => string;
    noMoves: (winner: 'w' | 'b') => string;
    fifteenMove: string;
    resignation: (winner: 'w' | 'b') => string;
    timeout: (winner: 'w' | 'b') => string;
    agreement: string;
    abandoned: string;
  };
}

const TRANSLATIONS: Record<Language, Translations> = {
  tr: {
    appSubtitle: 'Çevrimiçi, Yapay Zekalı ve Klasik Satranç',
    languageLabel: 'Dil',
    languageAriaLabel: 'Dil seçimi',
    settings: 'Ayarlar',
    openSettingsAria: 'Oyun ayarlarını aç',
    closeSettingsAria: 'Ayarları kapat',
    modeTablistAria: 'Oyun modu seçimi',
    modeBot: 'Bot',
    modeShashki: 'Şaşki',
    modeOnline: 'Çevrimiçi',
    chessGameLabel: 'Satranç',
    timeControlLabel: 'Süre Kontrolü',
    timeControls: {
      '3+2': '3+2 Yıldırım',
      '5+0': '5+0 Yıldırım',
      '10+0': '10+0 Hızlı',
      unlimited: 'Süresiz',
    },
    difficultyLabel: 'Zorluk Seviyesi',
    diffEasy: 'Kolay',
    diffMedium: 'Orta',
    diffHard: 'Usta',
    sideSelectionLabel: 'Taraf Seçimi',
    sidePrefOnlineLabel: 'Oda Kurarken Taraf Tercihi',
    white: 'Beyaz',
    black: 'Siyah',
    random: 'Rastgele',
    startGame: 'Oyuna Başla',
    playerNameLabel: 'Oyuncu Adınız',
    playerNamePlaceholder: 'Adınızı girin',
    defaultPlayerName: 'Oyuncu',
    searchingOpponent: 'Rakip aranıyor...',
    cancel: 'İptal Et',
    quickMatch: 'Hızlı Eşleşme',
    createPrivateRoom: 'Özel Oda Kur',
    joinByCodeLabel: 'Oda Kodu ile Katıl',
    joinByCodePlaceholder: 'Örn: KARE64',
    joinButton: 'Katıl',
    menuFooterHint: 'Tıklayarak veya sürükleyerek hamle yapın · Ok tuşlarıyla hamle geçmişinde gezinin',

    themeGroupAria: 'Arkaplan rengi seçimi',
    themeBgLabel: 'Arkaplan',
    themeCustom: 'Özel Renk',
    themeCustomShort: 'Özel',
    themeCustomTitle: 'İstediğiniz herhangi bir arkaplan rengini seçin',
    themeCustomPickerAria: 'Özel arkaplan rengi seç',
    themeColorPrefix: 'Arkaplan rengi:',
    themes: {
      cream: 'Klasik Krem',
      daylight: 'Saf Beyaz',
      sky: 'Gök Mavisi',
      sage: 'Adaçayı',
      blush: 'Gül Kurusu',
      lavender: 'Lavanta',
      honey: 'Kehribar',
      obsidian: 'Gece Abanozu',
    },

    settingsDialogAria: 'Oyun Ayarları',
    settingsLanguageSection: 'Dil',
    settingsAudioSection: 'Ses ve Müzik',
    sfxLabel: 'Taş ve Hamle Sesleri',
    sfxDesc: 'Taş yerleştirme, yeme, şah ve başlangıç sesleri',
    sfxVolumeAria: 'Efekt ses seviyesi',
    musicLabel: 'Arkaplan Müziği',
    musicDesc: 'Oyun sırasında sakin piyano atmosferi',
    musicVolumeAria: 'Müzik ses seviyesi',
    settingsBoardSection: 'Tahta ve Oynanış',
    legalMovesLabel: 'Geçerli Hamle İpuçları',
    legalMovesDesc: 'Taş seçildiğinde gidilebilecek kareleri işaretle',
    coordsLabel: 'Tahta Koordinatları',
    coordsDesc: 'Tahta kenarlarında a–h ve 1–8 konumlarını göster',
    animatePiecesLabel: 'Taş Animasyonları',
    animatePiecesDesc: 'Hamleler arasında taşları yumuşakça kaydır',
    autoQueenLabel: 'Otomatik Vezir Terfisi',
    autoQueenDesc: 'Son sıraya ulaşan piyonu sormadan Vezire çevir',
    settingsThemeSection: 'Arkaplan Rengi',
    resetDefaults: 'Varsayılanlara Sıfırla',
    done: 'Tamam',

    onlineLabel: 'Çevrimiçi',
    roomLabel: 'Oda',
    spectatorLabel: 'İzleyici',
    player1: '1. Oyuncu',
    player2: '2. Oyuncu',
    waitingOpponent: 'Rakip Bekleniyor...',
    botPlayerLabel: (d) => `Bot (${d})`,
    youBadge: 'Siz',
    disconnectedBadge: 'Bağlantı kesildi',
    turnPill: 'Sıra',

    moveHistoryAria: 'Hamle Geçmişi Paneli',
    moveHistoryTitle: 'Hamle Geçmişi',
    moveCount: (n) => `${n} hamle`,
    gameOverStatus: 'Oyun Sona Erdi',
    reviewMoveStatus: (ply) => `Geçmiş İnceleme · ${ply}. hamle`,
    checkTurnStatus: (isW) => `Şah! Sıra ${isW ? 'Beyazda' : 'Siyahta'}`,
    turnStatus: (isW) => `Sıra ${isW ? 'Beyazda' : 'Siyahta'}`,
    backToLive: 'Canlıya Dön',
    drawOfferReceived: 'Rakip beraberlik teklif etti',
    accept: 'Kabul Et',
    decline: 'Reddet',
    noMovesYet: 'Henüz hamle yapılmadı',
    noMovesHint: 'Oyunu başlatmak için tahtadan bir taş seçip hamle yapın.',
    navFirstAria: 'Başlangıca git',
    navPrevAria: 'Önceki hamle',
    navNextAria: 'Sonraki hamle',
    navLastAria: 'Son hamleye git',
    flipBoard: 'Tahtayı Çevir',
    drawOffer: 'Beraberlik',
    drawOfferSent: 'Teklif İletildi',
    resign: 'Terk Et',
    newGame: 'Yeni Oyun',
    mainMenu: 'Ana Menü',

    pieces: { p: 'Piyon', n: 'At', b: 'Fil', r: 'Kale', q: 'Vezir', k: 'Şah' },
    emptySquare: 'Boş kare',
    captureMove: 'Yeme hamlesi',
    legalMove: 'Geçerli hamle',

    promotionAria: 'Terfi seçimi',
    promotionTitle: 'Terfi Seçimi',
    promotionDesc: 'Piyonunuzu terfi ettirmek istediğiniz taşı seçin.',
    dismissPromo: 'Vazgeç',
    gameOverAria: 'Oyun sonu özeti',
    gameDrawTitle: 'Oyun Berabere',
    whiteWonTitle: 'Beyaz Kazandı',
    blackWonTitle: 'Siyah Kazandı',
    totalMovesLabel: 'Toplam Hamle',
    openingLabel: 'Açılış',
    waitingRematch: (c) => `Rövanş Bekleniyor (${c}/2)`,
    requestRematch: (c) => `Rövanş İste (${c}/2)`,
    playAgain: 'Tekrar Oyna',
    inspectBoard: 'Tahtayı İncele',
    waitingBannerPrefix: 'Rakip bekleniyor · Oda:',
    inviteLink: 'Davet Bağlantısı',
    copied: 'Kopyalandı',

    shashkiTitle: 'ŞAŞKİ',
    shashkiOpponentLabel: 'Rakip',
    shashkiBotPlayerLabel: (d) => `Bot (${d})`,
    shashkiClassicLabel: 'Klasik Şaşki (8×8)',
    shashkiManPiece: 'Taş',
    shashkiKingPiece: 'Damka',
    shashkiMandatoryCaptureStatus: (isW) => `Zorunlu yeme · Sıra ${isW ? 'Beyazda' : 'Siyahta'}`,
    shashkiChainCaptureStatus: (isW) => `Zincirleme yeme devam ediyor · ${isW ? 'Beyaz' : 'Siyah'}`,
    shashkiVariantLabel: 'Mod',

    wsWaitError: 'Sunucu bağlantısı bekleniyor, lütfen tekrar deneyin.',
    outcomeMessages: {
      checkmate: (w) => `Şah Mat! ${w === 'w' ? 'Beyaz' : 'Siyah'} kazandı.`,
      stalemate: 'Pat! Oyun berabere sonuçlandı.',
      threefold: 'Üç kez konum tekrarı nedeniyle oyun berabere.',
      insufficient: 'Yetersiz materyal nedeniyle oyun berabere.',
      fiftyMove: '50 hamle kuralı gereği oyun berabere.',
      noPieces: (w) => `Rakip taşı kalmadı. ${w === 'w' ? 'Beyaz' : 'Siyah'} kazandı!`,
      noMoves: (w) => `Rakibin hamlesi kalmadı. ${w === 'w' ? 'Beyaz' : 'Siyah'} kazandı!`,
      fifteenMove: '15 hamle damka kuralı gereği oyun berabere.',
      resignation: (w) => `${w === 'w' ? 'Siyah' : 'Beyaz'} terk etti. ${w === 'w' ? 'Beyaz' : 'Siyah'} kazandı!`,
      timeout: (w) => `${w === 'w' ? 'Siyah' : 'Beyaz'} oyuncunun süresi doldu. ${w === 'w' ? 'Beyaz' : 'Siyah'} kazandı!`,
      agreement: 'Oyuncuların anlaşmasıyla oyun berabere sonuçlandı.',
      abandoned: 'Oyun sonlandırıldı.',
    },
  },

  en: {
    appSubtitle: 'Online, AI & Classic Chess',
    languageLabel: 'Language',
    languageAriaLabel: 'Language selection',
    settings: 'Settings',
    openSettingsAria: 'Open game settings',
    closeSettingsAria: 'Close settings',
    modeTablistAria: 'Game mode selection',
    modeBot: 'Bot',
    modeShashki: 'Shashki',
    modeOnline: 'Online',
    chessGameLabel: 'Chess',
    timeControlLabel: 'Time Control',
    timeControls: {
      '3+2': '3+2 Blitz',
      '5+0': '5+0 Blitz',
      '10+0': '10+0 Rapid',
      unlimited: 'Unlimited',
    },
    difficultyLabel: 'Difficulty',
    diffEasy: 'Easy',
    diffMedium: 'Medium',
    diffHard: 'Master',
    sideSelectionLabel: 'Side',
    sidePrefOnlineLabel: 'Side Preference When Creating Room',
    white: 'White',
    black: 'Black',
    random: 'Random',
    startGame: 'Start Game',
    playerNameLabel: 'Your Name',
    playerNamePlaceholder: 'Enter your name',
    defaultPlayerName: 'Player',
    searchingOpponent: 'Finding opponent...',
    cancel: 'Cancel',
    quickMatch: 'Quick Match',
    createPrivateRoom: 'Create Private Room',
    joinByCodeLabel: 'Join with Room Code',
    joinByCodePlaceholder: 'e.g. KARE64',
    joinButton: 'Join',
    menuFooterHint: 'Click or drag pieces to move · Use arrow keys to browse move history',

    themeGroupAria: 'Background color selection',
    themeBgLabel: 'Background',
    themeCustom: 'Custom Color',
    themeCustomShort: 'Custom',
    themeCustomTitle: 'Pick any custom background color',
    themeCustomPickerAria: 'Choose custom background color',
    themeColorPrefix: 'Background color:',
    themes: {
      cream: 'Classic Cream',
      daylight: 'Pure White',
      sky: 'Sky Blue',
      sage: 'Sage Green',
      blush: 'Rose Blush',
      lavender: 'Lavender',
      honey: 'Amber',
      obsidian: 'Midnight Ebony',
    },

    settingsDialogAria: 'Game Settings',
    settingsLanguageSection: 'Language',
    settingsAudioSection: 'Sound & Music',
    sfxLabel: 'Piece & Move Sounds',
    sfxDesc: 'Placement, capture, check, and start sounds',
    sfxVolumeAria: 'Sound effects volume',
    musicLabel: 'Background Music',
    musicDesc: 'Calm ambient piano while playing',
    musicVolumeAria: 'Music volume',
    settingsBoardSection: 'Board & Gameplay',
    legalMovesLabel: 'Legal Move Hints',
    legalMovesDesc: 'Highlight valid squares when a piece is selected',
    coordsLabel: 'Board Coordinates',
    coordsDesc: 'Show a–h and 1–8 labels around the board',
    animatePiecesLabel: 'Piece Animations',
    animatePiecesDesc: 'Smoothly glide pieces between moves',
    autoQueenLabel: 'Auto-Promote to Queen',
    autoQueenDesc: 'Promote pawns reaching the last rank automatically',
    settingsThemeSection: 'Background Color',
    resetDefaults: 'Reset Defaults',
    done: 'Done',

    onlineLabel: 'Online',
    roomLabel: 'Room',
    spectatorLabel: 'Spectator',
    player1: 'Player 1',
    player2: 'Player 2',
    waitingOpponent: 'Waiting for Opponent...',
    botPlayerLabel: (d) => `Bot (${d})`,
    youBadge: 'You',
    disconnectedBadge: 'Disconnected',
    turnPill: 'Turn',

    moveHistoryAria: 'Move History Panel',
    moveHistoryTitle: 'Move History',
    moveCount: (n) => `${n} moves`,
    gameOverStatus: 'Game Over',
    reviewMoveStatus: (ply) => `Reviewing · Move ${ply}`,
    checkTurnStatus: (isW) => `Check! ${isW ? "White's" : "Black's"} turn`,
    turnStatus: (isW) => `${isW ? "White's" : "Black's"} turn`,
    backToLive: 'Back to Live',
    drawOfferReceived: 'Opponent offered a draw',
    accept: 'Accept',
    decline: 'Decline',
    noMovesYet: 'No moves yet',
    noMovesHint: 'Select a piece on the board to start the game.',
    navFirstAria: 'Go to start',
    navPrevAria: 'Previous move',
    navNextAria: 'Next move',
    navLastAria: 'Go to latest move',
    flipBoard: 'Flip Board',
    drawOffer: 'Draw',
    drawOfferSent: 'Offer Sent',
    resign: 'Resign',
    newGame: 'New Game',
    mainMenu: 'Main Menu',

    pieces: { p: 'Pawn', n: 'Knight', b: 'Bishop', r: 'Rook', q: 'Queen', k: 'King' },
    emptySquare: 'Empty square',
    captureMove: 'Capture move',
    legalMove: 'Legal move',

    promotionAria: 'Promotion choice',
    promotionTitle: 'Pawn Promotion',
    promotionDesc: 'Choose which piece to promote your pawn to.',
    dismissPromo: 'Cancel',
    gameOverAria: 'Game over summary',
    gameDrawTitle: 'Game Drawn',
    whiteWonTitle: 'White Won',
    blackWonTitle: 'Black Won',
    totalMovesLabel: 'Total Moves',
    openingLabel: 'Opening',
    waitingRematch: (c) => `Waiting Rematch (${c}/2)`,
    requestRematch: (c) => `Request Rematch (${c}/2)`,
    playAgain: 'Play Again',
    inspectBoard: 'Inspect Board',
    waitingBannerPrefix: 'Waiting for opponent · Room:',
    inviteLink: 'Invite Link',
    copied: 'Copied',

    shashkiTitle: 'SHASHKI',
    shashkiOpponentLabel: 'Opponent',
    shashkiBotPlayerLabel: (d) => `Bot (${d})`,
    shashkiClassicLabel: 'Classic Shashki (8×8)',
    shashkiManPiece: 'Man',
    shashkiKingPiece: 'Damka King',
    shashkiMandatoryCaptureStatus: (isW) => `Mandatory capture · ${isW ? "White's" : "Black's"} turn`,
    shashkiChainCaptureStatus: (isW) => `Chain capture active · ${isW ? 'White' : 'Black'}`,
    shashkiVariantLabel: 'Variant',

    wsWaitError: 'Waiting for server connection, please try again.',
    outcomeMessages: {
      checkmate: (w) => `Checkmate! ${w === 'w' ? 'White' : 'Black'} wins.`,
      stalemate: 'Stalemate! Game ended in a draw.',
      threefold: 'Draw by threefold repetition.',
      insufficient: 'Draw by insufficient material.',
      fiftyMove: 'Draw by fifty-move rule.',
      noPieces: (w) => `All opponent pieces captured. ${w === 'w' ? 'White' : 'Black'} wins!`,
      noMoves: (w) => `Opponent has no legal moves. ${w === 'w' ? 'White' : 'Black'} wins!`,
      fifteenMove: 'Draw by 15-move kings rule.',
      resignation: (w) => `${w === 'w' ? 'Black' : 'White'} resigned. ${w === 'w' ? 'White' : 'Black'} wins!`,
      timeout: (w) => `${w === 'w' ? 'Black' : 'White'} ran out of time. ${w === 'w' ? 'White' : 'Black'} wins!`,
      agreement: 'Game drawn by mutual agreement.',
      abandoned: 'Game ended.',
    },
  },

  ru: {
    appSubtitle: 'Онлайн, бот и классические шахматы',
    languageLabel: 'Язык',
    languageAriaLabel: 'Выбор языка',
    settings: 'Настройки',
    openSettingsAria: 'Открыть настройки игры',
    closeSettingsAria: 'Закрыть настройки',
    modeTablistAria: 'Выбор режима игры',
    modeBot: 'Бот',
    modeShashki: 'Шашки',
    modeOnline: 'Онлайн',
    chessGameLabel: 'Шахматы',
    timeControlLabel: 'Контроль времени',
    timeControls: {
      '3+2': '3+2 Блиц',
      '5+0': '5+0 Блиц',
      '10+0': '10+0 Рапид',
      unlimited: 'Без времени',
    },
    difficultyLabel: 'Уровень сложности',
    diffEasy: 'Лёгкий',
    diffMedium: 'Средний',
    diffHard: 'Мастер',
    sideSelectionLabel: 'Цвет фигур',
    sidePrefOnlineLabel: 'Выбор стороны при создании комнаты',
    white: 'Белые',
    black: 'Чёрные',
    random: 'Случайно',
    startGame: 'Начать игру',
    playerNameLabel: 'Ваше имя',
    playerNamePlaceholder: 'Введите имя',
    defaultPlayerName: 'Игрок',
    searchingOpponent: 'Поиск соперника...',
    cancel: 'Отмена',
    quickMatch: 'Быстрая игра',
    createPrivateRoom: 'Создать комнату',
    joinByCodeLabel: 'Войти по коду комнаты',
    joinByCodePlaceholder: 'Напр.: KARE64',
    joinButton: 'Войти',
    menuFooterHint: 'Нажмите или перетащите фигуру для хода · Стрелками листайте историю ходов',

    themeGroupAria: 'Выбор цвета фона',
    themeBgLabel: 'Фон',
    themeCustom: 'Свой цвет',
    themeCustomShort: 'Свой',
    themeCustomTitle: 'Выберите любой цвет фона',
    themeCustomPickerAria: 'Выбрать свой цвет фона',
    themeColorPrefix: 'Цвет фона:',
    themes: {
      cream: 'Классический крем',
      daylight: 'Чистый белый',
      sky: 'Небесный',
      sage: 'Шалфей',
      blush: 'Пыльная роза',
      lavender: 'Лаванда',
      honey: 'Янтарь',
      obsidian: 'Ночной эбен',
    },

    settingsDialogAria: 'Настройки игры',
    settingsLanguageSection: 'Язык',
    settingsAudioSection: 'Звук и музыка',
    sfxLabel: 'Звуки фигур и ходов',
    sfxDesc: 'Ход, взятие, шах и начало партии',
    sfxVolumeAria: 'Громкость эффектов',
    musicLabel: 'Фоновая музыка',
    musicDesc: 'Спокойное фортепиано во время игры',
    musicVolumeAria: 'Громкость музыки',
    settingsBoardSection: 'Доска и игра',
    legalMovesLabel: 'Подсказки ходов',
    legalMovesDesc: 'Показывать доступные клетки при выборе фигуры',
    coordsLabel: 'Координаты доски',
    coordsDesc: 'Отображать a–h и 1–8 по краям доски',
    animatePiecesLabel: 'Анимация фигур',
    animatePiecesDesc: 'Плавное перемещение фигур между ходами',
    autoQueenLabel: 'Автопревращение в ферзя',
    autoQueenDesc: 'Превращать пешку на последней линии без запроса',
    settingsThemeSection: 'Цвет фона',
    resetDefaults: 'Сбросить настройки',
    done: 'Готово',

    onlineLabel: 'Онлайн',
    roomLabel: 'Комната',
    spectatorLabel: 'Зритель',
    player1: 'Игрок 1',
    player2: 'Игрок 2',
    waitingOpponent: 'Ожидание соперника...',
    botPlayerLabel: (d) => `Бот (${d})`,
    youBadge: 'Вы',
    disconnectedBadge: 'Отключён',
    turnPill: 'Ход',

    moveHistoryAria: 'Панель истории ходов',
    moveHistoryTitle: 'История ходов',
    moveCount: (n) => `${n} ходов`,
    gameOverStatus: 'Партия завершена',
    reviewMoveStatus: (ply) => `Просмотр · ход ${ply}`,
    checkTurnStatus: (isW) => `Шах! Ход ${isW ? 'белых' : 'чёрных'}`,
    turnStatus: (isW) => `Ход ${isW ? 'белых' : 'чёрных'}`,
    backToLive: 'К текущей',
    drawOfferReceived: 'Соперник предлагает ничью',
    accept: 'Принять',
    decline: 'Отклонить',
    noMovesYet: 'Ходов пока нет',
    noMovesHint: 'Выберите фигуру на доске, чтобы начать партию.',
    navFirstAria: 'В начало',
    navPrevAria: 'Предыдущий ход',
    navNextAria: 'Следующий ход',
    navLastAria: 'К последнему ходу',
    flipBoard: 'Перевернуть',
    drawOffer: 'Ничья',
    drawOfferSent: 'Предложено',
    resign: 'Сдаться',
    newGame: 'Новая игра',
    mainMenu: 'Главное меню',

    pieces: { p: 'Пешка', n: 'Конь', b: 'Слон', r: 'Ладья', q: 'Ферзь', k: 'Король' },
    emptySquare: 'Пустая клетка',
    captureMove: 'Взятие',
    legalMove: 'Доступный ход',

    promotionAria: 'Выбор превращения',
    promotionTitle: 'Превращение пешки',
    promotionDesc: 'Выберите фигуру для превращения пешки.',
    dismissPromo: 'Отмена',
    gameOverAria: 'Итог партии',
    gameDrawTitle: 'Ничья',
    whiteWonTitle: 'Победа белых',
    blackWonTitle: 'Победа чёрных',
    totalMovesLabel: 'Всего ходов',
    openingLabel: 'Дебют',
    waitingRematch: (c) => `Ожидание реванша (${c}/2)`,
    requestRematch: (c) => `Реванш (${c}/2)`,
    playAgain: 'Играть снова',
    inspectBoard: 'Изучить доску',
    waitingBannerPrefix: 'Ожидание соперника · Комната:',
    inviteLink: 'Ссылка-приглашение',
    copied: 'Скопировано',

    shashkiTitle: 'ШАШКИ',
    shashkiOpponentLabel: 'Соперник',
    shashkiBotPlayerLabel: (d) => `Бот (${d})`,
    shashkiClassicLabel: 'Русские шашки (8×8)',
    shashkiManPiece: 'Шашка',
    shashkiKingPiece: 'Дамка',
    shashkiMandatoryCaptureStatus: (isW) => `Обязательный бой · Ход ${isW ? 'белых' : 'чёрных'}`,
    shashkiChainCaptureStatus: (isW) => `Продолжайте взятие · ${isW ? 'Белые' : 'Чёрные'}`,
    shashkiVariantLabel: 'Режим',

    wsWaitError: 'Ожидание подключения к серверу, повторите попытку.',
    outcomeMessages: {
      checkmate: (w) => `Мат! Победили ${w === 'w' ? 'белые' : 'чёрные'}.`,
      stalemate: 'Пат! Партия завершилась вничью.',
      threefold: 'Ничья из-за троекратного повторения позиции.',
      insufficient: 'Ничья из-за недостатка материала.',
      fiftyMove: 'Ничья по правилу 50 ходов.',
      noPieces: (w) => `Все шашки соперника взяты. Победили ${w === 'w' ? 'белые' : 'чёрные'}!`,
      noMoves: (w) => `У соперника нет ходов. Победили ${w === 'w' ? 'белые' : 'чёрные'}!`,
      fifteenMove: 'Ничья по правилу 15 ходов дамок.',
      resignation: (w) => `${w === 'w' ? 'Чёрные' : 'Белые'} сдались. Победили ${w === 'w' ? 'белые' : 'чёрные'}!`,
      timeout: (w) => `У ${w === 'w' ? 'чёрных' : 'белых'} закончилось время. Победили ${w === 'w' ? 'белые' : 'чёрные'}!`,
      agreement: 'Ничья по соглашению сторон.',
      abandoned: 'Партия завершена.',
    },
  },

  az: {
    appSubtitle: 'Onlayn, Bot və Klassik Şahmat',
    languageLabel: 'Dil',
    languageAriaLabel: 'Dil seçimi',
    settings: 'Ayarlar',
    openSettingsAria: 'Oyun ayarlarını aç',
    closeSettingsAria: 'Ayarları bağla',
    modeTablistAria: 'Oyun rejimi seçimi',
    modeBot: 'Bot',
    modeShashki: 'Şaşki',
    modeOnline: 'Onlayn',
    chessGameLabel: 'Şahmat',
    timeControlLabel: 'Vaxt Nəzarəti',
    timeControls: {
      '3+2': '3+2 Blits',
      '5+0': '5+0 Blits',
      '10+0': '10+0 Sürətli',
      unlimited: 'Vaxtsız',
    },
    difficultyLabel: 'Çətinlik Səviyyəsi',
    diffEasy: 'Asan',
    diffMedium: 'Orta',
    diffHard: 'Usta',
    sideSelectionLabel: 'Tərəf Seçimi',
    sidePrefOnlineLabel: 'Otaq Qurarkən Tərəf Seçimi',
    white: 'Ağ',
    black: 'Qara',
    random: 'Təsadüfi',
    startGame: 'Oyuna Başla',
    playerNameLabel: 'Oyunçu Adınız',
    playerNamePlaceholder: 'Adınızı daxil edin',
    defaultPlayerName: 'Oyunçu',
    searchingOpponent: 'Rəqib axtarılır...',
    cancel: 'Ləğv Et',
    quickMatch: 'Sürətli Uyğunlaşma',
    createPrivateRoom: 'Xüsusi Otaq Qur',
    joinByCodeLabel: 'Otaq Kodu ilə Qoşul',
    joinByCodePlaceholder: 'Məs: KARE64',
    joinButton: 'Qoşul',
    menuFooterHint: 'Gediş etmək üçün klikləyin və ya sürüşdürün · Ox düymələri ilə gediş tarixçəsinə baxın',

    themeGroupAria: 'Arxa fon rəngi seçimi',
    themeBgLabel: 'Arxa fon',
    themeCustom: 'Xüsusi Rəng',
    themeCustomShort: 'Xüsusi',
    themeCustomTitle: 'İstədiyiniz arxa fon rəngini seçin',
    themeCustomPickerAria: 'Xüsusi arxa fon rəngi seç',
    themeColorPrefix: 'Arxa fon rəngi:',
    themes: {
      cream: 'Klassik Krem',
      daylight: 'Saf Ağ',
      sky: 'Səma Mavisi',
      sage: 'Adaçayı',
      blush: 'Qızılgül',
      lavender: 'Lavanda',
      honey: 'Kəhrəba',
      obsidian: 'Gecə Qarası',
    },

    settingsDialogAria: 'Oyun Ayarları',
    settingsLanguageSection: 'Dil',
    settingsAudioSection: 'Səs və Musiqi',
    sfxLabel: 'Fiqur və Gediş Səsləri',
    sfxDesc: 'Fiqur qoyma, vurma, şah və başlanğıc səsləri',
    sfxVolumeAria: 'Effekt səs səviyyəsi',
    musicLabel: 'Arxa Fon Musiqisi',
    musicDesc: 'Oyun zamanı sakit piano atmosferi',
    musicVolumeAria: 'Musiqi səs səviyyəsi',
    settingsBoardSection: 'Lövhə və Oynanış',
    legalMovesLabel: 'Mümkün Gediş İpucları',
    legalMovesDesc: 'Fiqur seçildikdə gedilə bilən xanaları göstər',
    coordsLabel: 'Lövhə Koordinatları',
    coordsDesc: 'Lövhə kənarlarında a–h və 1–8 mövqelərini göstər',
    animatePiecesLabel: 'Fiqur Animasiyaları',
    animatePiecesDesc: 'Gedişlər arasında fiqurları yumşaq sürüşdür',
    autoQueenLabel: 'Avtomatik Vəzir Çevrilməsi',
    autoQueenDesc: 'Son sıraya çatan piyadanı soruşmadan Vəzirə çevir',
    settingsThemeSection: 'Arxa Fon Rəngi',
    resetDefaults: 'Varsayılanlara Sıfırla',
    done: 'Tamam',

    onlineLabel: 'Onlayn',
    roomLabel: 'Otaq',
    spectatorLabel: 'İzləyici',
    player1: '1-ci Oyunçu',
    player2: '2-ci Oyunçu',
    waitingOpponent: 'Rəqib Gözlənilir...',
    botPlayerLabel: (d) => `Bot (${d})`,
    youBadge: 'Siz',
    disconnectedBadge: 'Bağlantı kəsildi',
    turnPill: 'Növbə',

    moveHistoryAria: 'Gediş Tarixçəsi Paneli',
    moveHistoryTitle: 'Gediş Tarixçəsi',
    moveCount: (n) => `${n} gediş`,
    gameOverStatus: 'Oyun Bitdi',
    reviewMoveStatus: (ply) => `Tarixçəyə Baxış · ${ply}-ci gediş`,
    checkTurnStatus: (isW) => `Şah! Növbə ${isW ? 'Ağlardadır' : 'Qaralardadır'}`,
    turnStatus: (isW) => `Növbə ${isW ? 'Ağlardadır' : 'Qaralardadır'}`,
    backToLive: 'Canlıya Qayıt',
    drawOfferReceived: 'Rəqib heç-heçə təklif etdi',
    accept: 'Qəbul Et',
    decline: 'Rədd Et',
    noMovesYet: 'Hələ gediş edilməyib',
    noMovesHint: 'Oyunu başlamaq üçün lövhədən fiqur seçib gediş edin.',
    navFirstAria: 'Başlanğıca get',
    navPrevAria: 'Əvvəlki gediş',
    navNextAria: 'Növbəti gediş',
    navLastAria: 'Son gedişə get',
    flipBoard: 'Lövhəni Çevir',
    drawOffer: 'Heç-heçə',
    drawOfferSent: 'Təklif Göndərildi',
    resign: 'Təslim Ol',
    newGame: 'Yeni Oyun',
    mainMenu: 'Əsas Menyu',

    pieces: { p: 'Piyada', n: 'At', b: 'Fil', r: 'Top', q: 'Vəzir', k: 'Şah' },
    emptySquare: 'Boş xana',
    captureMove: 'Vurma gedişi',
    legalMove: 'Mümkün gediş',

    promotionAria: 'Çevrilmə seçimi',
    promotionTitle: 'Piyada Çevrilməsi',
    promotionDesc: 'Piyadanızı çevirmək istədiyiniz fiquru seçin.',
    dismissPromo: 'İmtina Et',
    gameOverAria: 'Oyunun nəticəsi',
    gameDrawTitle: 'Oyun Heç-heçə',
    whiteWonTitle: 'Ağlar Qazandı',
    blackWonTitle: 'Qaralar Qazandı',
    totalMovesLabel: 'Ümumi Gediş',
    openingLabel: 'Açılış',
    waitingRematch: (c) => `Revanş Gözlənilir (${c}/2)`,
    requestRematch: (c) => `Revanş İstə (${c}/2)`,
    playAgain: 'Yenidən Oyna',
    inspectBoard: 'Lövhəyə Bax',
    waitingBannerPrefix: 'Rəqib gözlənilir · Otaq:',
    inviteLink: 'Dəvət Linki',
    copied: 'Kopyalandı',

    shashkiTitle: 'ŞAŞKİ',
    shashkiOpponentLabel: 'Rəqib',
    shashkiBotPlayerLabel: (d) => `Bot (${d})`,
    shashkiClassicLabel: 'Klassik Şaşki (8×8)',
    shashkiManPiece: 'Daş',
    shashkiKingPiece: 'Damka',
    shashkiMandatoryCaptureStatus: (isW) => `Məcburi vurma · Növbə ${isW ? 'Ağlardadır' : 'Qaralardadır'}`,
    shashkiChainCaptureStatus: (isW) => `Ardıcıl vurma davam edir · ${isW ? 'Ağ' : 'Qara'}`,
    shashkiVariantLabel: 'Rejim',

    wsWaitError: 'Server bağlantısı gözlənilir, zəhmət olmasa yenidən cəhd edin.',
    outcomeMessages: {
      checkmate: (w) => `Şah Mat! ${w === 'w' ? 'Ağlar' : 'Qaralar'} qazandı.`,
      stalemate: 'Pat! Oyun heç-heçə bitdi.',
      threefold: 'Üç dəfə mövqe təkrarına görə oyun heç-heçə bitdi.',
      insufficient: 'Kifayət qədər fiqur olmadığına görə oyun heç-heçə bitdi.',
      fiftyMove: '50 gediş qaydasına görə oyun heç-heçə bitdi.',
      noPieces: (w) => `Rəqibin daşı qalmadı. ${w === 'w' ? 'Ağlar' : 'Qaralar'} qazandı!`,
      noMoves: (w) => `Rəqibin gedişi qalmadı. ${w === 'w' ? 'Ağlar' : 'Qaralar'} qazandı!`,
      fifteenMove: '15 damka gedişi qaydasına görə heç-heçə.',
      resignation: (w) => `${w === 'w' ? 'Qaralar' : 'Ağlar'} təslim oldu. ${w === 'w' ? 'Ağlar' : 'Qaralar'} qazandı!`,
      timeout: (w) => `${w === 'w' ? 'Qara' : 'Ağ'} oyunçunun vaxtı bitdi. ${w === 'w' ? 'Ağlar' : 'Qaralar'} qazandı!`,
      agreement: 'Oyunçuların razılığı ilə oyun heç-heçə bitdi.',
      abandoned: 'Oyun başa çatdı.',
    },
  },
};

export function getTranslations(lang: Language): Translations {
  return TRANSLATIONS[lang] ?? TRANSLATIONS.tr;
}

const OPENING_TRANSLATIONS: Record<string, Record<Exclude<Language, 'tr'>, string>> = {
  'Başlangıç Konumu': {
    en: 'Starting Position',
    ru: 'Начальная позиция',
    az: 'Başlanğıc Vəziyyəti',
  },
  'Klasik Açılış': {
    en: 'Classical Opening',
    ru: 'Классический дебют',
    az: 'Klassik Açılış',
  },
  'İtalyan Açılışı · Fritz Tuzağı': {
    en: 'Italian Game · Fritz Variation',
    ru: 'Итальянская партия · Ловушка Фрица',
    az: 'İtalyan Açılışı · Frits Tələsi',
  },
  'İki At Savunması · Kızarmış Ciğer Saldırısı': {
    en: 'Two Knights Defense · Fried Liver Attack',
    ru: 'Защита двух коней · Атака Фрида Ливера',
    az: 'İki At Müdafiəsi · Qızarmış Ciyər Hücumu',
  },
  'İtalyan Açılışı · İki At Savunması': {
    en: 'Italian Game · Two Knights Defense',
    ru: 'Итальянская партия · Защита двух коней',
    az: 'İtalyan Açılışı · İki At Müdafiəsi',
  },
  'İtalyan Açılışı · Giuoco Piano': {
    en: 'Italian Game · Giuoco Piano',
    ru: 'Итальянская партия · Тихая игра',
    az: 'İtalyan Açılışı · Giuoco Piano',
  },
  'İtalyan Açılışı': {
    en: 'Italian Game',
    ru: 'Итальянская партия',
    az: 'İtalyan Açılışı',
  },
  'İspanyol Açılışı (Ruy Lopez)': {
    en: 'Ruy Lopez (Spanish Opening)',
    ru: 'Испанская партия (Рюи Лопес)',
    az: 'İspan Açılışı (Ruy Lopes)',
  },
  'İskoç Açılışı': {
    en: 'Scotch Game',
    ru: 'Шотландская партия',
    az: 'Şotland Açılışı',
  },
  'Şah Gambiti': {
    en: "King's Gambit",
    ru: 'Королевский гамбит',
    az: 'Şah Qambiti',
  },
  'Açık Oyun (Şah Piyonu)': {
    en: "Open Game (King's Pawn)",
    ru: 'Открытый дебют',
    az: 'Açıq Oyun (Şah Piyadası)',
  },
  'Sicilya Savunması · Najdorf': {
    en: 'Sicilian Defense · Najdorf',
    ru: 'Сицилианская защита · Вариант Найдорфа',
    az: 'Siciliya Müdafiəsi · Naydorf',
  },
  'Sicilya Savunması': {
    en: 'Sicilian Defense',
    ru: 'Сицилианская защита',
    az: 'Siciliya Müdafiəsi',
  },
  'Fransız Savunması': {
    en: 'French Defense',
    ru: 'Французская защита',
    az: 'Fransız Müdafiəsi',
  },
  'Caro-Kann Savunması': {
    en: 'Caro-Kann Defense',
    ru: 'Защита Каро — Канн',
    az: 'Karo-Kann Müdafiəsi',
  },
  'İskandinav Savunması': {
    en: 'Scandinavian Defense',
    ru: 'Скандинавская защита',
    az: 'Skandinav Müdafiəsi',
  },
  'Vezir Gambiti': {
    en: "Queen's Gambit",
    ru: 'Ферзевый гамбит',
    az: 'Vəzir Qambiti',
  },
  'Londra Sistemi': {
    en: 'London System',
    ru: 'Лондонская система',
    az: 'London Sistemi',
  },
  'Şah Hint Savunması': {
    en: "King's Indian Defense",
    ru: 'Староиндийская защита',
    az: 'Şah Hind Müdafiəsi',
  },
  'Hint Savunması': {
    en: 'Indian Defense',
    ru: 'Индийская защита',
    az: 'Hind Müdafiəsi',
  },
  'Kapalı Oyun (Vezir Piyonu)': {
    en: "Closed Game (Queen's Pawn)",
    ru: 'Закрытый дебют',
    az: 'Qapalı Oyun (Vəzir Piyadası)',
  },
  'İngiliz Açılışı': {
    en: 'English Opening',
    ru: 'Английское начало',
    az: 'İngilis Açılışı',
  },
  'Réti Açılışı': {
    en: 'Réti Opening',
    ru: 'Дебют Рети',
    az: 'Reti Açılışı',
  },
  'Şah Piyonu Açılışı': {
    en: "King's Pawn Opening",
    ru: 'Дебют королевской пешки',
    az: 'Şah Piyadası Açılışı',
  },
  'Vezir Piyonu Açılışı': {
    en: "Queen's Pawn Opening",
    ru: 'Дебют ферзевой пешки',
    az: 'Vəzir Piyadası Açılışı',
  },
};

export function translateOpeningName(name: string, lang: Language): string {
  if (lang === 'tr') return name;
  return OPENING_TRANSLATIONS[name]?.[lang] ?? name;
}

export function formatOutcomeMessage(outcome: GameOutcome, lang: Language): string {
  const t = getTranslations(lang);
  switch (outcome.reason) {
    case 'checkmate':
      return outcome.winner === 'w' || outcome.winner === 'b'
        ? t.outcomeMessages.checkmate(outcome.winner)
        : outcome.message;
    case 'stalemate':
      return t.outcomeMessages.stalemate;
    case 'threefold_repetition':
      return t.outcomeMessages.threefold;
    case 'insufficient_material':
      return t.outcomeMessages.insufficient;
    case 'fifty_move_rule':
      return t.outcomeMessages.fiftyMove;
    case 'no_pieces':
      return outcome.winner === 'w' || outcome.winner === 'b'
        ? t.outcomeMessages.noPieces(outcome.winner)
        : outcome.message;
    case 'no_moves':
      return outcome.winner === 'w' || outcome.winner === 'b'
        ? t.outcomeMessages.noMoves(outcome.winner)
        : outcome.message;
    case 'fifteen_move_rule':
      return t.outcomeMessages.fifteenMove;
    case 'resignation':
      return outcome.winner === 'w' || outcome.winner === 'b'
        ? t.outcomeMessages.resignation(outcome.winner)
        : outcome.message;
    case 'timeout':
      return outcome.winner === 'w' || outcome.winner === 'b'
        ? t.outcomeMessages.timeout(outcome.winner)
        : outcome.message;
    case 'agreement':
      return t.outcomeMessages.agreement;
    case 'abandoned':
      return t.outcomeMessages.abandoned;
    default:
      return outcome.message;
  }
}

const SERVER_ERROR_MAP: Array<{ match: string; messages: Record<Language, string> }> = [
  {
    match: 'Oda bulunamadı',
    messages: {
      tr: 'Oda bulunamadı. Kodu kontrol edin.',
      en: 'Room not found. Please check the code.',
      ru: 'Комната не найдена. Проверьте код.',
      az: 'Otaq tapılmadı. Kodu yoxlayın.',
    },
  },
  {
    match: 'Geçersiz oda kodu',
    messages: {
      tr: 'Geçersiz oda kodu.',
      en: 'Invalid room code.',
      ru: 'Неверный код комнаты.',
      az: 'Yanlış otaq kodu.',
    },
  },
  {
    match: 'Hamle sırası rakipte',
    messages: {
      tr: 'Hamle sırası rakipte.',
      en: "It's your opponent's turn.",
      ru: 'Сейчас ход соперника.',
      az: 'Gediş növbəsi rəqibdədir.',
    },
  },
  {
    match: 'Oyun henüz başlamadı',
    messages: {
      tr: 'Oyun henüz başlamadı veya sona erdi.',
      en: 'Game has not started yet or has already ended.',
      ru: 'Игра ещё не началась или уже завершена.',
      az: 'Oyun hələ başlamayıb və ya artıq bitib.',
    },
  },
  {
    match: 'Odaya katılınamadı',
    messages: {
      tr: 'Odaya katılınamadı.',
      en: 'Could not join room.',
      ru: 'Не удалось войти в комнату.',
      az: 'Otağa qoşulmaq mümkün olmadı.',
    },
  },
];

export function translateServerError(message: string, lang: Language): string {
  if (lang === 'tr') return message;
  const hit = SERVER_ERROR_MAP.find((entry) => message.includes(entry.match));
  return hit ? hit.messages[lang] : message;
}
