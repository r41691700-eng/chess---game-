export interface GameSettings {
  sfxEnabled: boolean;
  sfxVolume: number;
  musicEnabled: boolean;
  musicVolume: number;
  showLegalMoves: boolean;
  showCoordinates: boolean;
  animatePieces: boolean;
  autoPromoteQueen: boolean;
}

export const DEFAULT_SETTINGS: GameSettings = {
  sfxEnabled: true,
  sfxVolume: 0.78,
  musicEnabled: true,
  musicVolume: 0.35,
  showLegalMoves: true,
  showCoordinates: true,
  animatePieces: true,
  autoPromoteQueen: false,
};

const SETTINGS_STORAGE_KEY = 'sahmat_settings_v1';

function clampVolume(val: unknown, fallback: number): number {
  if (typeof val !== 'number' || Number.isNaN(val)) return fallback;
  return Math.max(0, Math.min(1, val));
}

export function getSavedSettings(): GameSettings {
  if (typeof window === 'undefined') return { ...DEFAULT_SETTINGS };
  try {
    const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (!raw) return { ...DEFAULT_SETTINGS };
    const parsed = JSON.parse(raw) as Partial<GameSettings>;
    return {
      sfxEnabled:
        typeof parsed.sfxEnabled === 'boolean' ? parsed.sfxEnabled : DEFAULT_SETTINGS.sfxEnabled,
      sfxVolume: clampVolume(parsed.sfxVolume, DEFAULT_SETTINGS.sfxVolume),
      musicEnabled:
        typeof parsed.musicEnabled === 'boolean'
          ? parsed.musicEnabled
          : DEFAULT_SETTINGS.musicEnabled,
      musicVolume: clampVolume(parsed.musicVolume, DEFAULT_SETTINGS.musicVolume),
      showLegalMoves:
        typeof parsed.showLegalMoves === 'boolean'
          ? parsed.showLegalMoves
          : DEFAULT_SETTINGS.showLegalMoves,
      showCoordinates:
        typeof parsed.showCoordinates === 'boolean'
          ? parsed.showCoordinates
          : DEFAULT_SETTINGS.showCoordinates,
      animatePieces:
        typeof parsed.animatePieces === 'boolean'
          ? parsed.animatePieces
          : DEFAULT_SETTINGS.animatePieces,
      autoPromoteQueen:
        typeof parsed.autoPromoteQueen === 'boolean'
          ? parsed.autoPromoteQueen
          : DEFAULT_SETTINGS.autoPromoteQueen,
    };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export function saveSettings(settings: GameSettings): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  } catch {
    // ignore storage errors
  }
}
