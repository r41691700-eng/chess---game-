import test from 'node:test';
import assert from 'node:assert/strict';
import {
  formatOutcomeMessage,
  getTranslations,
  LANGUAGES,
  translateOpeningName,
  translateServerError,
} from './i18n';

test('supports Turkish, English, Russian, and Azerbaijani with Bot label', () => {
  assert.deepEqual(
    LANGUAGES.map((l) => l.id),
    ['tr', 'en', 'ru', 'az'],
  );
  assert.equal(getTranslations('tr').modeBot, 'Bot');
  assert.equal(getTranslations('en').modeBot, 'Bot');
  assert.equal(getTranslations('ru').modeBot, 'Бот');
  assert.equal(getTranslations('az').modeBot, 'Bot');

  assert.equal(getTranslations('tr').botPlayerLabel('Orta'), 'Bot (Orta)');
  assert.equal(getTranslations('en').botPlayerLabel('Medium'), 'Bot (Medium)');
  assert.equal(getTranslations('ru').botPlayerLabel('Средний'), 'Бот (Средний)');
  assert.equal(getTranslations('az').botPlayerLabel('Orta'), 'Bot (Orta)');

  assert.equal(getTranslations('tr').shashkiBotPlayerLabel('Orta'), 'Bot (Orta)');
  assert.equal(getTranslations('en').shashkiBotPlayerLabel('Medium'), 'Bot (Medium)');
  assert.equal(getTranslations('ru').shashkiBotPlayerLabel('Средний'), 'Бот (Средний)');
  assert.equal(getTranslations('az').shashkiBotPlayerLabel('Orta'), 'Bot (Orta)');
});

test('translates openings, outcomes, and server error messages across languages', () => {
  assert.equal(translateOpeningName('Başlangıç Konumu', 'en'), 'Starting Position');
  assert.equal(translateOpeningName('Başlangıç Konumu', 'ru'), 'Начальная позиция');
  assert.equal(translateOpeningName('Başlangıç Konumu', 'az'), 'Başlanğıc Vəziyyəti');

  const mateMsg = formatOutcomeMessage(
    { winner: 'w', reason: 'checkmate', message: 'Şah Mat! Beyaz kazandı.' },
    'en',
  );
  assert.equal(mateMsg, 'Checkmate! White wins.');

  assert.equal(getTranslations('tr').modeShashki, 'Şaşki');
  assert.equal(getTranslations('en').modeShashki, 'Shashki');
  assert.equal(getTranslations('ru').modeShashki, 'Шашки');
  assert.equal(getTranslations('az').modeShashki, 'Şaşki');

  const noPiecesMsg = formatOutcomeMessage(
    { winner: 'w', reason: 'no_pieces', message: 'Beyaz kazandı!' },
    'az',
  );
  assert.equal(noPiecesMsg, 'Rəqibin daşı qalmadı. Ağlar qazandı!');

  assert.equal(
    translateServerError('Oda bulunamadı. Kodu kontrol edin.', 'az'),
    'Otaq tapılmadı. Kodu yoxlayın.',
  );
});
