import type {
  BotDifficulty,
  GameOutcome,
  MoveRecord,
  PieceColor,
  ShashkiChainState,
  ShashkiStep,
} from './types';

export type { ShashkiChainState, ShashkiStep } from './types';

export interface ShashkiPiece {
  color: PieceColor;
  isKing: boolean;
}

export interface ShashkiBoardState {
  board: (ShashkiPiece | null)[][];
  turn: PieceColor;
  kingsOnlyPlies: number;
}

export interface ShashkiFullMove {
  from: string;
  to: string;
  steps: ShashkiStep[];
  capturedSquares: string[];
  notation: string;
  promoted: boolean;
}

export interface ShashkiStepTarget {
  to: string;
  isCapture: boolean;
  capturedSq?: string;
  promoted?: boolean;
}

const FILES = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'] as const;
const DIAG_DIRS: ReadonlyArray<readonly [number, number]> = [
  [-1, -1],
  [-1, 1],
  [1, -1],
  [1, 1],
];

export function isDarkSquare(r: number, c: number): boolean {
  return (r + c) % 2 === 1;
}

export function rcToSquare(r: number, c: number): string {
  return `${FILES[c]}${8 - r}`;
}

export function squareToRc(sq: string): { r: number; c: number } | null {
  if (sq.length !== 2) return null;
  const c = FILES.indexOf(sq[0] as (typeof FILES)[number]);
  const rank = Number(sq[1]);
  if (c < 0 || Number.isNaN(rank) || rank < 1 || rank > 8) return null;
  return { r: 8 - rank, c };
}

export function cloneBoard(board: (ShashkiPiece | null)[][]): (ShashkiPiece | null)[][] {
  return board.map((row) => row.map((cell) => (cell ? { ...cell } : null)));
}

export function createInitialShashkiState(): ShashkiBoardState {
  const board: (ShashkiPiece | null)[][] = Array.from({ length: 8 }, () =>
    Array<ShashkiPiece | null>(8).fill(null),
  );
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      if (!isDarkSquare(r, c)) continue;
      if (r <= 2) {
        board[r][c] = { color: 'b', isKing: false };
      } else if (r >= 5) {
        board[r][c] = { color: 'w', isKing: false };
      }
    }
  }
  return {
    board,
    turn: 'w',
    kingsOnlyPlies: 0,
  };
}

export const INITIAL_SHASHKI_STATE_KEY = serializeShashkiState(createInitialShashkiState());

export function serializeShashkiState(state: ShashkiBoardState): string {
  const rows: string[] = [];
  for (let r = 0; r < 8; r++) {
    let rowStr = '';
    for (let c = 0; c < 8; c++) {
      if (!isDarkSquare(r, c)) continue;
      const p = state.board[r][c];
      if (!p) rowStr += '.';
      else if (p.color === 'w') rowStr += p.isKing ? 'W' : 'w';
      else rowStr += p.isKing ? 'B' : 'b';
    }
    rows.push(rowStr);
  }
  return `${state.turn}:${state.kingsOnlyPlies}:${rows.join('/')}`;
}

export function deserializeShashkiState(key: string): ShashkiBoardState {
  const [turnPart, pliesPart, gridPart] = key.split(':');
  const turn: PieceColor = turnPart === 'b' ? 'b' : 'w';
  const kingsOnlyPlies = Number(pliesPart) || 0;
  const board: (ShashkiPiece | null)[][] = Array.from({ length: 8 }, () =>
    Array<ShashkiPiece | null>(8).fill(null),
  );
  const rowStrings = (gridPart ?? '').split('/');
  for (let r = 0; r < 8; r++) {
    const rowStr = rowStrings[r] ?? '....';
    let idx = 0;
    for (let c = 0; c < 8; c++) {
      if (!isDarkSquare(r, c)) continue;
      const ch = rowStr[idx++] ?? '.';
      if (ch === 'w') board[r][c] = { color: 'w', isKing: false };
      else if (ch === 'W') board[r][c] = { color: 'w', isKing: true };
      else if (ch === 'b') board[r][c] = { color: 'b', isKing: false };
      else if (ch === 'B') board[r][c] = { color: 'b', isKing: true };
    }
  }
  return { board, turn, kingsOnlyPlies };
}

function positionSignature(key: string): string {
  const parts = key.split(':');
  return `${parts[0]}:${parts[2] ?? ''}`;
}

function inBounds(r: number, c: number): boolean {
  return r >= 0 && r < 8 && c >= 0 && c < 8;
}

function promotionRowFor(color: PieceColor): number {
  return color === 'w' ? 0 : 7;
}

interface InternalStep {
  fromR: number;
  fromC: number;
  toR: number;
  toC: number;
  capR: number;
  capC: number;
  becameKing: boolean;
}

/**
 * Generates all complete mandatory capture sequences for the piece at (r, c)
 * obeying Russian / Azerbaijani Şaşki rules:
 * - Men capture forward AND backward (1 square over adjacent enemy onto empty behind).
 * - If a man lands on its back rank during a capture, it immediately promotes to Damka
 *   and continues capturing as a flying king if further captures exist.
 * - Flying Damka slides any number of empty squares, jumps exactly 1 enemy piece, and
 *   lands on any empty square beyond it. If any landing square permits continuation,
 *   the Damka MUST choose a continuing landing square.
 * - Captured pieces remain on the board as obstacles until the entire sequence ends,
 *   so no piece can be jumped twice or flown through.
 */
function findCaptureSequencesFrom(
  board: (ShashkiPiece | null)[][],
  r: number,
  c: number,
  color: PieceColor,
  isKing: boolean,
  capturedMask: Set<string>,
): InternalStep[][] {
  const sequences: InternalStep[][] = [];

  if (!isKing) {
    for (const [dr, dc] of DIAG_DIRS) {
      const midR = r + dr;
      const midC = c + dc;
      const landR = r + 2 * dr;
      const landC = c + 2 * dc;
      if (!inBounds(landR, landC)) continue;

      const midPiece = board[midR][midC];
      const capKey = `${midR},${midC}`;
      if (!midPiece || midPiece.color === color || capturedMask.has(capKey)) continue;
      if (board[landR][landC] !== null) continue;

      const promoted = landR === promotionRowFor(color);
      const nextIsKing = promoted;

      // Move piece temporarily on board while keeping captured enemy on midR, midC
      const piece = board[r][c]!;
      board[r][c] = null;
      board[landR][landC] = { color: piece.color, isKing: nextIsKing };
      capturedMask.add(capKey);

      const continuations = findCaptureSequencesFrom(
        board,
        landR,
        landC,
        color,
        nextIsKing,
        capturedMask,
      );

      capturedMask.delete(capKey);
      board[landR][landC] = null;
      board[r][c] = piece;

      const step: InternalStep = {
        fromR: r,
        fromC: c,
        toR: landR,
        toC: landC,
        capR: midR,
        capC: midC,
        becameKing: promoted,
      };

      if (continuations.length === 0) {
        sequences.push([step]);
      } else {
        for (const tail of continuations) {
          sequences.push([step, ...tail]);
        }
      }
    }
    return sequences;
  }

  // Flying King (Damka) capture search
  for (const [dr, dc] of DIAG_DIRS) {
    let scanR = r + dr;
    let scanC = c + dc;

    while (inBounds(scanR, scanC) && board[scanR][scanC] === null) {
      scanR += dr;
      scanC += dc;
    }

    if (!inBounds(scanR, scanC)) continue;
    const target = board[scanR][scanC];
    const capKey = `${scanR},${scanC}`;
    if (!target || target.color === color || capturedMask.has(capKey)) continue;

    // Collect all empty landing squares past the captured piece before any obstacle
    const landings: Array<{ landR: number; landC: number; tail: InternalStep[][] }> = [];
    let landR = scanR + dr;
    let landC = scanC + dc;

    const piece = board[r][c]!;
    board[r][c] = null;
    capturedMask.add(capKey);

    while (inBounds(landR, landC) && board[landR][landC] === null) {
      board[landR][landC] = { color: piece.color, isKing: true };
      const tail = findCaptureSequencesFrom(
        board,
        landR,
        landC,
        color,
        true,
        capturedMask,
      );
      board[landR][landC] = null;
      landings.push({ landR, landC, tail });
      landR += dr;
      landC += dc;
    }

    capturedMask.delete(capKey);
    board[r][c] = piece;

    const hasAnyContinuation = landings.some((l) => l.tail.length > 0);
    for (const l of landings) {
      if (hasAnyContinuation && l.tail.length === 0) {
        // Must pick a landing square that continues the capture chain
        continue;
      }
      const step: InternalStep = {
        fromR: r,
        fromC: c,
        toR: l.landR,
        toC: l.landC,
        capR: scanR,
        capC: scanC,
        becameKing: false,
      };
      if (l.tail.length === 0) {
        sequences.push([step]);
      } else {
        for (const t of l.tail) {
          sequences.push([step, ...t]);
        }
      }
    }
  }

  return sequences;
}

function internalSeqToFullMove(seq: InternalStep[]): ShashkiFullMove {
  const steps: ShashkiStep[] = seq.map((s) => ({
    from: rcToSquare(s.fromR, s.fromC),
    to: rcToSquare(s.toR, s.toC),
    capturedSq: rcToSquare(s.capR, s.capC),
    promoted: s.becameKing,
  }));
  const notation = [steps[0].from, ...steps.map((s) => s.to)].join(':');
  return {
    from: steps[0].from,
    to: steps[steps.length - 1].to,
    steps,
    capturedSquares: steps.map((s) => s.capturedSq!),
    notation,
    promoted: steps.some((s) => s.promoted),
  };
}

export function getLegalShashkiMoves(state: ShashkiBoardState): ShashkiFullMove[] {
  const boardCopy = cloneBoard(state.board);
  const captureMoves: ShashkiFullMove[] = [];

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = boardCopy[r][c];
      if (!piece || piece.color !== state.turn) continue;
      const seqs = findCaptureSequencesFrom(
        boardCopy,
        r,
        c,
        piece.color,
        piece.isKing,
        new Set<string>(),
      );
      for (const seq of seqs) {
        captureMoves.push(internalSeqToFullMove(seq));
      }
    }
  }

  // Mandatory capture rule: if any capture exists, non-capturing moves are illegal
  if (captureMoves.length > 0) {
    return captureMoves;
  }

  const quietMoves: ShashkiFullMove[] = [];
  const forwardDr = state.turn === 'w' ? -1 : 1;

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = state.board[r][c];
      if (!piece || piece.color !== state.turn) continue;

      if (!piece.isKing) {
        for (const dc of [-1, 1]) {
          const nr = r + forwardDr;
          const nc = c + dc;
          if (!inBounds(nr, nc) || state.board[nr][nc] !== null) continue;
          const from = rcToSquare(r, c);
          const to = rcToSquare(nr, nc);
          const promoted = nr === promotionRowFor(piece.color);
          quietMoves.push({
            from,
            to,
            steps: [{ from, to, promoted }],
            capturedSquares: [],
            notation: `${from}-${to}`,
            promoted,
          });
        }
      } else {
        for (const [dr, dc] of DIAG_DIRS) {
          let nr = r + dr;
          let nc = c + dc;
          while (inBounds(nr, nc) && state.board[nr][nc] === null) {
            const from = rcToSquare(r, c);
            const to = rcToSquare(nr, nc);
            quietMoves.push({
              from,
              to,
              steps: [{ from, to, promoted: false }],
              capturedSquares: [],
              notation: `${from}-${to}`,
              promoted: false,
            });
            nr += dr;
            nc += dc;
          }
        }
      }
    }
  }

  return quietMoves;
}

export function hasMandatoryCapture(state: ShashkiBoardState): boolean {
  const moves = getLegalShashkiMoves(state);
  return moves.length > 0 && moves[0].capturedSquares.length > 0;
}

export function getMandatoryCaptureSourceSquares(
  state: ShashkiBoardState,
  chain: ShashkiChainState | null,
): string[] {
  if (chain) return [chain.activeSquare];
  const moves = getLegalShashkiMoves(state);
  if (moves.length === 0 || moves[0].capturedSquares.length === 0) return [];
  return Array.from(new Set(moves.map((m) => m.from)));
}

/**
 * Returns interactive single-step legal destinations for `square`, respecting:
 * - active mid-turn chain jump (only next step of sequences matching prefix)
 * - mandatory capture rule on turn start
 */
export function getShashkiStepTargets(
  state: ShashkiBoardState,
  square: string,
  chain: ShashkiChainState | null,
): ShashkiStepTarget[] {
  if (chain) {
    if (square !== chain.activeSquare) return [];
    const rc = squareToRc(chain.activeSquare);
    if (!rc) return [];
    const boardCopy = cloneBoard(state.board);
    const capturedMask = new Set<string>();
    for (const cSq of chain.capturedSquares) {
      const cRc = squareToRc(cSq);
      if (cRc) capturedMask.add(`${cRc.r},${cRc.c}`);
    }
    const piece = boardCopy[rc.r][rc.c];
    if (!piece) return [];

    const seqs = findCaptureSequencesFrom(
      boardCopy,
      rc.r,
      rc.c,
      piece.color,
      piece.isKing,
      capturedMask,
    );
    const byDest = new Map<string, ShashkiStepTarget>();
    for (const seq of seqs) {
      const first = seq[0];
      const to = rcToSquare(first.toR, first.toC);
      if (!byDest.has(to)) {
        byDest.set(to, {
          to,
          isCapture: true,
          capturedSq: rcToSquare(first.capR, first.capC),
          promoted: first.becameKing,
        });
      }
    }
    return Array.from(byDest.values());
  }

  const moves = getLegalShashkiMoves(state);
  const byDest = new Map<string, ShashkiStepTarget>();
  for (const m of moves) {
    if (m.from !== square) continue;
    const first = m.steps[0];
    if (!byDest.has(first.to)) {
      byDest.set(first.to, {
        to: first.to,
        isCapture: Boolean(first.capturedSq),
        capturedSq: first.capturedSq,
        promoted: first.promoted,
      });
    }
  }
  return Array.from(byDest.values());
}

export function countShashkiPieces(state: ShashkiBoardState): {
  wMen: number;
  wKings: number;
  bMen: number;
  bKings: number;
  wTotal: number;
  bTotal: number;
} {
  let wMen = 0;
  let wKings = 0;
  let bMen = 0;
  let bKings = 0;
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const p = state.board[r][c];
      if (!p) continue;
      if (p.color === 'w') {
        if (p.isKing) wKings++;
        else wMen++;
      } else {
        if (p.isKing) bKings++;
        else bMen++;
      }
    }
  }
  return {
    wMen,
    wKings,
    bMen,
    bKings,
    wTotal: wMen + wKings,
    bTotal: bMen + bKings,
  };
}

export function evaluateShashkiOutcome(
  nextState: ShashkiBoardState,
  previousStateKeys: string[],
): GameOutcome | null {
  const counts = countShashkiPieces(nextState);
  if (counts.wTotal === 0) {
    return { winner: 'b', reason: 'no_pieces', message: 'Siyah kazandı!' };
  }
  if (counts.bTotal === 0) {
    return { winner: 'w', reason: 'no_pieces', message: 'Beyaz kazandı!' };
  }

  const legalNext = getLegalShashkiMoves(nextState);
  if (legalNext.length === 0) {
    const winner: PieceColor = nextState.turn === 'w' ? 'b' : 'w';
    return {
      winner,
      reason: 'no_moves',
      message: `${winner === 'w' ? 'Beyaz' : 'Siyah'} kazandı!`,
    };
  }

  if (nextState.kingsOnlyPlies >= 30) {
    return {
      winner: 'draw',
      reason: 'fifteen_move_rule',
      message: '15 hamle kuralı gereği beraberlik.',
    };
  }

  const currentSig = positionSignature(serializeShashkiState(nextState));
  let repCount = 1;
  for (const prevKey of previousStateKeys) {
    if (positionSignature(prevKey) === currentSig) {
      repCount++;
    }
  }
  if (repCount >= 3) {
    return {
      winner: 'draw',
      reason: 'threefold_repetition',
      message: 'Üç kez konum tekrarı ile beraberlik.',
    };
  }

  return null;
}

export function applyShashkiFullMove(
  state: ShashkiBoardState,
  move: ShashkiFullMove,
  plyCount = 0,
  previousStateKeys: string[] = [],
): {
  state: ShashkiBoardState;
  stateKey: string;
  moveRecord: MoveRecord;
  outcome: GameOutcome | null;
} {
  const nextBoard = cloneBoard(state.board);
  const startRc = squareToRc(move.from);
  const endRc = squareToRc(move.to);
  if (!startRc || !endRc) {
    throw new Error(`Invalid Shashki move squares: ${move.from} -> ${move.to}`);
  }

  const movingPiece = nextBoard[startRc.r][startRc.c];
  if (!movingPiece || movingPiece.color !== state.turn) {
    throw new Error(`No matching Shashki piece at ${move.from}`);
  }

  const wasKingInitially = movingPiece.isKing;
  const isKingAtEnd = wasKingInitially || move.promoted;

  nextBoard[startRc.r][startRc.c] = null;
  for (const capSq of move.capturedSquares) {
    const capRc = squareToRc(capSq);
    if (capRc) nextBoard[capRc.r][capRc.c] = null;
  }
  nextBoard[endRc.r][endRc.c] = { color: movingPiece.color, isKing: isKingAtEnd };

  const resetsCounter = !wasKingInitially || move.capturedSquares.length > 0;
  const nextState: ShashkiBoardState = {
    board: nextBoard,
    turn: state.turn === 'w' ? 'b' : 'w',
    kingsOnlyPlies: resetsCounter ? 0 : state.kingsOnlyPlies + 1,
  };

  const stateKey = serializeShashkiState(nextState);
  const outcome = evaluateShashkiOutcome(nextState, previousStateKeys);
  const nextPly = plyCount + 1;

  const moveRecord: MoveRecord = {
    ply: nextPly,
    moveNumber: Math.ceil(nextPly / 2),
    color: state.turn,
    san: move.notation,
    from: move.from,
    to: move.to,
    fen: stateKey,
    captured: move.capturedSquares.length > 0 ? 'p' : undefined,
    promotion: move.promoted ? 'q' : undefined,
    isCheck: false,
    isCheckmate: outcome !== null && outcome.winner !== 'draw',
    isCastle: false,
  };

  return {
    state: nextState,
    stateKey,
    moveRecord,
    outcome,
  };
}

export interface InteractiveStepResult {
  valid: boolean;
  completed: boolean;
  nextState: ShashkiBoardState;
  nextChain: ShashkiChainState | null;
  capturedNow: boolean;
  promotedNow: boolean;
  moveRecord?: MoveRecord;
  stateKey?: string;
  outcome?: GameOutcome | null;
}

/**
 * Applies a single interactive step (either a quiet move or one jump in a capture chain).
 * During a multi-jump chain, captured pieces stay on the board as marked obstacles until
 * the final jump finishes, matching authentic Russian/Azerbaijani Şaşki rules.
 */
export function applyInteractiveShashkiStep(
  state: ShashkiBoardState,
  fromSquare: string,
  toSquare: string,
  chain: ShashkiChainState | null,
  plyCount: number,
  previousStateKeys: string[],
): InteractiveStepResult {
  const targets = getShashkiStepTargets(state, fromSquare, chain);
  const match = targets.find((t) => t.to === toSquare);
  if (!match) {
    return {
      valid: false,
      completed: false,
      nextState: state,
      nextChain: chain,
      capturedNow: false,
      promotedNow: false,
    };
  }

  const fromRc = squareToRc(fromSquare);
  const toRc = squareToRc(toSquare);
  if (!fromRc || !toRc) {
    return {
      valid: false,
      completed: false,
      nextState: state,
      nextChain: chain,
      capturedNow: false,
      promotedNow: false,
    };
  }

  const nextBoard = cloneBoard(state.board);
  const movingPiece = nextBoard[fromRc.r][fromRc.c];
  if (!movingPiece) {
    return {
      valid: false,
      completed: false,
      nextState: state,
      nextChain: chain,
      capturedNow: false,
      promotedNow: false,
    };
  }

  const wasKingBeforeStep = movingPiece.isKing;
  const promotedNow = !wasKingBeforeStep && Boolean(match.promoted);
  const isKingAfterStep = wasKingBeforeStep || promotedNow;

  nextBoard[fromRc.r][fromRc.c] = null;
  nextBoard[toRc.r][toRc.c] = { color: movingPiece.color, isKing: isKingAfterStep };

  const stepObj: ShashkiStep = {
    from: fromSquare,
    to: toSquare,
    capturedSq: match.capturedSq,
    promoted: promotedNow,
  };

  if (match.isCapture && match.capturedSq) {
    const newCaptured = [...(chain?.capturedSquares ?? []), match.capturedSq];
    const newSteps = [...(chain?.steps ?? []), stepObj];
    const tempState: ShashkiBoardState = {
      board: nextBoard,
      turn: state.turn,
      kingsOnlyPlies: state.kingsOnlyPlies,
    };
    const nextChainCandidate: ShashkiChainState = {
      activeSquare: toSquare,
      startSquare: chain?.startSquare ?? fromSquare,
      steps: newSteps,
      capturedSquares: newCaptured,
      promotedDuringTurn: Boolean(chain?.promotedDuringTurn || promotedNow),
    };

    const furtherTargets = getShashkiStepTargets(tempState, toSquare, nextChainCandidate);
    if (furtherTargets.length > 0) {
      return {
        valid: true,
        completed: false,
        nextState: tempState,
        nextChain: nextChainCandidate,
        capturedNow: true,
        promotedNow,
      };
    }

    // Chain capture complete — remove all captured pieces now
    for (const cSq of newCaptured) {
      const cRc = squareToRc(cSq);
      if (cRc) nextBoard[cRc.r][cRc.c] = null;
    }

    const finishedState: ShashkiBoardState = {
      board: nextBoard,
      turn: state.turn === 'w' ? 'b' : 'w',
      kingsOnlyPlies: 0,
    };
    const stateKey = serializeShashkiState(finishedState);
    const outcome = evaluateShashkiOutcome(finishedState, previousStateKeys);
    const nextPly = plyCount + 1;
    const notation = [nextChainCandidate.startSquare, ...newSteps.map((s) => s.to)].join(':');

    const moveRecord: MoveRecord = {
      ply: nextPly,
      moveNumber: Math.ceil(nextPly / 2),
      color: state.turn,
      san: notation,
      from: nextChainCandidate.startSquare,
      to: toSquare,
      fen: stateKey,
      captured: 'p',
      promotion: nextChainCandidate.promotedDuringTurn ? 'q' : undefined,
      isCheck: false,
      isCheckmate: outcome !== null && outcome.winner !== 'draw',
      isCastle: false,
    };

    return {
      valid: true,
      completed: true,
      nextState: finishedState,
      nextChain: null,
      capturedNow: true,
      promotedNow,
      moveRecord,
      stateKey,
      outcome,
    };
  }

  // Quiet move completes immediately
  const finishedState: ShashkiBoardState = {
    board: nextBoard,
    turn: state.turn === 'w' ? 'b' : 'w',
    kingsOnlyPlies: !wasKingBeforeStep ? 0 : state.kingsOnlyPlies + 1,
  };
  const stateKey = serializeShashkiState(finishedState);
  const outcome = evaluateShashkiOutcome(finishedState, previousStateKeys);
  const nextPly = plyCount + 1;

  const moveRecord: MoveRecord = {
    ply: nextPly,
    moveNumber: Math.ceil(nextPly / 2),
    color: state.turn,
    san: `${fromSquare}-${toSquare}`,
    from: fromSquare,
    to: toSquare,
    fen: stateKey,
    promotion: promotedNow ? 'q' : undefined,
    isCheck: false,
    isCheckmate: outcome !== null && outcome.winner !== 'draw',
    isCastle: false,
  };

  return {
    valid: true,
    completed: true,
    nextState: finishedState,
    nextChain: null,
    capturedNow: false,
    promotedNow,
    moveRecord,
    stateKey,
    outcome,
  };
}

// ---------- Şaşki Bot Engine (Alpha-Beta Minimax) ----------

function evaluateShashkiPosition(state: ShashkiBoardState, perspective: PieceColor): number {
  let score = 0;
  let wCount = 0;
  let bCount = 0;

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const p = state.board[r][c];
      if (!p) continue;
      if (p.color === 'w') wCount++;
      else bCount++;

      const sign = p.color === perspective ? 1 : -1;
      if (p.isKing) {
        // Flying Damka is very strong in Şaşki (~3.2 men) + bonus for central diagonals
        const centerDist = Math.abs(3.5 - r) + Math.abs(3.5 - c);
        score += sign * (335 - centerDist * 6);
      } else {
        const advancement = p.color === 'w' ? 7 - r : r;
        const centerBonus = c >= 2 && c <= 5 ? 12 : c === 0 || c === 7 ? -6 : 4;
        const backRankBonus = (p.color === 'w' && r === 7) || (p.color === 'b' && r === 0) ? 16 : 0;
        score += sign * (100 + advancement * 7 + centerBonus + backRankBonus);
      }
    }
  }

  if (wCount === 0) return perspective === 'w' ? -100000 : 100000;
  if (bCount === 0) return perspective === 'b' ? -100000 : 100000;

  return score;
}

function applyMoveFast(state: ShashkiBoardState, move: ShashkiFullMove): ShashkiBoardState {
  const nextBoard = cloneBoard(state.board);
  const startRc = squareToRc(move.from)!;
  const endRc = squareToRc(move.to)!;
  const piece = nextBoard[startRc.r][startRc.c]!;
  const isKingAtEnd = piece.isKing || move.promoted;
  nextBoard[startRc.r][startRc.c] = null;
  for (const capSq of move.capturedSquares) {
    const cRc = squareToRc(capSq);
    if (cRc) nextBoard[cRc.r][cRc.c] = null;
  }
  nextBoard[endRc.r][endRc.c] = { color: piece.color, isKing: isKingAtEnd };

  const resets = !piece.isKing || move.capturedSquares.length > 0;
  return {
    board: nextBoard,
    turn: state.turn === 'w' ? 'b' : 'w',
    kingsOnlyPlies: resets ? 0 : state.kingsOnlyPlies + 1,
  };
}

function orderMoves(moves: ShashkiFullMove[]): ShashkiFullMove[] {
  return [...moves].sort((a, b) => {
    const scoreA = a.capturedSquares.length * 100 + (a.promoted ? 60 : 0);
    const scoreB = b.capturedSquares.length * 100 + (b.promoted ? 60 : 0);
    return scoreB - scoreA;
  });
}

function minimaxShashki(
  state: ShashkiBoardState,
  depth: number,
  alpha: number,
  beta: number,
  maximizing: boolean,
  botColor: PieceColor,
): number {
  const counts = countShashkiPieces(state);
  if (counts.wTotal === 0) return botColor === 'b' ? 90000 + depth : -90000 - depth;
  if (counts.bTotal === 0) return botColor === 'w' ? 90000 + depth : -90000 - depth;
  if (state.kingsOnlyPlies >= 30) return 0;

  const moves = getLegalShashkiMoves(state);
  if (moves.length === 0) {
    // Current side to move cannot move -> loses
    return state.turn === botColor ? -90000 - depth : 90000 + depth;
  }

  if (depth <= 0) {
    return evaluateShashkiPosition(state, botColor);
  }

  const ordered = orderMoves(moves);

  if (maximizing) {
    let best = -Infinity;
    for (const m of ordered) {
      const next = applyMoveFast(state, m);
      const val = minimaxShashki(next, depth - 1, alpha, beta, false, botColor);
      if (val > best) best = val;
      if (best > alpha) alpha = best;
      if (beta <= alpha) break;
    }
    return best;
  } else {
    let best = Infinity;
    for (const m of ordered) {
      const next = applyMoveFast(state, m);
      const val = minimaxShashki(next, depth - 1, alpha, beta, true, botColor);
      if (val < best) best = val;
      if (best < beta) beta = best;
      if (beta <= alpha) break;
    }
    return best;
  }
}

export function chooseShashkiBotMove(
  state: ShashkiBoardState,
  difficulty: BotDifficulty,
): ShashkiFullMove | null {
  const moves = orderMoves(getLegalShashkiMoves(state));
  if (moves.length === 0) return null;
  if (moves.length === 1) return moves[0];

  const botColor = state.turn;
  const depth = difficulty === 'easy' ? 2 : difficulty === 'medium' ? 4 : 5;

  const scored: Array<{ move: ShashkiFullMove; score: number }> = [];
  for (const m of moves) {
    const next = applyMoveFast(state, m);
    const val = minimaxShashki(next, depth - 1, -Infinity, Infinity, false, botColor);
    const jitter = difficulty === 'easy' ? (Math.random() - 0.5) * 45 : (Math.random() - 0.5) * 4;
    scored.push({ move: m, score: val + jitter });
  }

  scored.sort((a, b) => b.score - a.score);

  if (difficulty === 'easy') {
    const pool = scored.slice(0, Math.min(3, scored.length));
    return pool[Math.floor(Math.random() * pool.length)].move;
  }

  return scored[0].move;
}
