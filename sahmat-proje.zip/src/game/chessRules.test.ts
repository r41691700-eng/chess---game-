import test from 'node:test';
import assert from 'node:assert/strict';
import {
  applyMove,
  chooseBotMove,
  detectOpeningName,
  getBoardMatrix,
  getCapturedAndMaterial,
  getLegalMovesForSquare,
  INITIAL_FEN,
  isPromotionMove,
} from './chessRules';

test('getBoardMatrix parses FEN into 8x8 coordinates accurately', () => {
  const matrix = getBoardMatrix(INITIAL_FEN);
  assert.equal(matrix.length, 8);
  assert.deepEqual(matrix[0][0], { square: 'a8', type: 'r', color: 'b' });
  assert.deepEqual(matrix[0][4], { square: 'e8', type: 'k', color: 'b' });
  assert.equal(matrix[3][4], null);
  assert.deepEqual(matrix[6][4], { square: 'e2', type: 'p', color: 'w' });
  assert.deepEqual(matrix[7][7], { square: 'h1', type: 'r', color: 'w' });
});

test('initial position provides legal pawn moves on e2', () => {
  const moves = getLegalMovesForSquare(INITIAL_FEN, 'e2');
  const targets = moves.map((m) => m.to).sort();
  assert.deepEqual(targets, ['e3', 'e4']);
});

test('applyMove executes SAN moves and detects Scholar Mate checkmate', () => {
  let fen = INITIAL_FEN;
  const sequence = [
    { from: 'e2', to: 'e4' },
    { from: 'e7', to: 'e5' },
    { from: 'f1', to: 'c4' },
    { from: 'b8', to: 'c6' },
    { from: 'd1', to: 'h5' },
    { from: 'g8', to: 'f6' },
    { from: 'h5', to: 'f7' },
  ];

  let lastOutcome = null;
  let lastSan = '';
  for (let i = 0; i < sequence.length; i++) {
    const res = applyMove(fen, sequence[i], i);
    assert.equal(res.valid, true);
    fen = res.fen;
    lastOutcome = res.outcome ?? null;
    lastSan = res.move?.san ?? '';
  }

  assert.equal(lastSan, 'Qxf7#');
  assert.ok(lastOutcome);
  assert.equal(lastOutcome.winner, 'w');
  assert.equal(lastOutcome.reason, 'checkmate');
});

test('detectOpeningName identifies Italian Opening and Fritz Trap', () => {
  const fritzMoves = ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Nf6', 'Ng5', 'd5', 'exd5', 'Nd4'];
  assert.equal(detectOpeningName(fritzMoves), 'İtalyan Açılışı · Fritz Tuzağı');
  assert.equal(detectOpeningName(['e4', 'c5']), 'Sicilya Savunması');
  assert.equal(detectOpeningName([]), 'Başlangıç Konumu');
});

test('getCapturedAndMaterial computes captured pieces and material lead', () => {
  // White has captured black queen & e5 pawn missing
  const fenAfterCapture = 'rnb1kbnr/pppp1ppp/8/8/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 0 3';
  const summary = getCapturedAndMaterial(fenAfterCapture);
  assert.deepEqual(summary.capturedByWhite, ['q', 'p']);
  assert.deepEqual(summary.capturedByBlack, []);
  assert.equal(summary.whiteAdvantage, 10);
  assert.equal(summary.blackAdvantage, 0);
});

test('isPromotionMove detects pawn reaching back rank', () => {
  const promoFen = '4k3/P7/8/8/8/8/8/4K3 w - - 0 1';
  assert.equal(isPromotionMove(promoFen, 'a7', 'a8'), true);
  assert.equal(isPromotionMove(INITIAL_FEN, 'e2', 'e4'), false);
});

test('chooseBotMove returns a legal move and captures free queen on medium/hard', () => {
  // White to move, black queen on d5 is undefended and attackable by pawn c4 or knight c3
  const fen = 'rnb1kbnr/ppp1pppp/8/3q4/8/2N5/PPPPPPPP/R1BQKBNR w KQkq - 0 1';
  const botMove = chooseBotMove(fen, 'hard', () => 0);
  assert.ok(botMove);
  assert.equal(botMove.from, 'c3');
  assert.equal(botMove.to, 'd5');
});

test('applyMove detects threefold repetition across move FEN history', () => {
  let fen = INITIAL_FEN;
  const fens: string[] = [];
  const sequence = [
    { from: 'g1', to: 'f3' },
    { from: 'g8', to: 'f6' },
    { from: 'f3', to: 'g1' },
    { from: 'f6', to: 'g8' },
    { from: 'g1', to: 'f3' },
    { from: 'g8', to: 'f6' },
    { from: 'f3', to: 'g1' },
    { from: 'f6', to: 'g8' },
  ];

  let lastOutcome = null;
  for (let i = 0; i < sequence.length; i++) {
    const res = applyMove(fen, sequence[i], i, fens);
    assert.equal(res.valid, true);
    fens.push(res.fen);
    fen = res.fen;
    lastOutcome = res.outcome ?? null;
  }

  assert.ok(lastOutcome);
  assert.equal(lastOutcome.winner, 'draw');
  assert.equal(lastOutcome.reason, 'threefold_repetition');
});
