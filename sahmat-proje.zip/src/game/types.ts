export type PieceColor = 'w' | 'b';
export type PieceType = 'p' | 'n' | 'b' | 'r' | 'q' | 'k';
export type PromotionPiece = 'q' | 'r' | 'b' | 'n';

export type GameVariant = 'chess' | 'shashki';
export type GameMode = 'online' | 'bot';
export type BotDifficulty = 'easy' | 'medium' | 'hard';
export type SidePreference = 'w' | 'b' | 'random';

export interface ShashkiStep {
  from: string;
  to: string;
  capturedSq?: string;
  promoted?: boolean;
}

export interface ShashkiChainState {
  activeSquare: string;
  startSquare: string;
  steps: ShashkiStep[];
  capturedSquares: string[];
  promotedDuringTurn: boolean;
}

export type TimeControlKey = 'unlimited' | '3+2' | '5+0' | '10+0';

export interface TimeControlConfig {
  key: TimeControlKey;
  label: string;
  initialMs: number;
  incrementMs: number;
}

export const TIME_CONTROLS: Record<TimeControlKey, TimeControlConfig> = {
  '3+2': { key: '3+2', label: '3+2 Yıldırım', initialMs: 3 * 60 * 1000, incrementMs: 2000 },
  '5+0': { key: '5+0', label: '5+0 Yıldırım', initialMs: 5 * 60 * 1000, incrementMs: 0 },
  '10+0': { key: '10+0', label: '10+0 Hızlı', initialMs: 10 * 60 * 1000, incrementMs: 0 },
  unlimited: { key: 'unlimited', label: 'Süresiz', initialMs: 0, incrementMs: 0 },
};

export interface MoveRecord {
  ply: number;
  moveNumber: number;
  color: PieceColor;
  san: string;
  from: string;
  to: string;
  fen: string;
  captured?: PieceType;
  promotion?: PromotionPiece;
  isCheck: boolean;
  isCheckmate: boolean;
  isCastle: boolean;
}

export type GameResultReason =
  | 'checkmate'
  | 'stalemate'
  | 'threefold_repetition'
  | 'insufficient_material'
  | 'fifty_move_rule'
  | 'no_pieces'
  | 'no_moves'
  | 'fifteen_move_rule'
  | 'resignation'
  | 'agreement'
  | 'timeout'
  | 'abandoned';

export interface GameOutcome {
  winner: PieceColor | 'draw';
  reason: GameResultReason;
  message: string;
}

export interface PlayerSeat {
  name: string;
  connected: boolean;
}

export interface RoomPublicState {
  roomCode: string;
  variant: GameVariant;
  status: 'waiting' | 'playing' | 'finished';
  fen: string;
  turn: PieceColor;
  moves: MoveRecord[];
  timeControl: TimeControlKey;
  clocks: { w: number; b: number };
  lastMoveAt: number | null;
  players: {
    w: PlayerSeat | null;
    b: PlayerSeat | null;
  };
  spectatorCount: number;
  drawOfferFrom: PieceColor | null;
  rematchVotes: PieceColor[];
  outcome: GameOutcome | null;
  openingName: string;
  shashkiChain?: ShashkiChainState | null;
}

export type ClientWsMessage =
  | {
      type: 'room:create';
      playerName: string;
      variant: GameVariant;
      timeControl: TimeControlKey;
      sidePreference: SidePreference;
      playerToken: string;
    }
  | {
      type: 'room:join';
      roomCode: string;
      playerName: string;
      playerToken: string;
    }
  | {
      type: 'matchmaking:join';
      playerName: string;
      variant: GameVariant;
      timeControl: TimeControlKey;
      playerToken: string;
    }
  | {
      type: 'matchmaking:cancel';
    }
  | {
      type: 'game:move';
      roomCode: string;
      from: string;
      to: string;
      promotion?: PromotionPiece;
      playerToken: string;
    }
  | {
      type: 'game:resign';
      roomCode: string;
      playerToken: string;
    }
  | {
      type: 'game:draw_offer';
      roomCode: string;
      playerToken: string;
    }
  | {
      type: 'game:draw_respond';
      roomCode: string;
      accept: boolean;
      playerToken: string;
    }
  | {
      type: 'game:rematch';
      roomCode: string;
      playerToken: string;
    }
  | {
      type: 'room:leave';
      roomCode: string;
      playerToken: string;
    };

export type ServerWsMessage =
  | {
      type: 'room:joined';
      room: RoomPublicState;
      role: PieceColor | 'spectator';
      playerToken: string;
    }
  | {
      type: 'room:state';
      room: RoomPublicState;
    }
  | {
      type: 'matchmaking:waiting';
      timeControl: TimeControlKey;
      queuePosition: number;
    }
  | {
      type: 'matchmaking:canceled';
    }
  | {
      type: 'error';
      code: string;
      message: string;
    };
