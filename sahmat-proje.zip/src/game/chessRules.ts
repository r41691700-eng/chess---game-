import { Chess, type Move, type Square } from 'chess.js';
import type {
  BotDifficulty,
  GameOutcome,
  MoveRecord,
  PieceColor,
  PieceType,
  PromotionPiece,
} from './types';

export const INITIAL_FEN =
  'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

export interface BoardSquarePiece {
  square: string;
  type: PieceType;
  color: PieceColor;
}

export interface AppliedMoveResult {
  valid: boolean;
  fen: string;
  turn: PieceColor;
  move?: MoveRecord;
  outcome?: GameOutcome | null;
  isCheck: boolean;
  error?: string;
}

const PIECE_VALUES: Record<PieceType, number> = {
  p: 100,
  n: 320,
  b: 330,
  r: 500,
  q: 900,
  k: 20000,
};

const STARTING_COUNTS: Record<PieceType, number> = {
  p: 8,
  n: 2,
  b: 2,
  r: 2,
  q: 1,
  k: 1,
};

// Piece-square tables (from White's perspective: rank 8 at row 0, rank 1 at row 7)
const PAWN_PST = [
  [0, 0, 0, 0, 0, 0, 0, 0],
  [50, 50, 50, 50, 50, 50, 50, 50],
  [10, 10, 20, 30, 30, 20, 10, 10],
  [5, 5, 10, 25, 25, 10, 5, 5],
  [0, 0, 0, 22, 22, 0, 0, 0],
  [5, -5, -10, 0, 0, -10, -5, 5],
  [5, 10, 10, -20, -20, 10, 10, 5],
  [0, 0, 0, 0, 0, 0, 0, 0],
];

const KNIGHT_PST = [
  [-50, -40, -30, -30, -30, -30, -40, -50],
  [-40, -20, 0, 0, 0, 0, -20, -40],
  [-30, 0, 10, 15, 15, 10, 0, -30],
  [-30, 5, 15, 20, 20, 15, 5, -30],
  [-30, 0, 15, 20, 20, 15, 0, -30],
  [-30, 5, 10, 15, 15, 10, 5, -30],
  [-40, -20, 0, 5, 5, 0, -20, -40],
  [-50, -40, -30, -30, -30, -30, -40, -50],
];

const BISHOP_PST = [
  [-20, -10, -10, -10, -10, -10, -10, -20],
  [-10, 0, 0, 0, 0, 0, 0, -10],
  [-10, 0, 5, 10, 10, 5, 0, -10],
  [-10, 5, 5, 10, 10, 5, 5, -10],
  [-10, 0, 10, 10, 10, 10, 0, -10],
  [-10, 10, 10, 10, 10, 10, 10, -10],
  [-10, 5, 0, 0, 0, 0, 5, -10],
  [-20, -10, -10, -10, -10, -10, -10, -20],
];

const ROOK_PST = [
  [0, 0, 0, 0, 0, 0, 0, 0],
  [5, 10, 10, 10, 10, 10, 10, 5],
  [-5, 0, 0, 0, 0, 0, 0, -5],
  [-5, 0, 0, 0, 0, 0, 0, -5],
  [-5, 0, 0, 0, 0, 0, 0, -5],
  [-5, 0, 0, 0, 0, 0, 0, -5],
  [-5, 0, 0, 0, 0, 0, 0, -5],
  [0, 0, 0, 5, 5, 0, 0, 0],
];

const QUEEN_PST = [
  [-20, -10, -10, -5, -5, -10, -10, -20],
  [-10, 0, 0, 0, 0, 0, 0, -10],
  [-10, 0, 5, 5, 5, 5, 0, -10],
  [-5, 0, 5, 5, 5, 5, 0, -5],
  [0, 0, 5, 5, 5, 5, 0, -5],
  [-10, 5, 5, 5, 5, 5, 0, -10],
  [-10, 0, 5, 0, 0, 0, 0, -10],
  [-20, -10, -10, -5, -5, -10, -10, -20],
];

const KING_PST = [
  [-30, -40, -40, -50, -50, -40, -40, -30],
  [-30, -40, -40, -50, -50, -40, -40, -30],
  [-30, -40, -40, -50, -50, -40, -40, -30],
  [-30, -40, -40, -50, -50, -40, -40, -30],
  [-20, -30, -30, -40, -40, -30, -30, -20],
  [-10, -20, -20, -20, -20, -20, -20, -10],
  [20, 20, 0, 0, 0, 0, 20, 20],
  [20, 30, 10, 0, 0, 10, 30, 20],
];

const PST_MAP: Record<PieceType, number[][]> = {
  p: PAWN_PST,
  n: KNIGHT_PST,
  b: BISHOP_PST,
  r: ROOK_PST,
  q: QUEEN_PST,
  k: KING_PST,
};

export function getBoardMatrix(fen: string): (BoardSquarePiece | null)[][] {
  const files = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
  const matrix: (BoardSquarePiece | null)[][] = Array.from({ length: 8 }, () =>
    Array<BoardSquarePiece | null>(8).fill(null),
  );
  const placement = fen.split(' ')[0] ?? '';
  let row = 0;
  let col = 0;

  for (let i = 0; i < placement.length; i++) {
    const ch = placement[i];
    if (ch === '/') {
      row++;
      col = 0;
      if (row >= 8) break;
      continue;
    }
    const emptyCount = ch.charCodeAt(0) - 48;
    if (emptyCount >= 1 && emptyCount <= 8) {
      col += emptyCount;
    } else if (row < 8 && col < 8) {
      const lower = ch.toLowerCase() as PieceType;
      const color: PieceColor = ch >= 'A' && ch <= 'Z' ? 'w' : 'b';
      matrix[row][col] = {
        square: `${files[col]}${8 - row}`,
        type: lower,
        color,
      };
      col++;
    }
  }
  return matrix;
}

export function getTurn(fen: string): PieceColor {
  return fen.split(' ')[1] === 'b' ? 'b' : 'w';
}

export function getPieceAtSquare(
  fen: string,
  square: string,
): { type: PieceType; color: PieceColor } | null {
  const fileIdx = 'abcdefgh'.indexOf(square[0]);
  const rankNum = Number(square[1]);
  if (fileIdx < 0 || rankNum < 1 || rankNum > 8) return null;

  const targetRow = 8 - rankNum;
  const placement = fen.split(' ')[0];
  let row = 0;
  let col = 0;

  for (let i = 0; i < placement.length; i++) {
    const ch = placement[i];
    if (ch === '/') {
      row++;
      col = 0;
      if (row > targetRow) return null;
      continue;
    }
    if (row !== targetRow) continue;

    const emptyCount = Number(ch);
    if (!Number.isNaN(emptyCount) && emptyCount >= 1 && emptyCount <= 8) {
      col += emptyCount;
      if (col > fileIdx) return null;
    } else {
      if (col === fileIdx) {
        const lower = ch.toLowerCase() as PieceType;
        const color: PieceColor = ch === ch.toUpperCase() ? 'w' : 'b';
        return { type: lower, color };
      }
      col++;
    }
  }
  return null;
}

export function isInCheck(fen: string): boolean {
  const chess = new Chess(fen);
  return chess.inCheck();
}

export function getKingSquare(fen: string, color: PieceColor): string | null {
  const placement = fen.split(' ')[0];
  const files = 'abcdefgh';
  const targetChar = color === 'w' ? 'K' : 'k';
  let row = 0;
  let col = 0;

  for (let i = 0; i < placement.length; i++) {
    const ch = placement[i];
    if (ch === '/') {
      row++;
      col = 0;
      continue;
    }
    const emptyCount = Number(ch);
    if (!Number.isNaN(emptyCount) && emptyCount >= 1 && emptyCount <= 8) {
      col += emptyCount;
    } else {
      if (ch === targetChar) {
        return `${files[col]}${8 - row}`;
      }
      col++;
    }
  }
  return null;
}

export function getLegalMovesForSquare(
  fen: string,
  square: string,
): { to: string; isCapture: boolean; isPromotion: boolean }[] {
  const chess = new Chess(fen);
  const moves = chess.moves({ square: square as Square, verbose: true }) as Move[];
  const byTarget = new Map<string, { to: string; isCapture: boolean; isPromotion: boolean }>();
  for (const m of moves) {
    if (!byTarget.has(m.to)) {
      byTarget.set(m.to, {
        to: m.to,
        isCapture: Boolean(m.captured) || m.flags.includes('e'),
        isPromotion: Boolean(m.promotion),
      });
    }
  }
  return Array.from(byTarget.values());
}

export function isPromotionMove(fen: string, from: string, to: string): boolean {
  const chess = new Chess(fen);
  const moves = chess.moves({ square: from as Square, verbose: true }) as Move[];
  return moves.some((m) => m.to === to && Boolean(m.promotion));
}

function getPositionKey(fen: string): string {
  return fen.split(' ').slice(0, 4).join(' ');
}

export function evaluateGameOutcome(
  chess: Chess,
  priorPositionFens?: string[],
): GameOutcome | null {
  if (chess.isCheckmate()) {
    const winner: PieceColor = chess.turn() === 'w' ? 'b' : 'w';
    const winnerLabel = winner === 'w' ? 'Beyaz' : 'Siyah';
    return {
      winner,
      reason: 'checkmate',
      message: `Şah Mat! ${winnerLabel} kazandı.`,
    };
  }
  if (chess.isStalemate()) {
    return {
      winner: 'draw',
      reason: 'stalemate',
      message: 'Pat! Oyun berabere sonuçlandı.',
    };
  }

  let isThreefold = chess.isThreefoldRepetition();
  if (!isThreefold && priorPositionFens && priorPositionFens.length >= 4) {
    const currentKey = getPositionKey(chess.fen());
    let count = 1; // current position after move
    if (getPositionKey(INITIAL_FEN) === currentKey) {
      count++;
    }
    for (const prevFen of priorPositionFens) {
      if (getPositionKey(prevFen) === currentKey) {
        count++;
        if (count >= 3) {
          isThreefold = true;
          break;
        }
      }
    }
  }

  if (isThreefold) {
    return {
      winner: 'draw',
      reason: 'threefold_repetition',
      message: 'Üç kez konum tekrarı nedeniyle oyun berabere.',
    };
  }
  if (chess.isInsufficientMaterial()) {
    return {
      winner: 'draw',
      reason: 'insufficient_material',
      message: 'Yetersiz materyal nedeniyle oyun berabere.',
    };
  }
  if (chess.isDraw()) {
    return {
      winner: 'draw',
      reason: 'fifty_move_rule',
      message: '50 hamle kuralı gereği oyun berabere.',
    };
  }
  return null;
}

export function applyMove(
  fen: string,
  moveInput: { from: string; to: string; promotion?: PromotionPiece },
  plyIndex: number,
  priorPositionFens?: string[],
): AppliedMoveResult {
  try {
    const chess = new Chess(fen);
    const moveNumber = Math.floor(plyIndex / 2) + 1;
    const movingColor = chess.turn() as PieceColor;

    const result = chess.move({
      from: moveInput.from,
      to: moveInput.to,
      promotion: moveInput.promotion ?? 'q',
    });

    if (!result) {
      return {
        valid: false,
        fen,
        turn: movingColor,
        isCheck: chess.inCheck(),
        error: 'Geçersiz hamle.',
      };
    }

    const nextFen = chess.fen();
    const outcome = evaluateGameOutcome(chess, priorPositionFens);
    const isCheck = chess.inCheck();

    const record: MoveRecord = {
      ply: plyIndex + 1,
      moveNumber,
      color: movingColor,
      san: result.san,
      from: result.from,
      to: result.to,
      fen: nextFen,
      captured: result.captured as PieceType | undefined,
      promotion: result.promotion as PromotionPiece | undefined,
      isCheck,
      isCheckmate: chess.isCheckmate(),
      isCastle: result.flags.includes('k') || result.flags.includes('q'),
    };

    return {
      valid: true,
      fen: nextFen,
      turn: chess.turn() as PieceColor,
      move: record,
      outcome,
      isCheck,
    };
  } catch {
    return {
      valid: false,
      fen,
      turn: getTurn(fen),
      isCheck: isInCheck(fen),
      error: 'Geçersiz hamle.',
    };
  }
}

export interface CapturedSummary {
  capturedByWhite: PieceType[];
  capturedByBlack: PieceType[];
  whiteAdvantage: number;
  blackAdvantage: number;
}

export function getCapturedAndMaterial(fen: string): CapturedSummary {
  const counts: Record<PieceColor, Record<PieceType, number>> = {
    w: { p: 0, n: 0, b: 0, r: 0, q: 0, k: 0 },
    b: { p: 0, n: 0, b: 0, r: 0, q: 0, k: 0 },
  };

  const placement = fen.split(' ')[0] ?? '';
  for (let i = 0; i < placement.length; i++) {
    const ch = placement[i];
    if (ch === '/') continue;
    const emptyCount = ch.charCodeAt(0) - 48;
    if (emptyCount >= 1 && emptyCount <= 8) continue;
    const color: PieceColor = ch >= 'A' && ch <= 'Z' ? 'w' : 'b';
    const type = ch.toLowerCase() as PieceType;
    if (counts[color][type] !== undefined) {
      counts[color][type] += 1;
    }
  }

  const order: PieceType[] = ['q', 'r', 'b', 'n', 'p'];
  const capturedByWhite: PieceType[] = [];
  const capturedByBlack: PieceType[] = [];

  for (const type of order) {
    const missingBlack = Math.max(0, STARTING_COUNTS[type] - counts.b[type]);
    for (let i = 0; i < missingBlack; i++) capturedByWhite.push(type);
    const missingWhite = Math.max(0, STARTING_COUNTS[type] - counts.w[type]);
    for (let i = 0; i < missingWhite; i++) capturedByBlack.push(type);
  }

  let whiteMaterial = 0;
  let blackMaterial = 0;
  for (const type of order) {
    const val = Math.round(PIECE_VALUES[type] / 100);
    whiteMaterial += counts.w[type] * val;
    blackMaterial += counts.b[type] * val;
  }

  const diff = whiteMaterial - blackMaterial;
  return {
    capturedByWhite,
    capturedByBlack,
    whiteAdvantage: diff > 0 ? diff : 0,
    blackAdvantage: diff < 0 ? -diff : 0,
  };
}

const OPENING_BOOK: Array<{ prefix: string[]; name: string }> = [
  { prefix: ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Nf6', 'Ng5', 'd5', 'exd5', 'Nd4'], name: 'İtalyan Açılışı · Fritz Tuzağı' },
  { prefix: ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Nf6', 'Ng5'], name: 'İki At Savunması · Kızarmış Ciğer Saldırısı' },
  { prefix: ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Nf6'], name: 'İtalyan Açılışı · İki At Savunması' },
  { prefix: ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Bc5'], name: 'İtalyan Açılışı · Giuoco Piano' },
  { prefix: ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4'], name: 'İtalyan Açılışı' },
  { prefix: ['e4', 'e5', 'Nf3', 'Nc6', 'Bb5'], name: 'İspanyol Açılışı (Ruy Lopez)' },
  { prefix: ['e4', 'e5', 'Nf3', 'Nc6', 'd4'], name: 'İskoç Açılışı' },
  { prefix: ['e4', 'e5', 'f4'], name: 'Şah Gambiti' },
  { prefix: ['e4', 'e5'], name: 'Açık Oyun (Şah Piyonu)' },
  { prefix: ['e4', 'c5', 'Nf3', 'd6', 'd4', 'cxd4', 'Nxd4', 'Nf6', 'Nc3', 'a6'], name: 'Sicilya Savunması · Najdorf' },
  { prefix: ['e4', 'c5'], name: 'Sicilya Savunması' },
  { prefix: ['e4', 'e6'], name: 'Fransız Savunması' },
  { prefix: ['e4', 'c6'], name: 'Caro-Kann Savunması' },
  { prefix: ['e4', 'd5'], name: 'İskandinav Savunması' },
  { prefix: ['d4', 'd5', 'c4'], name: 'Vezir Gambiti' },
  { prefix: ['d4', 'd5', 'Bf4'], name: 'Londra Sistemi' },
  { prefix: ['d4', 'Nf6', 'c4', 'g6'], name: 'Şah Hint Savunması' },
  { prefix: ['d4', 'Nf6', 'c4', 'e6'], name: 'Hint Savunması' },
  { prefix: ['d4', 'd5'], name: 'Kapalı Oyun (Vezir Piyonu)' },
  { prefix: ['c4'], name: 'İngiliz Açılışı' },
  { prefix: ['Nf3'], name: 'Réti Açılışı' },
  { prefix: ['e4'], name: 'Şah Piyonu Açılışı' },
  { prefix: ['d4'], name: 'Vezir Piyonu Açılışı' },
];

export function detectOpeningName(sans: string[]): string {
  if (sans.length === 0) return 'Başlangıç Konumu';
  for (const entry of OPENING_BOOK) {
    if (sans.length >= entry.prefix.length) {
      let match = true;
      for (let i = 0; i < entry.prefix.length; i++) {
        if (sans[i] !== entry.prefix[i]) {
          match = false;
          break;
        }
      }
      if (match) return entry.name;
    }
  }
  return 'Klasik Açılış';
}

function evaluateBoard(chess: Chess): number {
  if (chess.isCheckmate()) {
    return chess.turn() === 'w' ? -99999 : 99999;
  }
  if (chess.isDraw() || chess.isStalemate()) {
    return 0;
  }

  let score = 0;
  const board = chess.board();
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = board[r][c];
      if (!piece) continue;
      const type = piece.type as PieceType;
      const base = PIECE_VALUES[type];
      const pstRow = piece.color === 'w' ? r : 7 - r;
      const positional = PST_MAP[type][pstRow][c];
      const total = base + positional;
      score += piece.color === 'w' ? total : -total;
    }
  }
  return score;
}

function orderMoves(moves: Move[]): Move[] {
  return moves.sort((a, b) => {
    const scoreA =
      (a.captured ? PIECE_VALUES[a.captured as PieceType] * 10 : 0) +
      (a.promotion ? 800 : 0) +
      (a.san.includes('+') ? 40 : 0);
    const scoreB =
      (b.captured ? PIECE_VALUES[b.captured as PieceType] * 10 : 0) +
      (b.promotion ? 800 : 0) +
      (b.san.includes('+') ? 40 : 0);
    return scoreB - scoreA;
  });
}

function minimax(
  chess: Chess,
  depth: number,
  alpha: number,
  beta: number,
  maximizingWhite: boolean,
  deadline: number,
): number {
  if (depth === 0 || chess.isGameOver() || Date.now() >= deadline) {
    const evalScore = evaluateBoard(chess);
    if (evalScore > 90000) return evalScore + depth;
    if (evalScore < -90000) return evalScore - depth;
    return evalScore;
  }

  const moves = orderMoves(chess.moves({ verbose: true }) as Move[]);

  if (maximizingWhite) {
    let best = -Infinity;
    for (const move of moves) {
      chess.move(move);
      const val = minimax(chess, depth - 1, alpha, beta, false, deadline);
      chess.undo();
      if (val > best) best = val;
      if (val > alpha) alpha = val;
      if (beta <= alpha || Date.now() >= deadline) break;
    }
    return best;
  } else {
    let best = Infinity;
    for (const move of moves) {
      chess.move(move);
      const val = minimax(chess, depth - 1, alpha, beta, true, deadline);
      chess.undo();
      if (val < best) best = val;
      if (val < beta) beta = val;
      if (beta <= alpha || Date.now() >= deadline) break;
    }
    return best;
  }
}

export function chooseBotMove(
  fen: string,
  difficulty: BotDifficulty,
  rng: () => number = Math.random,
): { from: string; to: string; promotion?: PromotionPiece } | null {
  const chess = new Chess(fen);
  const moves = orderMoves(chess.moves({ verbose: true }) as Move[]);
  if (moves.length === 0) return null;

  const isWhite = chess.turn() === 'w';
  const maxDepth = difficulty === 'easy' ? 1 : difficulty === 'medium' ? 2 : 3;
  const budgetMs = difficulty === 'hard' ? 220 : 120;
  const deadline = Date.now() + budgetMs;

  let bestScored: Array<{ move: Move; score: number }> = [];

  for (let depth = 1; depth <= maxDepth; depth++) {
    const scored: Array<{ move: Move; score: number }> = [];
    let aborted = false;

    for (const move of moves) {
      if (depth > 1 && Date.now() >= deadline) {
        aborted = true;
        break;
      }
      chess.move(move);
      const score = minimax(chess, depth - 1, -Infinity, Infinity, !isWhite, deadline);
      chess.undo();
      scored.push({ move, score });
    }

    if (!aborted && scored.length === moves.length) {
      scored.sort((a, b) => (isWhite ? b.score - a.score : a.score - b.score));
      bestScored = scored;
      // Put best move first for next iteration
      moves.sort((a, b) => {
        if (a === scored[0].move) return -1;
        if (b === scored[0].move) return 1;
        return 0;
      });
    } else {
      break;
    }
  }

  if (bestScored.length === 0) {
    const fallback = moves[0];
    return {
      from: fallback.from,
      to: fallback.to,
      promotion: fallback.promotion as PromotionPiece | undefined,
    };
  }

  if (difficulty === 'easy') {
    const bestScore = bestScored[0].score;
    if (Math.abs(bestScore) > 90000) {
      const m = bestScored[0].move;
      return { from: m.from, to: m.to, promotion: m.promotion as PromotionPiece | undefined };
    }
    const pool = bestScored.slice(0, Math.min(4, bestScored.length));
    const picked = pool[Math.floor(rng() * pool.length)].move;
    return {
      from: picked.from,
      to: picked.to,
      promotion: picked.promotion as PromotionPiece | undefined,
    };
  }

  const topScore = bestScored[0].score;
  const tied = bestScored.filter((s) => Math.abs(s.score - topScore) <= 4);
  const chosen = tied[Math.floor(rng() * tied.length)].move;
  return {
    from: chosen.from,
    to: chosen.to,
    promotion: chosen.promotion as PromotionPiece | undefined,
  };
}
