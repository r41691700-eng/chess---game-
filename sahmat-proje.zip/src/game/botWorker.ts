import { chooseBotMove } from './chessRules';
import {
  chooseShashkiBotMove,
  deserializeShashkiState,
  type ShashkiFullMove,
} from './shashkiRules';
import type { BotDifficulty, PromotionPiece } from './types';

export type BotWorkerRequest =
  | {
      kind?: 'chess';
      requestId: number;
      fen: string;
      difficulty: BotDifficulty;
    }
  | {
      kind: 'shashki';
      requestId: number;
      stateKey: string;
      difficulty: BotDifficulty;
    };

export type BotWorkerResponse =
  | {
      kind?: 'chess';
      requestId: number;
      move: { from: string; to: string; promotion?: PromotionPiece } | null;
    }
  | {
      kind: 'shashki';
      requestId: number;
      move: ShashkiFullMove | null;
    };

self.onmessage = (event: MessageEvent<BotWorkerRequest>) => {
  const data = event.data;
  if (data.kind === 'shashki') {
    const state = deserializeShashkiState(data.stateKey);
    const move = chooseShashkiBotMove(state, data.difficulty);
    self.postMessage({
      kind: 'shashki',
      requestId: data.requestId,
      move,
    } satisfies BotWorkerResponse);
    return;
  }

  const move = chooseBotMove(data.fen, data.difficulty);
  self.postMessage({
    kind: 'chess',
    requestId: data.requestId,
    move,
  } satisfies BotWorkerResponse);
};
