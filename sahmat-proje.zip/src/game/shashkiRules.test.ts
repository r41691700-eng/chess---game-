import test from 'node:test';
import assert from 'node:assert/strict';
import {
  applyInteractiveShashkiStep,
  applyShashkiFullMove,
  chooseShashkiBotMove,
  countShashkiPieces,
  createInitialShashkiState,
  deserializeShashkiState,
  getLegalShashkiMoves,
  getShashkiStepTargets,
  serializeShashkiState,
  squareToRc,
  type ShashkiBoardState,
} from './shashkiRules';

function emptyState(turn: 'w' | 'b' = 'w', kingsOnlyPlies = 0): ShashkiBoardState {
  return {
    board: Array.from({ length: 8 }, () => Array(8).fill(null)),
    turn,
    kingsOnlyPlies,
  };
}

function putPiece(
  state: ShashkiBoardState,
  square: string,
  color: 'w' | 'b',
  isKing = false,
) {
  const rc = squareToRc(square);
  assert.ok(rc, `Invalid square ${square}`);
  state.board[rc.r][rc.c] = { color, isKing };
}

test('initial Şaşki board places 12 white and 12 black pieces on dark squares', () => {
  const state = createInitialShashkiState();
  const counts = countShashkiPieces(state);
  assert.equal(counts.wMen, 12);
  assert.equal(counts.bMen, 12);
  assert.equal(counts.wKings, 0);
  assert.equal(counts.bKings, 0);
  assert.equal(state.turn, 'w');

  // Verify screenshot setup: b8, d8, f8, h8 have black; a1, c1, e1, g1 have white; a8 is empty light
  const b8 = squareToRc('b8')!;
  const a8 = squareToRc('a8')!;
  const a1 = squareToRc('a1')!;
  assert.equal(state.board[a8.r][a8.c], null);
  assert.equal(state.board[b8.r][b8.c]?.color, 'b');
  assert.equal(state.board[a1.r][a1.c]?.color, 'w');

  // Initial opening has 7 quiet forward moves for White
  const moves = getLegalShashkiMoves(state);
  assert.equal(moves.length, 7);
});

test('regular piece captures forward and backward, and mandatory capture forbids quiet moves', () => {
  const state = emptyState('w');
  putPiece(state, 'c3', 'w');
  putPiece(state, 'a1', 'w'); // a1 could normally move quietly to b2 if no capture existed
  putPiece(state, 'b2', 'b'); // backward capture available for c3 -> a1? No, a1 is occupied! Put enemy at d2 -> backward to e1
  putPiece(state, 'd2', 'b');
  putPiece(state, 'a3', 'w'); // a3 could quietly move to b4

  // Reset cleanly: White on c3, Black on d2 (backward capture c3:e1), White on g3 (could move f4/h4)
  const s = emptyState('w');
  putPiece(s, 'c3', 'w');
  putPiece(s, 'd2', 'b');
  putPiece(s, 'g3', 'w');

  const moves = getLegalShashkiMoves(s);
  assert.equal(moves.length, 1);
  assert.equal(moves[0].notation, 'c3:e1');
  assert.deepEqual(moves[0].capturedSquares, ['d2']);
});

test('multi-capture chain forbids jumping the same captured piece twice and finishes on chain end', () => {
  const state = emptyState('w');
  putPiece(state, 'c3', 'w');
  putPiece(state, 'd4', 'b');
  putPiece(state, 'f6', 'b');

  // Interactive step 1: c3 -> e5 (cannot stop here because f6 jump remains)
  const step1 = applyInteractiveShashkiStep(state, 'c3', 'e5', null, 0, []);
  assert.equal(step1.valid, true);
  assert.equal(step1.completed, false);
  assert.equal(step1.nextChain?.activeSquare, 'e5');
  // Captured piece on d4 remains on board until turn completes
  const d4 = squareToRc('d4')!;
  assert.equal(step1.nextState.board[d4.r][d4.c]?.color, 'b');

  // Step 2: e5 -> g7 completes sequence and removes both d4 and f6
  const step2 = applyInteractiveShashkiStep(
    step1.nextState,
    'e5',
    'g7',
    step1.nextChain,
    0,
    [],
  );
  assert.equal(step2.valid, true);
  assert.equal(step2.completed, true);
  assert.equal(step2.moveRecord?.san, 'c3:e5:g7');
  assert.equal(step2.nextState.board[d4.r][d4.c], null);
  const f6 = squareToRc('f6')!;
  assert.equal(step2.nextState.board[f6.r][f6.c], null);
  assert.equal(step2.nextState.turn, 'b');
});

test('mid-capture promotion to Damka immediately grants flying king captures in same turn', () => {
  const state = emptyState('w');
  putPiece(state, 'd6', 'w');
  putPiece(state, 'e7', 'b');
  putPiece(state, 'h6', 'b');

  // d6 jumps e7 -> lands f8 (back rank -> immediately Damka!), then as Damka flies down h6 -> captures h6?
  // Wait: f8 -> g7 -> h6 is diagonal (+1, +1)! So landing g7 can capture h6? Wait: h6 is at edge (col 7), can't land past h6.
  // Put second enemy on g7? No, f8 -> g7 is blocked, put enemy on d6? Put enemy on g7? Better: f8 -> e7 is already captured,
  // put second enemy on g7? Can't land past g7 on h6 if h6 is empty -> put second enemy on g7 with h6 empty! No wait: f8 is (0,5), g7 is (1,6), h6 is (2,7) — h6 is empty!
  const s = emptyState('w');
  putPiece(s, 'd6', 'w');
  putPiece(s, 'c7', 'b'); // d6 jumps c7 -> b8 (back rank, r=0, c=1)
  putPiece(s, 'e5', 'b'); // From b8, flying Damka flies b8 -> c7(already captured? wait)
  // Better: put enemies on e7 (r=1,c=4) and f4 (r=4,c=5): Wait from f8 (r=0,c=5) to h6 (r=2,c=7):
  // Let's use d6 -> e7 -> f8 (promoted!), then along (1,1): g7 is enemy, h6 is empty!
  const s2 = emptyState('w');
  putPiece(s2, 'd6', 'w');
  putPiece(s2, 'e7', 'b');
  putPiece(s2, 'g7', 'b'); // wait b8 -> d6? Let's calculate exact squares!
  // d6 = (2,3). Jump over e7 = (1,4) -> land f8 = (0,5).
  // From f8 = (0,5), diagonal (+1,+1) goes to g7=(1,6), h6=(2,7). So if g7 has Black piece, Damka jumps g7 to h6.
  // Even better, test LONG-RANGE flying capture right after promotion:
  // a5=(3,0)? No, b6=(2,1) jumps c7=(1,2) -> lands d8=(0,3).
  // From d8=(0,3), diagonal (+1,+1) goes e7=(1,4), f6=(2,5), g5=(3,6), h4=(4,7).
  // Put Black piece on f6=(2,5) and leave g5,h4 empty -> a newly crowned Damka on d8 flies across empty e7 to jump f6!
  const midPromo = emptyState('w');
  putPiece(midPromo, 'b6', 'w');
  putPiece(midPromo, 'c7', 'b');
  putPiece(midPromo, 'f6', 'b');

  const moves = getLegalShashkiMoves(midPromo);
  assert.ok(moves.some((m) => m.notation === 'b6:d8:g5'));
  assert.ok(moves.some((m) => m.notation === 'b6:d8:h4'));
  // Every legal move must be a 2-step capture because Damka on d8 CAN jump f6!
  assert.ok(moves.every((m) => m.capturedSquares.length === 2));
});

test('flying Damka must land on a square that continues capture when one exists', () => {
  const state = emptyState('w');
  putPiece(state, 'a1', 'w', true); // White Damka
  putPiece(state, 'c3', 'b'); // Damka jumps c3 -> can land d4, e5, f6, g7, h8
  putPiece(state, 'g5', 'b'); // From e5 (r=3,c=4), Damka can jump g5 (r=3? wait: e5=(3,4), f6=(2,5), g5=(3,6) no)
  // From f6=(2,5), diagonal (+1,+1) is g5=(3,6), h4=(4,7)!
  const s = emptyState('w');
  putPiece(s, 'a1', 'w', true);
  putPiece(s, 'c3', 'b');
  putPiece(s, 'g5', 'b'); // f6 -> g5 -> h4!

  const targets = getShashkiStepTargets(s, 'a1', null).map((t) => t.to);
  assert.deepEqual(targets, ['f6']); // d4, e5, g7, h8 do not continue capture, so ONLY f6 is legal!
});

test('stalemated player loses and 15-move kings-only rule draws', () => {
  // Blocked Black piece on a7 behind White pieces -> Black has 0 legal moves -> White wins
  const blocked = emptyState('b');
  putPiece(blocked, 'a7', 'b');
  putPiece(blocked, 'b6', 'w');
  putPiece(blocked, 'c5', 'w');

  const res = applyShashkiFullMove(
    { ...blocked, turn: 'w' },
    getLegalShashkiMoves({ ...blocked, turn: 'w' })[0],
  );
  // Let's construct direct outcome check where Black has 0 moves
  const blockedBlack = emptyState('w');
  putPiece(blockedBlack, 'a1', 'b'); // wait b moves down (+1), on row 7 (rank 1) can't move!Wait black at rank 1 would already be promoted unless edge test; use a7 blocked by b6 and c5
  const s = emptyState('w');
  putPiece(s, 'h8', 'b');
  putPiece(s, 'f6', 'w');
  putPiece(s, 'h6', 'w');
  // White plays h6-g7, locking Black's h8 behind g7 and f6 -> Black has 0 legal moves -> White wins!
  const moveToBlock = getLegalShashkiMoves(s).find((m) => m.notation === 'h6-g7');
  assert.ok(moveToBlock);
  const blockedResult = applyShashkiFullMove(s, moveToBlock!, 0, []);
  assert.equal(blockedResult.outcome?.winner, 'w');
  assert.equal(blockedResult.outcome?.reason, 'no_moves');

  // 15-move kings-only draw (30 plies)
  const kingDraw = emptyState('w', 29);
  putPiece(kingDraw, 'a1', 'w', true);
  putPiece(kingDraw, 'h8', 'b', true);
  const kingMove = getLegalShashkiMoves(kingDraw)[0];
  const drawResult = applyShashkiFullMove(kingDraw, kingMove, 30, []);
  assert.equal(drawResult.outcome?.winner, 'draw');
  assert.equal(drawResult.outcome?.reason, 'fifteen_move_rule');
});

test('serialize/deserialize round-trips state and Bot returns legal move across difficulties', () => {
  const initial = createInitialShashkiState();
  const key = serializeShashkiState(initial);
  const parsed = deserializeShashkiState(key);
  assert.equal(serializeShashkiState(parsed), key);

  for (const diff of ['easy', 'medium', 'hard'] as const) {
    const botMove = chooseShashkiBotMove(initial, diff);
    assert.ok(botMove);
    const legal = getLegalShashkiMoves(initial);
    assert.ok(legal.some((m) => m.notation === botMove.notation));
  }
});
