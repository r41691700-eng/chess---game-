import test from 'node:test';
import assert from 'node:assert/strict';
import { RoomManager } from './roomManager';
import { INITIAL_SHASHKI_STATE_KEY, createInitialShashkiState, serializeShashkiState } from './shashkiRules';

test('room creation, joining, turn enforcement, and legal move sync', () => {
  const manager = new RoomManager();
  const created = manager.createRoom({
    playerName: 'Ahmet',
    playerToken: 'tok-w',
    timeControl: '10+0',
    sidePreference: 'w',
    now: 1000,
    rng: () => 0.1,
  });

  assert.equal(created.role, 'w');
  assert.equal(created.room.status, 'waiting');
  const code = created.room.roomCode;

  // Cannot move while waiting for opponent
  const premature = manager.makeMove({
    roomCode: code,
    playerToken: 'tok-w',
    from: 'e2',
    to: 'e4',
    now: 1500,
  });
  assert.equal(premature.ok, false);

  // Opponent joins
  const joined = manager.joinRoom({
    roomCode: code,
    playerName: 'Mehmet',
    playerToken: 'tok-b',
    now: 2000,
  });
  assert.equal(joined.ok, true);
  assert.equal(joined.role, 'b');
  assert.equal(joined.room?.status, 'playing');

  // Black cannot move out of turn
  const wrongTurn = manager.makeMove({
    roomCode: code,
    playerToken: 'tok-b',
    from: 'e7',
    to: 'e5',
    now: 2500,
  });
  assert.equal(wrongTurn.ok, false);

  // White plays e4
  const move1 = manager.makeMove({
    roomCode: code,
    playerToken: 'tok-w',
    from: 'e2',
    to: 'e4',
    now: 3000,
  });
  assert.equal(move1.ok, true);
  assert.equal(move1.room?.turn, 'b');
  assert.equal(move1.room?.moves.length, 1);
  assert.equal(move1.room?.moves[0].san, 'e4');
});

test('matchmaking pairs two players in the same time control queue', () => {
  const manager = new RoomManager();
  const first = manager.enqueueMatchmaking({
    playerName: 'Zeynep',
    playerToken: 't1',
    timeControl: '5+0',
  });
  assert.equal(first.matched, false);

  const second = manager.enqueueMatchmaking({
    playerName: 'Can',
    playerToken: 't2',
    timeControl: '5+0',
    rng: () => 0.2,
  });
  assert.equal(second.matched, true);
  if (second.matched) {
    assert.equal(second.room.status, 'playing');
    assert.equal(second.room.timeControl, '5+0');
    assert.ok(second.room.players.w);
    assert.ok(second.room.players.b);
  }
});

test('draw offer, acceptance, and rematch swap sides cleanly', () => {
  const manager = new RoomManager();
  const created = manager.createRoom({
    playerName: 'Oyuncu A',
    playerToken: 'a',
    timeControl: 'unlimited',
    sidePreference: 'w',
  });
  const code = created.room.roomCode;
  manager.joinRoom({ roomCode: code, playerName: 'Oyuncu B', playerToken: 'b' });

  const offer = manager.offerDraw({ roomCode: code, playerToken: 'a' });
  assert.equal(offer.ok, true);
  assert.equal(offer.room?.drawOfferFrom, 'w');

  const accept = manager.respondDraw({ roomCode: code, playerToken: 'b', accept: true });
  assert.equal(accept.ok, true);
  assert.equal(accept.room?.status, 'finished');
  assert.equal(accept.room?.outcome?.winner, 'draw');

  const vote1 = manager.voteRematch({ roomCode: code, playerToken: 'a' });
  assert.equal(vote1.room?.status, 'finished');
  assert.equal(vote1.rematchStarted, false);
  const vote2 = manager.voteRematch({ roomCode: code, playerToken: 'b' });
  assert.equal(vote2.room?.status, 'playing');
  assert.equal(vote2.rematchStarted, true);
  assert.equal(vote2.room?.players.w?.name, 'Oyuncu B');
  assert.equal(vote2.room?.players.b?.name, 'Oyuncu A');
  assert.equal(manager.getPlayerRole(code, 'b'), 'w');
  assert.equal(manager.getPlayerRole(code, 'a'), 'b');
});

test('reconnection restores seat using same playerToken', () => {
  const manager = new RoomManager();
  const created = manager.createRoom({
    playerName: 'Ali',
    playerToken: 'token-ali',
    timeControl: '10+0',
    sidePreference: 'w',
  });
  const code = created.room.roomCode;
  manager.setConnectionStatus(code, 'token-ali', false);
  const rejoined = manager.joinRoom({
    roomCode: code,
    playerName: 'Ali',
    playerToken: 'token-ali',
  });
  assert.equal(rejoined.ok, true);
  assert.equal(rejoined.role, 'w');
  assert.equal(rejoined.room?.players.w?.connected, true);
});

test('leaveRoom removes empty waiting rooms and pruneStaleRooms cleans abandoned games', () => {
  const manager = new RoomManager();
  const created = manager.createRoom({
    playerName: 'Deniz',
    playerToken: 'tok-deniz',
    timeControl: '5+0',
    sidePreference: 'w',
    now: 1000,
  });
  assert.equal(manager.getRoomCount(), 1);
  manager.leaveRoom(created.room.roomCode, 'tok-deniz', 1500);
  assert.equal(manager.getRoomCount(), 0);

  const created2 = manager.createRoom({
    playerName: 'Ege',
    playerToken: 'tok-ege',
    timeControl: '5+0',
    sidePreference: 'w',
    now: 1000,
  });
  manager.joinRoom({
    roomCode: created2.room.roomCode,
    playerName: 'Bora',
    playerToken: 'tok-bora',
    now: 2000,
  });
  manager.setConnectionStatus(created2.room.roomCode, 'tok-ege', false, 3000);
  manager.setConnectionStatus(created2.room.roomCode, 'tok-bora', false, 3000);
  assert.equal(manager.pruneStaleRooms(5000, 1000), 1);
  assert.equal(manager.getRoomCount(), 0);
});

test('online room detects threefold repetition draw accurately', () => {
  const manager = new RoomManager();
  const created = manager.createRoom({
    playerName: 'Beyaz',
    playerToken: 'tw',
    timeControl: 'unlimited',
    sidePreference: 'w',
  });
  const code = created.room.roomCode;
  manager.joinRoom({ roomCode: code, playerName: 'Siyah', playerToken: 'tb' });

  const seq = [
    ['tw', 'g1', 'f3'],
    ['tb', 'g8', 'f6'],
    ['tw', 'f3', 'g1'],
    ['tb', 'f6', 'g8'],
    ['tw', 'g1', 'f3'],
    ['tb', 'g8', 'f6'],
    ['tw', 'f3', 'g1'],
    ['tb', 'f6', 'g8'],
  ] as const;

  let finalRoom = created.room;
  for (const [token, from, to] of seq) {
    const res = manager.makeMove({ roomCode: code, playerToken: token, from, to });
    assert.equal(res.ok, true);
    finalRoom = res.room!;
  }

  assert.equal(finalRoom.status, 'finished');
  assert.equal(finalRoom.outcome?.winner, 'draw');
  assert.equal(finalRoom.outcome?.reason, 'threefold_repetition');
});

test('online Shashki matchmaking isolates variants and rooms enforce multi-jump chain captures', () => {
  const manager = new RoomManager();

  // Chess queue and Shashki queue must not match each other
  const chessWait = manager.enqueueMatchmaking({
    playerName: 'ChessP1',
    playerToken: 'cp1',
    variant: 'chess',
    timeControl: '5+0',
  });
  assert.equal(chessWait.matched, false);

  const shashkiWait = manager.enqueueMatchmaking({
    playerName: 'ShashkiP1',
    playerToken: 'sp1',
    variant: 'shashki',
    timeControl: '5+0',
  });
  assert.equal(shashkiWait.matched, false);

  const shashkiMatch = manager.enqueueMatchmaking({
    playerName: 'ShashkiP2',
    playerToken: 'sp2',
    variant: 'shashki',
    timeControl: '5+0',
    rng: () => 0.2,
  });
  assert.equal(shashkiMatch.matched, true);
  if (!shashkiMatch.matched) return;
  assert.equal(shashkiMatch.room.variant, 'shashki');
  assert.equal(shashkiMatch.room.fen, INITIAL_SHASHKI_STATE_KEY);

  // Use a deterministic private room with 3+2 increment to test multi-jump & increment timing
  const created = manager.createRoom({
    playerName: 'Aynur',
    playerToken: 'sw',
    variant: 'shashki',
    timeControl: '3+2',
    sidePreference: 'w',
    now: 1000,
    rng: () => 0.1,
  });
  assert.equal(created.room.variant, 'shashki');
  assert.equal(created.room.fen, INITIAL_SHASHKI_STATE_KEY);
  const code = created.room.roomCode;
  manager.joinRoom({ roomCode: code, playerName: 'Murad', playerToken: 'sb', now: 1500 });

  // Illegal chess-like move must be rejected
  const illegal = manager.makeMove({
    roomCode: code,
    playerToken: 'sw',
    from: 'e2',
    to: 'e4',
    now: 2000,
  });
  assert.equal(illegal.ok, false);

  // Setup sequence leading to mandatory double jump e5 -> c3 -> a1 by Black
  const setupMoves: Array<[string, string, string, number]> = [
    ['sw', 'c3', 'd4', 2000],
    ['sb', 'h6', 'g5', 3000],
    ['sw', 'b2', 'c3', 4000],
    ['sb', 'g7', 'h6', 5000],
    ['sw', 'a1', 'b2', 6000],
    ['sb', 'd6', 'e5', 7000],
    ['sw', 'c3', 'b4', 8000],
  ];

  for (const [token, from, to, now] of setupMoves) {
    const res = manager.makeMove({ roomCode: code, playerToken: token, from, to, now });
    assert.equal(res.ok, true, `Expected ${from}->${to} to succeed: ${res.error}`);
    assert.equal(res.room?.shashkiChain, null);
  }

  const clockBeforeChain = manager.getRoomState(code, 8000)!.clocks.b;

  // Step 1 of double capture: e5 -> c3 (mid-chain: turn stays Black, moves not yet incremented, no increment awarded yet)
  const step1 = manager.makeMove({
    roomCode: code,
    playerToken: 'sb',
    from: 'e5',
    to: 'c3',
    now: 9000,
  });
  assert.equal(step1.ok, true);
  assert.equal(step1.room?.turn, 'b');
  assert.equal(step1.room?.moves.length, 7);
  assert.deepEqual(step1.room?.shashkiChain, {
    activeSquare: 'c3',
    startSquare: 'e5',
    capturedSquares: ['d4'],
    promotedDuringTurn: false,
    steps: [{ from: 'e5', to: 'c3', capturedSq: 'd4', promoted: false }],
  });
  assert.equal(step1.room?.clocks.b, clockBeforeChain - 1000);

  // White cannot move mid-chain
  const prematureWhite = manager.makeMove({
    roomCode: code,
    playerToken: 'sw',
    from: 'b4',
    to: 'a5',
    now: 9200,
  });
  assert.equal(prematureWhite.ok, false);

  // Step 2 of double capture: c3 -> a1 completes the chain and awards the +2s increment once
  const step2 = manager.makeMove({
    roomCode: code,
    playerToken: 'sb',
    from: 'c3',
    to: 'a1',
    now: 10000,
  });
  assert.equal(step2.ok, true);
  assert.equal(step2.room?.turn, 'w');
  assert.equal(step2.room?.shashkiChain, null);
  assert.equal(step2.room?.moves.length, 8);
  assert.equal(step2.room?.moves[7]?.san, 'e5:c3:a1');
  assert.equal(step2.room?.clocks.b, clockBeforeChain - 2000 + 2000);

  // Resign & Rematch resets to initial Shashki board and swaps sides
  const resigned = manager.resign({ roomCode: code, playerToken: 'sw', now: 11000 });
  assert.equal(resigned.ok, true);
  assert.equal(resigned.room?.status, 'finished');

  manager.voteRematch({ roomCode: code, playerToken: 'sw', now: 11500 });
  const rematch = manager.voteRematch({ roomCode: code, playerToken: 'sb', now: 12000 });
  assert.equal(rematch.rematchStarted, true);
  assert.equal(rematch.room?.variant, 'shashki');
  assert.equal(rematch.room?.status, 'playing');
  assert.equal(rematch.room?.fen, INITIAL_SHASHKI_STATE_KEY);
  assert.equal(rematch.room?.shashkiChain, null);
  assert.equal(rematch.room?.moves.length, 0);
  assert.equal(manager.getPlayerRole(code, 'sb'), 'w');
  assert.equal(manager.getPlayerRole(code, 'sw'), 'b');
});

test('createInitialShashkiState key matches INITIAL_SHASHKI_STATE_KEY', () => {
  assert.equal(serializeShashkiState(createInitialShashkiState()), INITIAL_SHASHKI_STATE_KEY);
});

