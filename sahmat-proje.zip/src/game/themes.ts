export type AppThemeId =
  | 'cream'
  | 'daylight'
  | 'sky'
  | 'sage'
  | 'blush'
  | 'lavender'
  | 'honey'
  | 'obsidian'
  | 'custom';

export interface AppThemeOption {
  id: Exclude<AppThemeId, 'custom'>;
  label: string;
  swatch: string;
  isDark: boolean;
}

export const APP_THEMES: AppThemeOption[] = [
  { id: 'cream', label: 'Klasik Krem', swatch: '#F2EBD9', isDark: false },
  { id: 'daylight', label: 'Saf Beyaz', swatch: '#F7F8FA', isDark: false },
  { id: 'sky', label: 'Gök Mavisi', swatch: '#E7F0F8', isDark: false },
  { id: 'sage', label: 'Adaçayı', swatch: '#E7F1EA', isDark: false },
  { id: 'blush', label: 'Gül Kurusu', swatch: '#F6E9E7', isDark: false },
  { id: 'lavender', label: 'Lavanta', swatch: '#EEEAF6', isDark: false },
  { id: 'honey', label: 'Kehribar', swatch: '#FAF0DA', isDark: false },
  { id: 'obsidian', label: 'Gece Abanozu', swatch: '#191715', isDark: true },
];

export interface ThemeSelection {
  id: AppThemeId;
  customHex: string;
}

const THEME_STORAGE_KEY = 'sahmat_theme_v2';

export function getSavedThemeSelection(): ThemeSelection {
  if (typeof window === 'undefined') return { id: 'cream', customHex: '#E8EFF5' };
  try {
    const raw = localStorage.getItem(THEME_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<ThemeSelection>;
      if (parsed.id && (parsed.id === 'custom' || APP_THEMES.some((t) => t.id === parsed.id))) {
        return {
          id: parsed.id,
          customHex: /^#[0-9A-Fa-f]{6}$/.test(parsed.customHex ?? '')
            ? (parsed.customHex as string)
            : '#E8EFF5',
        };
      }
    }
  } catch {
    // ignore storage errors
  }
  return { id: 'cream', customHex: '#E8EFF5' };
}

export function saveThemeSelection(selection: ThemeSelection): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(THEME_STORAGE_KEY, JSON.stringify(selection));
  } catch {
    // ignore storage errors
  }
}

function hexToRgb(hex: string): { r: number; g: number; b: number } {
  const clean = hex.replace('#', '');
  const n = parseInt(clean, 16);
  return {
    r: (n >> 16) & 255,
    g: (n >> 8) & 255,
    b: n & 255,
  };
}

function mixHex(hexA: string, hexB: string, weightB: number): string {
  const a = hexToRgb(hexA);
  const b = hexToRgb(hexB);
  const w = Math.max(0, Math.min(1, weightB));
  const r = Math.round(a.r * (1 - w) + b.r * w);
  const g = Math.round(a.g * (1 - w) + b.g * w);
  const bl = Math.round(a.b * (1 - w) + b.b * w);
  return `#${[r, g, bl].map((v) => v.toString(16).padStart(2, '0')).join('')}`;
}

function getRelativeLuminance(hex: string): number {
  const { r, g, b } = hexToRgb(hex);
  const toLinear = (c: number) => {
    const s = c / 255;
    return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
  };
  return 0.2126 * toLinear(r) + 0.7152 * toLinear(g) + 0.0722 * toLinear(b);
}

export function getCustomThemeCssVars(customHex: string): Record<string, string> {
  const safeHex = /^#[0-9A-Fa-f]{6}$/.test(customHex) ? customHex : '#E8EFF5';
  const lum = getRelativeLuminance(safeHex);
  const isDark = lum < 0.36;

  if (!isDark) {
    return {
      '--app-bg': safeHex,
      '--app-glow-1': 'rgba(255, 255, 255, 0.72)',
      '--app-glow-2': 'rgba(0, 0, 0, 0.05)',
      '--surface-panel': mixHex(safeHex, '#FFFFFF', 0.65),
      '--surface-elevated': mixHex(safeHex, '#FFFFFF', 0.38),
      '--surface-muted': mixHex(safeHex, '#2B2118', 0.07),
      '--surface-input': '#FFFFFF',
      '--surface-hover': mixHex(safeHex, '#2B2118', 0.11),
      '--ink-primary': '#1E1915',
      '--ink-secondary': '#53473C',
      '--ink-muted': '#76685B',
      '--border-strong': 'rgba(34, 26, 20, 0.28)',
      '--border-subtle': 'rgba(34, 26, 20, 0.13)',
      '--btn-primary-bg': '#2A211A',
      '--btn-primary-hover': '#3E3127',
      '--btn-primary-text': '#FBF8F1',
      '--btn-accent-bg': '#6E4B32',
      '--btn-accent-hover': '#5B3D28',
      '--btn-accent-text': '#FBF8F1',
      '--accent-gold': '#6E4B32',
      '--board-mat': '#EDE4D2',
      '--board-coord': 'rgba(43, 33, 24, 0.78)',
      '--danger-bg': 'rgba(153, 45, 34, 0.1)',
      '--danger-border': 'rgba(153, 45, 34, 0.32)',
      '--danger-text': '#8B261B',
    };
  }

  return {
    '--app-bg': safeHex,
    '--app-glow-1': 'rgba(255, 244, 224, 0.08)',
    '--app-glow-2': 'rgba(0, 0, 0, 0.4)',
    '--surface-panel': mixHex(safeHex, '#FFFFFF', 0.07),
    '--surface-elevated': mixHex(safeHex, '#FFFFFF', 0.11),
    '--surface-muted': mixHex(safeHex, '#000000', 0.18),
    '--surface-input': mixHex(safeHex, '#000000', 0.25),
    '--surface-hover': mixHex(safeHex, '#FFFFFF', 0.16),
    '--ink-primary': '#F4EFE6',
    '--ink-secondary': '#CFC6B8',
    '--ink-muted': '#9F9587',
    '--border-strong': 'rgba(232, 214, 184, 0.3)',
    '--border-subtle': 'rgba(232, 214, 184, 0.14)',
    '--btn-primary-bg': '#D4B37A',
    '--btn-primary-hover': '#E0C28C',
    '--btn-primary-text': '#181411',
    '--btn-accent-bg': '#755037',
    '--btn-accent-hover': '#885D40',
    '--btn-accent-text': '#FAF6EE',
    '--accent-gold': '#D4B37A',
    '--board-mat': '#E8DEC7',
    '--board-coord': 'rgba(43, 33, 24, 0.85)',
    '--danger-bg': 'rgba(205, 78, 62, 0.18)',
    '--danger-border': 'rgba(224, 114, 100, 0.45)',
    '--danger-text': '#F6ACA2',
  };
}
