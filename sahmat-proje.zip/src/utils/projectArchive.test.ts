import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import zlib from 'node:zlib';
import { buildZipArchive, collectProjectFiles, crc32 } from './projectArchive';

test('buildZipArchive produces a valid PKZIP archive with decompressable entries', () => {
  const sampleText = '<!doctype html><html><title>ŞAHMAT</title></html>';
  const entries = [
    { name: 'index.html', data: Buffer.from(sampleText, 'utf8') },
    { name: 'src/app.ts', data: Buffer.from('export const ok = true;\n', 'utf8') },
  ];

  const zip = buildZipArchive(entries);

  // Local file header signature at start
  assert.equal(zip.readUInt32LE(0), 0x04034b50);
  // End of central directory signature at end (no comment)
  assert.equal(zip.readUInt32LE(zip.length - 22), 0x06054b50);
  assert.equal(zip.readUInt16LE(zip.length - 12), 2);

  // Decompress first entry payload
  const nameLen = zip.readUInt16LE(26);
  const compressedLen = zip.readUInt32LE(18);
  const payloadOffset = 30 + nameLen;
  const restored = zlib.inflateRawSync(zip.subarray(payloadOffset, payloadOffset + compressedLen));
  assert.equal(restored.toString('utf8'), sampleText);
  assert.equal(zip.readUInt32LE(14), crc32(restored));
});

test('collectProjectFiles includes core app files and omits secrets or build folders', () => {
  const rootDir = path.resolve(process.cwd());
  const files = collectProjectFiles(rootDir);
  const names = new Set(files.map((f) => f.name));

  assert.equal(names.has('index.html'), true);
  assert.equal(names.has('package.json'), true);
  assert.equal(names.has('server.ts'), true);
  assert.equal(names.has('src/App.tsx'), true);
  assert.equal(names.has('.env'), false);
  assert.equal([...names].some((n) => n.startsWith('node_modules/')), false);
  assert.equal([...names].some((n) => n.startsWith('.aistudio/')), false);
});
