let audioCtx: AudioContext | null = null;
let noiseBuffer: AudioBuffer | null = null;

let masterMuted = false;
let sfxEnabled = true;
let sfxVolume = 0.78;
let musicEnabled = true;
let musicVolume = 0.35;

// Background ambient music scheduler state
let musicTimer: number | null = null;
let musicDelayTimer: number | null = null;
let musicBusGain: GainNode | null = null;
let musicStepIndex = 0;
let musicPlaying = false;

function getCtx(allowWhenSfxOff = false): AudioContext | null {
  if (typeof window === 'undefined' || masterMuted) return null;
  if (!allowWhenSfxOff && !sfxEnabled) return null;
  if (!audioCtx) {
    const Ctor =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return null;
    audioCtx = new Ctor();
  }
  if (audioCtx.state === 'suspended') {
    void audioCtx.resume();
  }
  return audioCtx;
}

function getNoiseBuffer(ctx: AudioContext): AudioBuffer {
  if (noiseBuffer && noiseBuffer.sampleRate === ctx.sampleRate) {
    return noiseBuffer;
  }
  const length = Math.floor(ctx.sampleRate * 0.04);
  const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < length; i++) {
    data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.0045));
  }
  noiseBuffer = buffer;
  return buffer;
}

export function setSoundMuted(nextMuted: boolean): void {
  masterMuted = nextMuted;
  if (musicBusGain && audioCtx) {
    const target = !masterMuted && musicEnabled ? musicVolume * 0.16 : 0;
    musicBusGain.gain.setTargetAtTime(target, audioCtx.currentTime, 0.06);
  }
  if (masterMuted) {
    stopBackgroundMusic();
  }
}

export function isSoundMuted(): boolean {
  return masterMuted;
}

export function warmupAudio(): void {
  const ctx = getCtx(true);
  if (!ctx) return;
  getNoiseBuffer(ctx);
}

export function applyAudioSettings(params: {
  sfxEnabled: boolean;
  sfxVolume: number;
  musicEnabled: boolean;
  musicVolume: number;
}): void {
  sfxEnabled = params.sfxEnabled;
  sfxVolume = Math.max(0, Math.min(1, params.sfxVolume));
  musicEnabled = params.musicEnabled;
  musicVolume = Math.max(0, Math.min(1, params.musicVolume));

  if (musicBusGain && audioCtx) {
    const target = !masterMuted && musicEnabled ? musicVolume * 0.16 : 0;
    musicBusGain.gain.setTargetAtTime(target, audioCtx.currentTime, 0.08);
  }

  if (!musicEnabled || masterMuted) {
    stopBackgroundMusic();
  }
}

/**
 * Synthesizes a single, clean acoustic wooden chess piece placement:
 * a warm damped wood body resonance paired with a soft low-passed felt/wood tap.
 */
function playAcousticWoodPlacement(options: {
  pitchVariance?: number;
  bodyStartFreq: number;
  bodyEndFreq: number;
  harmonicFreq: number;
  tapCutoffFreq: number;
  volume: number;
  decaySec?: number;
  delay?: number;
}) {
  const ctx = getCtx(false);
  if (!ctx) return;

  const vol = options.volume * sfxVolume;
  if (vol <= 0.001) return;

  const t0 = ctx.currentTime + (options.delay ?? 0);
  const jitter = 1 + (Math.random() - 0.5) * (options.pitchVariance ?? 0.04);
  const decay = options.decaySec ?? 0.068;

  // 1. Warm wooden board resonance (single clean sine thud)
  const bodyOsc = ctx.createOscillator();
  const bodyGain = ctx.createGain();
  bodyOsc.type = 'sine';
  bodyOsc.frequency.setValueAtTime(options.bodyStartFreq * jitter, t0);
  bodyOsc.frequency.exponentialRampToValueAtTime(
    Math.max(45, options.bodyEndFreq * jitter),
    t0 + 0.032,
  );

  bodyGain.gain.setValueAtTime(0.0001, t0);
  bodyGain.gain.linearRampToValueAtTime(vol * 0.85, t0 + 0.0025);
  bodyGain.gain.exponentialRampToValueAtTime(0.0001, t0 + decay);

  bodyOsc.connect(bodyGain);
  bodyGain.connect(ctx.destination);
  bodyOsc.start(t0);
  bodyOsc.stop(t0 + decay + 0.015);

  // 2. Subtle wood knock harmonic
  const knockOsc = ctx.createOscillator();
  const knockGain = ctx.createGain();
  knockOsc.type = 'triangle';
  knockOsc.frequency.setValueAtTime(options.harmonicFreq * jitter, t0);
  knockOsc.frequency.exponentialRampToValueAtTime(
    Math.max(120, options.harmonicFreq * 0.68 * jitter),
    t0 + 0.016,
  );

  knockGain.gain.setValueAtTime(0.0001, t0);
  knockGain.gain.linearRampToValueAtTime(vol * 0.28, t0 + 0.0015);
  knockGain.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.022);

  knockOsc.connect(knockGain);
  knockGain.connect(ctx.destination);
  knockOsc.start(t0);
  knockOsc.stop(t0 + 0.028);

  // 3. Soft low-passed wood surface tap
  const noiseSrc = ctx.createBufferSource();
  noiseSrc.buffer = getNoiseBuffer(ctx);

  const filter = ctx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.setValueAtTime(options.tapCutoffFreq * jitter, t0);
  filter.Q.setValueAtTime(0.8, t0);

  const noiseGain = ctx.createGain();
  noiseGain.gain.setValueAtTime(0.0001, t0);
  noiseGain.gain.linearRampToValueAtTime(vol * 0.22, t0 + 0.0015);
  noiseGain.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.018);

  noiseSrc.connect(filter);
  filter.connect(noiseGain);
  noiseGain.connect(ctx.destination);
  noiseSrc.start(t0);
  noiseSrc.stop(t0 + 0.024);
}

export function playSelectSound(): void {
  const ctx = getCtx(false);
  if (!ctx) return;
  const vol = 0.055 * sfxVolume;
  if (vol <= 0.001) return;

  const t0 = ctx.currentTime;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = 'sine';
  osc.frequency.setValueAtTime(340, t0);
  osc.frequency.exponentialRampToValueAtTime(220, t0 + 0.024);
  gain.gain.setValueAtTime(0.0001, t0);
  gain.gain.linearRampToValueAtTime(vol, t0 + 0.002);
  gain.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.028);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(t0);
  osc.stop(t0 + 0.032);
}

export function playMoveSound(): void {
  playAcousticWoodPlacement({
    bodyStartFreq: 185,
    bodyEndFreq: 96,
    harmonicFreq: 440,
    tapCutoffFreq: 920,
    volume: 0.24,
    decaySec: 0.064,
    pitchVariance: 0.05,
  });
}

export function playCaptureSound(): void {
  playAcousticWoodPlacement({
    bodyStartFreq: 235,
    bodyEndFreq: 108,
    harmonicFreq: 620,
    tapCutoffFreq: 1350,
    volume: 0.32,
    decaySec: 0.082,
    pitchVariance: 0.04,
  });
}

export function playCastleSound(): void {
  playAcousticWoodPlacement({
    bodyStartFreq: 180,
    bodyEndFreq: 94,
    harmonicFreq: 420,
    tapCutoffFreq: 900,
    volume: 0.22,
    decaySec: 0.06,
  });
  playAcousticWoodPlacement({
    bodyStartFreq: 205,
    bodyEndFreq: 104,
    harmonicFreq: 470,
    tapCutoffFreq: 960,
    volume: 0.22,
    decaySec: 0.065,
    delay: 0.115,
  });
}

export function playCheckSound(): void {
  playMoveSound();
  const ctx = getCtx(false);
  if (!ctx) return;
  const vol = 0.09 * sfxVolume;
  if (vol <= 0.001) return;

  const t0 = ctx.currentTime + 0.025;
  const freqs = [523.25, 783.99];
  freqs.forEach((f, idx) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(f, t0);
    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.linearRampToValueAtTime(idx === 0 ? vol : vol * 0.5, t0 + 0.014);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.28);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(t0);
    osc.stop(t0 + 0.3);
  });
}

export function playGameOverSound(isWin: boolean): void {
  const ctx = getCtx(false);
  if (!ctx) return;
  const vol = 0.11 * sfxVolume;
  if (vol <= 0.001) return;

  const chord = isWin ? [392.0, 493.88, 587.33, 783.99] : [392.0, 349.23, 311.13];
  chord.forEach((freq, idx) => {
    const start = ctx.currentTime + idx * 0.095;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, start);

    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.linearRampToValueAtTime(vol, start + 0.018);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.42);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(start);
    osc.stop(start + 0.45);
  });
}

/**
 * Warm classical felt-piano / harp opening fanfare played when a match begins.
 */
export function playGameStartMusic(): void {
  const ctx = getCtx(true);
  if (!ctx) return;
  const activeVol = musicEnabled ? musicVolume : sfxEnabled ? sfxVolume * 0.55 : 0;
  if (activeVol <= 0.005) return;

  // Noble warm Cmaj9 rising arpeggio + gentle fifth sustain
  const notes = [
    { freq: 261.63, delay: 0.0, dur: 0.55, amp: 0.14 }, // C4
    { freq: 329.63, delay: 0.09, dur: 0.55, amp: 0.13 }, // E4
    { freq: 392.0, delay: 0.18, dur: 0.65, amp: 0.13 }, // G4
    { freq: 493.88, delay: 0.27, dur: 0.75, amp: 0.12 }, // B4
    { freq: 587.33, delay: 0.37, dur: 1.05, amp: 0.14 }, // D5
    { freq: 130.81, delay: 0.0, dur: 1.35, amp: 0.12 }, // C3 warm bass anchor
  ];

  const filter = ctx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.setValueAtTime(1600, ctx.currentTime);
  filter.connect(ctx.destination);

  for (const n of notes) {
    const start = ctx.currentTime + n.delay;
    const osc = ctx.createOscillator();
    const subOsc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(n.freq, start);

    subOsc.type = 'triangle';
    subOsc.frequency.setValueAtTime(n.freq * 2, start);

    const subGain = ctx.createGain();
    subGain.gain.setValueAtTime(0.08, start);

    const peak = n.amp * activeVol;
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.linearRampToValueAtTime(peak, start + 0.025);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + n.dur);

    osc.connect(gain);
    subOsc.connect(subGain);
    subGain.connect(gain);
    gain.connect(filter);

    osc.start(start);
    subOsc.start(start);
    osc.stop(start + n.dur + 0.04);
    subOsc.stop(start + n.dur + 0.04);
  }
}

// Calm, meditative 16-step ambient chess-parlor progression (Cmaj7 -> Am9 -> Fmaj7 -> G6)
const AMBIENT_STEPS: Array<{ bass?: number; notes: number[]; dur: number }> = [
  { bass: 130.81, notes: [261.63, 329.63, 493.88], dur: 2.3 }, // Cmaj7
  { notes: [392.0], dur: 1.3 },
  { notes: [587.33], dur: 1.4 },
  { notes: [329.63, 493.88], dur: 1.5 },

  { bass: 110.0, notes: [220.0, 261.63, 392.0], dur: 2.3 }, // Am7
  { notes: [493.88], dur: 1.3 },
  { notes: [523.25], dur: 1.4 },
  { notes: [261.63, 392.0], dur: 1.5 },

  { bass: 87.31, notes: [174.61, 220.0, 329.63], dur: 2.3 }, // Fmaj7
  { notes: [261.63], dur: 1.3 },
  { notes: [392.0], dur: 1.4 },
  { notes: [220.0, 329.63], dur: 1.5 },

  { bass: 98.0, notes: [196.0, 246.94, 329.63], dur: 2.3 }, // G6
  { notes: [293.66], dur: 1.3 },
  { notes: [440.0], dur: 1.4 },
  { notes: [246.94, 392.0], dur: 1.5 },
];

function ensureMusicBus(ctx: AudioContext): GainNode {
  if (musicBusGain && musicBusGain.context === ctx) {
    return musicBusGain;
  }

  const bus = ctx.createGain();
  const target = !masterMuted && musicEnabled ? musicVolume * 0.16 : 0;
  bus.gain.setValueAtTime(target, ctx.currentTime);

  const lpf = ctx.createBiquadFilter();
  lpf.type = 'lowpass';
  lpf.frequency.setValueAtTime(1050, ctx.currentTime);

  // Subtle ambient echo tail for felt-piano warmth
  const delay = ctx.createDelay(1.0);
  delay.delayTime.setValueAtTime(0.36, ctx.currentTime);
  const feedback = ctx.createGain();
  feedback.gain.setValueAtTime(0.24, ctx.currentTime);
  const wetGain = ctx.createGain();
  wetGain.gain.setValueAtTime(0.28, ctx.currentTime);

  bus.connect(lpf);
  lpf.connect(ctx.destination);
  lpf.connect(delay);
  delay.connect(feedback);
  feedback.connect(delay);
  delay.connect(wetGain);
  wetGain.connect(ctx.destination);

  musicBusGain = bus;
  return bus;
}

function scheduleAmbientStep(): void {
  if (!musicPlaying || masterMuted || !musicEnabled) return;
  const ctx = getCtx(true);
  if (!ctx) return;

  const bus = ensureMusicBus(ctx);
  const step = AMBIENT_STEPS[musicStepIndex % AMBIENT_STEPS.length];
  musicStepIndex = (musicStepIndex + 1) % AMBIENT_STEPS.length;

  const t0 = ctx.currentTime + 0.04;

  const playWarmTone = (freq: number, amp: number, dur: number) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, t0);

    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.linearRampToValueAtTime(amp, t0 + 0.09);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);

    osc.connect(gain);
    gain.connect(bus);
    osc.start(t0);
    osc.stop(t0 + dur + 0.06);
  };

  if (step.bass) {
    playWarmTone(step.bass, 0.36, step.dur);
  }
  step.notes.forEach((freq, idx) => {
    playWarmTone(freq, 0.24 - idx * 0.03, step.dur * 0.9);
  });
}

export function startBackgroundMusic(delayMs = 0): void {
  if (typeof window === 'undefined' || masterMuted || !musicEnabled) return;
  const ctx = getCtx(true);
  if (!ctx) return;
  ensureMusicBus(ctx);

  if (musicPlaying || musicDelayTimer !== null) return;

  const begin = () => {
    musicDelayTimer = null;
    if (masterMuted || !musicEnabled || musicPlaying) return;
    musicPlaying = true;
    scheduleAmbientStep();
    musicTimer = window.setInterval(scheduleAmbientStep, 920);
  };

  if (delayMs > 0) {
    musicDelayTimer = window.setTimeout(begin, delayMs);
  } else {
    begin();
  }
}

export function stopBackgroundMusic(): void {
  musicPlaying = false;
  if (musicDelayTimer !== null) {
    window.clearTimeout(musicDelayTimer);
    musicDelayTimer = null;
  }
  if (musicTimer !== null) {
    window.clearInterval(musicTimer);
    musicTimer = null;
  }
}
