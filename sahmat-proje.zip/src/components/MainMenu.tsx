import { useState } from 'react';
import { Bot, Globe, Swords, ArrowRight, Loader2, Settings } from 'lucide-react';
import { getTranslations, type Language } from '../game/i18n';
import {
  type BotDifficulty,
  type GameVariant,
  type SidePreference,
  type TimeControlKey,
} from '../game/types';
import { GameBrandTitle } from './GameBrandTitle';

interface MainMenuProps {
  variant?: GameVariant;
  onVariantChange?: (variant: GameVariant) => void;
  playerName: string;
  onPlayerNameChange: (name: string) => void;
  lang: Language;
  onOpenSettings: () => void;
  wsConnected: boolean;
  matchmakingWaiting: boolean;
  onlineError: string | null;
  initialRoomCode?: string;
  onStartBotGame: (params: {
    difficulty: BotDifficulty;
    side: SidePreference;
    timeControl: TimeControlKey;
  }) => void;
  onStartShashkiGame: (params: {
    difficulty: BotDifficulty;
    side: SidePreference;
    timeControl: TimeControlKey;
  }) => void;
  onCreateOnlineRoom: (params: {
    variant: GameVariant;
    timeControl: TimeControlKey;
    sidePreference: SidePreference;
  }) => void;
  onJoinOnlineRoom: (roomCode: string) => void;
  onJoinMatchmaking: (params: {
    variant: GameVariant;
    timeControl: TimeControlKey;
  }) => void;
  onCancelMatchmaking: () => void;
  onClearError?: () => void;
}

type MenuTab = 'bot' | 'online';

export function MainMenu({
  variant: controlledVariant,
  onVariantChange,
  playerName,
  onPlayerNameChange,
  lang,
  onOpenSettings,
  wsConnected,
  matchmakingWaiting,
  onlineError,
  initialRoomCode = '',
  onStartBotGame,
  onStartShashkiGame,
  onCreateOnlineRoom,
  onJoinOnlineRoom,
  onJoinMatchmaking,
  onCancelMatchmaking,
  onClearError,
}: MainMenuProps) {
  const t = getTranslations(lang);
  const [activeTab, setActiveTab] = useState<MenuTab>(initialRoomCode ? 'online' : 'bot');
  const [difficulty, setDifficulty] = useState<BotDifficulty>('medium');
  const [side, setSide] = useState<SidePreference>('w');
  const [internalVariant, setInternalVariant] = useState<GameVariant>('chess');
  const selectedVariant = controlledVariant ?? internalVariant;
  const setSelectedVariant = (next: GameVariant) => {
    setInternalVariant(next);
    onVariantChange?.(next);
  };
  const [timeControl, setTimeControl] = useState<TimeControlKey>('10+0');
  const [roomCodeInput, setRoomCodeInput] = useState(initialRoomCode);

  const timeKeys: TimeControlKey[] = ['3+2', '5+0', '10+0', 'unlimited'];

  return (
    <main className="min-h-dvh parchment-texture flex flex-col px-3.5 sm:px-8 pt-3 pb-3.5 sm:py-10">
      <div className="max-w-[640px] w-full mx-auto flex-1 sm:flex-none sm:my-auto flex flex-col gap-3 sm:gap-6">
        {/* Top Royal Header */}
        <header className="animate-menu-rise flex items-center justify-between gap-3 px-0.5">
          <GameBrandTitle
            variant={selectedVariant}
            title={selectedVariant === 'shashki' ? t.shashkiTitle : 'ŞAHMAT'}
            size="lg"
          />

          <button
            type="button"
            onClick={onOpenSettings}
            aria-label={t.openSettingsAria}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-[var(--border-subtle)] bg-[var(--surface-panel)] text-xs sm:text-sm font-semibold text-[var(--ink-primary)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer shrink-0 shadow-sm"
          >
            <Settings className="w-4 h-4 text-[var(--accent-gold)]" />
            <span>{t.settings}</span>
          </button>
        </header>

        {/* Mode Selector & Configuration */}
        <div className="animate-menu-rise flex-1 sm:flex-none flex flex-col gap-2.5 sm:gap-4">
          <div
            role="tablist"
            aria-label={t.modeTablistAria}
            className="grid grid-cols-2 gap-1 p-1 rounded-xl border border-[var(--border-subtle)] bg-[var(--surface-muted)]"
          >
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === 'bot'}
              onClick={() => {
                setActiveTab('bot');
                onClearError?.();
              }}
              className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-xs sm:text-sm font-semibold transition-colors duration-150 cursor-pointer whitespace-nowrap ${
                activeTab === 'bot'
                  ? 'bg-[var(--btn-primary-bg)] text-[var(--btn-primary-text)] shadow-sm'
                  : 'text-[var(--ink-secondary)] hover:text-[var(--ink-primary)] hover:bg-[var(--surface-hover)]/60'
              }`}
            >
              <Bot className="w-4 h-4 shrink-0" />
              <span>{t.modeBot}</span>
            </button>

            <button
              type="button"
              role="tab"
              aria-selected={activeTab === 'online'}
              onClick={() => setActiveTab('online')}
              className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-xs sm:text-sm font-semibold transition-colors duration-150 cursor-pointer whitespace-nowrap ${
                activeTab === 'online'
                  ? 'bg-[var(--btn-primary-bg)] text-[var(--btn-primary-text)] shadow-sm'
                  : 'text-[var(--ink-secondary)] hover:text-[var(--ink-primary)] hover:bg-[var(--surface-hover)]/60'
              }`}
            >
              <Globe className="w-4 h-4 shrink-0" />
              <span>{t.modeOnline}</span>
            </button>
          </div>

          <div className="soft-panel rounded-2xl p-4 sm:p-7 flex-1 sm:flex-none flex flex-col justify-between sm:justify-start gap-3.5 sm:gap-5">
            {/* Time Control Selector */}
            <div>
              <span className="block text-xs font-semibold text-[var(--ink-secondary)] mb-2">
                {t.timeControlLabel}
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {timeKeys.map((key) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setTimeControl(key)}
                    className={`py-2.5 px-3 rounded-lg text-xs font-semibold border transition-colors cursor-pointer whitespace-nowrap ${
                      timeControl === key
                        ? 'bg-[var(--btn-primary-bg)] text-[var(--btn-primary-text)] border-transparent shadow-sm'
                        : 'bg-[var(--surface-elevated)] text-[var(--ink-primary)] border-[var(--border-subtle)] hover:bg-[var(--surface-hover)]'
                    }`}
                  >
                    {t.timeControls[key]}
                  </button>
                ))}
              </div>
            </div>

            {/* Game Variant Selector (Chess / Shashki) */}
            <div>
              <span className="block text-xs font-semibold text-[var(--ink-secondary)] mb-2">
                {t.shashkiVariantLabel}
              </span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedVariant('chess')}
                  className={`py-2.5 px-3 rounded-lg text-xs font-semibold border transition-colors cursor-pointer whitespace-nowrap ${
                    selectedVariant === 'chess'
                      ? 'bg-[var(--btn-accent-bg)] text-[var(--btn-accent-text)] border-transparent shadow-sm'
                      : 'bg-[var(--surface-elevated)] text-[var(--ink-primary)] border-[var(--border-subtle)] hover:bg-[var(--surface-hover)]'
                  }`}
                >
                  {t.chessGameLabel}
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedVariant('shashki')}
                  className={`py-2.5 px-3 rounded-lg text-xs font-semibold border transition-colors cursor-pointer whitespace-nowrap ${
                    selectedVariant === 'shashki'
                      ? 'bg-[var(--btn-accent-bg)] text-[var(--btn-accent-text)] border-transparent shadow-sm'
                      : 'bg-[var(--surface-elevated)] text-[var(--ink-primary)] border-[var(--border-subtle)] hover:bg-[var(--surface-hover)]'
                  }`}
                >
                  {t.modeShashki}
                </button>
              </div>
            </div>

            {activeTab === 'bot' && (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <span className="block text-xs font-semibold text-[var(--ink-secondary)] mb-2">
                      {t.difficultyLabel}
                    </span>
                    <div className="grid grid-cols-3 gap-1.5">
                      {(
                        [
                          { id: 'easy', label: t.diffEasy },
                          { id: 'medium', label: t.diffMedium },
                          { id: 'hard', label: t.diffHard },
                        ] as const
                      ).map((lvl) => (
                        <button
                          key={lvl.id}
                          type="button"
                          onClick={() => setDifficulty(lvl.id)}
                          className={`py-2.5 px-2 rounded-lg text-xs font-semibold border transition-colors cursor-pointer whitespace-nowrap ${
                            difficulty === lvl.id
                              ? 'bg-[var(--btn-accent-bg)] text-[var(--btn-accent-text)] border-transparent shadow-sm'
                              : 'bg-[var(--surface-elevated)] text-[var(--ink-primary)] border-[var(--border-subtle)] hover:bg-[var(--surface-hover)]'
                          }`}
                        >
                          {lvl.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <span className="block text-xs font-semibold text-[var(--ink-secondary)] mb-2">
                      {t.sideSelectionLabel}
                    </span>
                    <div className="grid grid-cols-3 gap-1.5">
                      {(
                        [
                          { id: 'w', label: t.white },
                          { id: 'b', label: t.black },
                          { id: 'random', label: t.random },
                        ] as const
                      ).map((opt) => (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => setSide(opt.id)}
                          className={`py-2.5 px-2 rounded-lg text-xs font-semibold border transition-colors cursor-pointer whitespace-nowrap ${
                            side === opt.id
                              ? 'bg-[var(--btn-accent-bg)] text-[var(--btn-accent-text)] border-transparent shadow-sm'
                              : 'bg-[var(--surface-elevated)] text-[var(--ink-primary)] border-[var(--border-subtle)] hover:bg-[var(--surface-hover)]'
                          }`}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  data-start="true"
                  onClick={() => {
                    if (selectedVariant === 'shashki') {
                      onStartShashkiGame({ difficulty, side, timeControl });
                    } else {
                      onStartBotGame({ difficulty, side, timeControl });
                    }
                  }}
                  className="w-full py-3.5 px-6 rounded-xl bg-[var(--btn-primary-bg)] text-[var(--btn-primary-text)] font-semibold text-sm sm:text-base flex items-center justify-center gap-2 hover:bg-[var(--btn-primary-hover)] transition-colors cursor-pointer whitespace-nowrap shadow-sm"
                >
                  <Swords className="w-4 h-4" />
                  <span>{t.startGame}</span>
                </button>
              </>
            )}

            {activeTab === 'online' && (
              <div className="flex flex-col gap-4">

                <div>
                  <label
                    htmlFor="player-name-input"
                    className="block text-xs font-semibold text-[var(--ink-secondary)] mb-1.5"
                  >
                    {t.playerNameLabel}
                  </label>
                  <input
                    id="player-name-input"
                    type="text"
                    maxLength={24}
                    value={playerName}
                    onChange={(e) => onPlayerNameChange(e.target.value)}
                    placeholder={t.playerNamePlaceholder}
                    className="w-full px-3.5 py-2.5 rounded-lg text-sm bg-[var(--surface-input)] border border-[var(--border-subtle)] text-[var(--ink-primary)] focus:outline-none focus:border-[var(--border-strong)]"
                  />
                </div>

                <div>
                  <span className="block text-xs font-semibold text-[var(--ink-secondary)] mb-2">
                    {t.sidePrefOnlineLabel}
                  </span>
                  <div className="grid grid-cols-3 gap-2">
                    {(
                      [
                        { id: 'w', label: t.white },
                        { id: 'b', label: t.black },
                        { id: 'random', label: t.random },
                      ] as const
                    ).map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setSide(opt.id)}
                        className={`py-2 px-2 rounded-lg text-xs font-semibold border transition-colors cursor-pointer whitespace-nowrap ${
                          side === opt.id
                            ? 'bg-[var(--btn-accent-bg)] text-[var(--btn-accent-text)] border-transparent shadow-sm'
                            : 'bg-[var(--surface-elevated)] text-[var(--ink-primary)] border-[var(--border-subtle)] hover:bg-[var(--surface-hover)]'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>

                {onlineError && (
                  <p className="text-xs font-semibold text-[var(--danger-text)] bg-[var(--danger-bg)] border border-[var(--danger-border)] rounded-lg px-3 py-2">
                    {onlineError}
                  </p>
                )}

                {matchmakingWaiting ? (
                  <div className="flex items-center justify-between gap-3 rounded-xl bg-[var(--surface-elevated)] border border-[var(--border-subtle)] px-4 py-3">
                    <div className="flex items-center gap-2 text-sm font-semibold text-[var(--ink-primary)]">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>{t.searchingOpponent}</span>
                    </div>
                    <button
                      type="button"
                      onClick={onCancelMatchmaking}
                      className="px-3 py-1.5 rounded-lg text-xs font-semibold border border-[var(--border-strong)] text-[var(--ink-primary)] hover:bg-[var(--surface-hover)] cursor-pointer whitespace-nowrap"
                    >
                      {t.cancel}
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <button
                      type="button"
                      disabled={!wsConnected}
                      onClick={() => onJoinMatchmaking({ variant: selectedVariant, timeControl })}
                      className="py-3 px-4 rounded-xl bg-[var(--btn-primary-bg)] text-[var(--btn-primary-text)] font-semibold text-sm flex items-center justify-center gap-2 hover:bg-[var(--btn-primary-hover)] disabled:opacity-50 transition-colors cursor-pointer whitespace-nowrap shadow-sm"
                    >
                      <Globe className="w-4 h-4" />
                      <span>{t.quickMatch}</span>
                    </button>

                    <button
                      type="button"
                      disabled={!wsConnected}
                      onClick={() => onCreateOnlineRoom({ variant: selectedVariant, timeControl, sidePreference: side })}
                      className="py-3 px-4 rounded-xl bg-[var(--btn-accent-bg)] text-[var(--btn-accent-text)] font-semibold text-sm flex items-center justify-center gap-2 hover:bg-[var(--btn-accent-hover)] disabled:opacity-50 transition-colors cursor-pointer whitespace-nowrap shadow-sm"
                    >
                      <span>{t.createPrivateRoom}</span>
                    </button>
                  </div>
                )}

                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (roomCodeInput.trim()) {
                      onJoinOnlineRoom(roomCodeInput.trim().toUpperCase());
                    }
                  }}
                  className="pt-3.5 border-t border-[var(--border-subtle)] flex items-end gap-2"
                >
                  <div className="flex-1">
                    <label
                      htmlFor="room-code-input"
                      className="block text-xs font-semibold text-[var(--ink-secondary)] mb-1.5"
                    >
                      {t.joinByCodeLabel}
                    </label>
                    <input
                      id="room-code-input"
                      type="text"
                      maxLength={160}
                      value={roomCodeInput}
                      onChange={(e) => {
                        const raw = e.target.value.trim();
                        const urlMatch = raw.match(/[?&]room=([A-Za-z0-9]+)/i);
                        const normalized = (urlMatch ? urlMatch[1] : raw.replace(/\s+/g, ''))
                          .toUpperCase()
                          .slice(0, 12);
                        setRoomCodeInput(normalized);
                        onClearError?.();
                      }}
                      placeholder={t.joinByCodePlaceholder}
                      className="w-full px-3.5 py-2 rounded-lg text-sm font-mono-tabular uppercase tracking-wider bg-[var(--surface-input)] border border-[var(--border-subtle)] text-[var(--ink-primary)] focus:outline-none focus:border-[var(--border-strong)]"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={!wsConnected || !roomCodeInput.trim()}
                    className="px-4 py-2 rounded-lg text-sm font-semibold border border-[var(--border-strong)] bg-[var(--surface-elevated)] text-[var(--ink-primary)] hover:bg-[var(--surface-hover)] disabled:opacity-45 inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0 h-[38px]"
                  >
                    <span>{t.joinButton}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}
