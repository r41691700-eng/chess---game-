import { memo, useCallback, useLayoutEffect, useMemo, useRef } from 'react';
import {
  getBoardMatrix,
  getKingSquare,
  getLegalMovesForSquare,
  isInCheck as checkIsInCheck,
} from '../game/chessRules';
import { getTranslations, type Language } from '../game/i18n';
import type { PieceColor, PieceType } from '../game/types';
import { ChessPieceSvg } from './ChessPieceSvg';

interface ChessBoardProps {
  fen: string;
  orientation: PieceColor;
  interactive: boolean;
  canMoveColor?: PieceColor | 'both' | null;
  selectedSquare: string | null;
  lastMove?: { from: string; to: string } | null;
  inCheck?: boolean;
  onSquareClick: (square: string) => void;
  onPieceDrop?: (from: string, to: string) => void;
  showLegalMoves?: boolean;
  showCoordinates?: boolean;
  animatePieces?: boolean;
  lang?: Language;
}

const FILES = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];

function getVisualCoords(square: string, orientation: PieceColor): { col: number; row: number } {
  const f = FILES.indexOf(square[0]);
  const r = 8 - Number(square[1]);
  return orientation === 'w' ? { col: f, row: r } : { col: 7 - f, row: 7 - r };
}

function getCastlingRookMove(
  lastMove: { from: string; to: string },
  pieceType?: PieceType,
): { from: string; to: string } | null {
  if (pieceType !== 'k') return null;
  if (lastMove.from === 'e1' && lastMove.to === 'g1') return { from: 'h1', to: 'f1' };
  if (lastMove.from === 'e1' && lastMove.to === 'c1') return { from: 'a1', to: 'd1' };
  if (lastMove.from === 'e8' && lastMove.to === 'g8') return { from: 'h8', to: 'f8' };
  if (lastMove.from === 'e8' && lastMove.to === 'c8') return { from: 'a8', to: 'd8' };
  return null;
}

interface ChessSquareCellProps {
  square: string;
  isLight: boolean;
  pieceType: PieceType | null;
  pieceColor: PieceColor | null;
  isSelected: boolean;
  isLastFrom: boolean;
  isLastTo: boolean;
  legalKind: 0 | 1 | 2;
  isKingThreatened: boolean;
  pieceCanDrag: boolean;
  interactive: boolean;
  animatePieces: boolean;
  glideId: number;
  glideDxPct: number;
  glideDyPct: number;
  rankLabel?: string;
  fileLabel?: string;
  ariaLabel: string;
  onSquareClick: (square: string) => void;
  onSquareDrop: (fromSquare: string, toSquare: string) => void;
  onDragStartSquare: (square: string) => void;
}

const ChessSquareCell = memo(function ChessSquareCell({
  square,
  isLight,
  pieceType,
  pieceColor,
  isSelected,
  isLastFrom,
  isLastTo,
  legalKind,
  isKingThreatened,
  pieceCanDrag,
  interactive,
  animatePieces,
  glideId,
  glideDxPct,
  glideDyPct,
  rankLabel,
  fileLabel,
  ariaLabel,
  onSquareClick,
  onSquareDrop,
  onDragStartSquare,
}: ChessSquareCellProps) {
  const glideRef = useRef<HTMLDivElement | null>(null);
  const lastPlayedGlideIdRef = useRef<number>(0);

  useLayoutEffect(() => {
    if (glideId === 0) {
      lastPlayedGlideIdRef.current = 0;
      return;
    }
    if (lastPlayedGlideIdRef.current === glideId) return;
    lastPlayedGlideIdRef.current = glideId;

    const el = glideRef.current;
    if (!el) return;
    if (
      typeof window !== 'undefined' &&
      window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
    ) {
      return;
    }

    el.getAnimations?.().forEach((a) => a.cancel());
    el.style.willChange = 'transform';
    const anim = el.animate(
      [
        { transform: `translate3d(${glideDxPct}%, ${glideDyPct}%, 0) scale(1)` },
        {
          transform: `translate3d(${glideDxPct * 0.42}%, ${glideDyPct * 0.42}%, 0) scale(1.08)`,
          offset: 0.45,
        },
        { transform: 'translate3d(0%, 0%, 0) scale(1)' },
      ],
      {
        duration: 210,
        easing: 'cubic-bezier(0.22, 1, 0.36, 1)',
      },
    );
    const clearWillChange = () => {
      if (glideRef.current) {
        glideRef.current.style.willChange = 'auto';
      }
    };
    anim.onfinish = clearWillChange;
    anim.oncancel = clearWillChange;
  }, [glideDxPct, glideDyPct, glideId]);

  const baseColor = isLight ? '#E6CEA8' : '#7B5236';
  let overlayTint: string | undefined;
  if (isSelected) {
    overlayTint = 'linear-gradient(rgba(222, 168, 42, 0.52), rgba(222, 168, 42, 0.52))';
  } else if (isLastFrom || isLastTo) {
    overlayTint = 'linear-gradient(rgba(226, 180, 58, 0.34), rgba(226, 180, 58, 0.34))';
  }

  return (
    <button
      type="button"
      data-square={square}
      aria-label={ariaLabel}
      onClick={() => onSquareClick(square)}
      onDragOver={(e) => {
        if (interactive) e.preventDefault();
      }}
      onDrop={(e) => {
        if (!interactive) return;
        e.preventDefault();
        const fromSq = e.dataTransfer.getData('text/plain');
        if (fromSq && fromSq !== square) {
          onSquareDrop(fromSq, square);
        }
      }}
      style={{
        backgroundColor: baseColor,
        backgroundImage: overlayTint,
      }}
      className="relative aspect-square w-full h-full flex items-center justify-center p-[5.5%] overflow-visible focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[#211912]"
    >
      {rankLabel && (
        <span
          aria-hidden="true"
          className={`absolute top-[2px] left-[3px] text-[8px] sm:text-[9.5px] font-bold leading-none pointer-events-none select-none z-10 ${
            isLight ? 'text-[#6A452B]/85' : 'text-[#EFE0C4]/85'
          }`}
        >
          {rankLabel}
        </span>
      )}

      {fileLabel && (
        <span
          aria-hidden="true"
          className={`absolute bottom-[2px] right-[3px] text-[8px] sm:text-[9.5px] font-bold leading-none pointer-events-none select-none z-10 ${
            isLight ? 'text-[#6A452B]/85' : 'text-[#EFE0C4]/85'
          }`}
        >
          {fileLabel}
        </span>
      )}

      {isKingThreatened && (
        <span
          aria-hidden="true"
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              'radial-gradient(circle, rgba(182, 34, 24, 0.85) 0%, rgba(182, 34, 24, 0.3) 58%, transparent 74%)',
          }}
        />
      )}

      {isLastTo && animatePieces && glideId > 0 && (
        <span
          key={`settle-${glideId}`}
          aria-hidden="true"
          className="animate-square-settle absolute inset-[8%] rounded-full border-2 border-[#E6B33D]/80 pointer-events-none z-10"
        />
      )}

      {legalKind === 1 && (
        <span
          aria-hidden="true"
          className={`w-[27%] h-[27%] rounded-full bg-[#1E1610]/30 pointer-events-none z-10 ${
            animatePieces ? 'animate-hint-pop' : ''
          }`}
        />
      )}

      {legalKind === 2 && (
        <span
          aria-hidden="true"
          className={`absolute inset-[7%] rounded-full border-[3.5px] border-[#1E1610]/45 pointer-events-none z-10 ${
            animatePieces ? 'animate-hint-pop' : ''
          }`}
        />
      )}

      {pieceType && pieceColor && (
        <div
          ref={glideRef}
          key={`piece-${pieceColor}-${pieceType}`}
          className={`w-full h-full ${glideId > 0 || isSelected ? 'z-30' : 'z-20'}`}
        >
          <div
            draggable={pieceCanDrag}
            onDragStart={(e) => {
              if (!pieceCanDrag) {
                e.preventDefault();
                return;
              }
              e.dataTransfer.setData('text/plain', square);
              e.dataTransfer.effectAllowed = 'move';
              onDragStartSquare(square);
            }}
            className={`w-full h-full transition-transform duration-150 ${
              isSelected ? 'scale-[1.09] -translate-y-0.5' : ''
            } ${pieceCanDrag ? 'cursor-grab active:cursor-grabbing hover:scale-[1.03]' : ''}`}
          >
            <ChessPieceSvg type={pieceType} color={pieceColor} />
          </div>
        </div>
      )}
    </button>
  );
});

export const ChessBoard = memo(function ChessBoard({
  fen,
  orientation,
  interactive,
  canMoveColor,
  selectedSquare,
  lastMove,
  inCheck: inCheckProp,
  onSquareClick,
  onPieceDrop,
  showLegalMoves = true,
  showCoordinates = true,
  animatePieces = true,
  lang = 'tr',
}: ChessBoardProps) {
  const t = getTranslations(lang);
  const matrix = useMemo(() => getBoardMatrix(fen), [fen]);
  const inCheck = useMemo(
    () => (inCheckProp !== undefined ? inCheckProp : checkIsInCheck(fen)),
    [fen, inCheckProp],
  );
  const turn = useMemo(() => (fen.split(' ')[1] === 'b' ? 'b' : 'w') as PieceColor, [fen]);
  const checkedKingSquare = useMemo(
    () => (inCheck ? getKingSquare(fen, turn) : null),
    [fen, inCheck, turn],
  );

  const legalTargets = useMemo(() => {
    if (!interactive || !selectedSquare) return new Map<string, { isCapture: boolean }>();
    const list = getLegalMovesForSquare(fen, selectedSquare);
    return new Map(list.map((m) => [m.to, { isCapture: m.isCapture }]));
  }, [fen, interactive, selectedSquare]);

  const rows = useMemo(() => {
    const indices = [0, 1, 2, 3, 4, 5, 6, 7];
    return orientation === 'w' ? indices : [...indices].reverse();
  }, [orientation]);

  const cols = useMemo(() => {
    const indices = [0, 1, 2, 3, 4, 5, 6, 7];
    return orientation === 'w' ? indices : [...indices].reverse();
  }, [orientation]);

  const castlingRookMove = useMemo(() => {
    if (!lastMove) return null;
    const toF = FILES.indexOf(lastMove.to[0]);
    const toR = 8 - Number(lastMove.to[1]);
    const movedPiece = matrix[toR]?.[toF];
    return getCastlingRookMove(lastMove, movedPiece?.type);
  }, [lastMove, matrix]);

  // Increment glideSeq strictly when lastMove changes (not on selection/flip/click)
  const glideSeqRef = useRef<number>(0);
  const prevLastMoveRef = useRef<{ from: string; to: string } | null>(null);
  if (
    lastMove &&
    (prevLastMoveRef.current?.from !== lastMove.from ||
      prevLastMoveRef.current?.to !== lastMove.to)
  ) {
    glideSeqRef.current += 1;
    prevLastMoveRef.current = lastMove;
  } else if (!lastMove) {
    prevLastMoveRef.current = null;
  }

  // Skip glide when a piece was just dropped directly on the square by pointer drag
  const recentDropRef = useRef<{ from: string; to: string; ts: number } | null>(null);
  const onSquareClickRef = useRef(onSquareClick);
  const onPieceDropRef = useRef(onPieceDrop);
  const selectedSquareRef = useRef(selectedSquare);
  onSquareClickRef.current = onSquareClick;
  onPieceDropRef.current = onPieceDrop;
  selectedSquareRef.current = selectedSquare;

  const handleSquareClick = useCallback((sq: string) => {
    onSquareClickRef.current(sq);
  }, []);

  const handleSquareDrop = useCallback((fromSq: string, toSq: string) => {
    recentDropRef.current = { from: fromSq, to: toSq, ts: performance.now() };
    onPieceDropRef.current?.(fromSq, toSq);
  }, []);

  const handleDragStartSquare = useCallback((sq: string) => {
    if (selectedSquareRef.current !== sq) {
      onSquareClickRef.current(sq);
    }
  }, []);

  const activeDrop = recentDropRef.current;
  const skipDroppedGlide =
    Boolean(
      activeDrop &&
        lastMove &&
        activeDrop.from === lastMove.from &&
        activeDrop.to === lastMove.to &&
        performance.now() - activeDrop.ts < 450,
    );

  return (
    <div
      className="board-shell-frame rounded-xl p-1 select-none"
      data-testid="chess-board"
    >
      <div className="grid grid-cols-8 aspect-square w-full border border-[#322318]/80 rounded-[4px] overflow-visible shadow-[inset_0_0_0_1px_rgba(255,255,255,0.12)]">
        {rows.map((r, rIdx) =>
          cols.map((c, cIdx) => {
            const isLight = (r + c) % 2 === 0;
            const square = `${FILES[c]}${8 - r}`;
            const piece = matrix[r][c];
            const isSelected = selectedSquare === square;
            const isLastFrom = lastMove?.from === square;
            const isLastTo = lastMove?.to === square;
            const legalInfo = legalTargets.get(square);
            const legalKind: 0 | 1 | 2 =
              showLegalMoves && legalInfo ? (legalInfo.isCapture ? 2 : 1) : 0;
            const isKingThreatened = checkedKingSquare === square;

            const pieceCanDrag =
              interactive &&
              piece !== null &&
              (canMoveColor === 'both' || canMoveColor === piece.color) &&
              piece.color === turn;

            let glideSource: string | null = null;
            if (animatePieces && piece) {
              if (lastMove && isLastTo && !skipDroppedGlide) {
                glideSource = lastMove.from;
              } else if (castlingRookMove && castlingRookMove.to === square) {
                glideSource = castlingRookMove.from;
              }
            }

            let glideId = 0;
            let glideDxPct = 0;
            let glideDyPct = 0;
            if (glideSource) {
              const fromCoords = getVisualCoords(glideSource, orientation);
              const toCoords = getVisualCoords(square, orientation);
              glideId = glideSeqRef.current;
              glideDxPct = (fromCoords.col - toCoords.col) * 100;
              glideDyPct = (fromCoords.row - toCoords.row) * 100;
            }

            const labelParts = [square];
            if (piece) {
              labelParts.push(piece.color === 'w' ? t.white : t.black);
              labelParts.push(t.pieces[piece.type]);
            } else {
              labelParts.push(t.emptySquare);
            }
            if (legalInfo) {
              labelParts.push(legalInfo.isCapture ? t.captureMove : t.legalMove);
            }

            return (
              <ChessSquareCell
                key={square}
                square={square}
                isLight={isLight}
                pieceType={piece ? piece.type : null}
                pieceColor={piece ? piece.color : null}
                isSelected={isSelected}
                isLastFrom={isLastFrom}
                isLastTo={isLastTo}
                legalKind={legalKind}
                isKingThreatened={isKingThreatened}
                pieceCanDrag={pieceCanDrag}
                interactive={interactive}
                animatePieces={animatePieces}
                glideId={glideId}
                glideDxPct={glideDxPct}
                glideDyPct={glideDyPct}
                rankLabel={showCoordinates && cIdx === 0 ? String(8 - r) : undefined}
                fileLabel={showCoordinates && rIdx === 7 ? FILES[c] : undefined}
                ariaLabel={labelParts.join(' ')}
                onSquareClick={handleSquareClick}
                onSquareDrop={handleSquareDrop}
                onDragStartSquare={handleDragStartSquare}
              />
            );
          }),
        )}
      </div>
    </div>
  );
});
