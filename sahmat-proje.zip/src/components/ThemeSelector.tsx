import { Palette } from 'lucide-react';
import { getTranslations, type Language } from '../game/i18n';
import { APP_THEMES, type ThemeSelection } from '../game/themes';

interface ThemeSelectorProps {
  selection: ThemeSelection;
  onChange: (next: ThemeSelection) => void;
  lang?: Language;
  compact?: boolean;
  showCustom?: boolean;
}

export function ThemeSelector({
  selection,
  onChange,
  lang = 'tr',
  compact = false,
  showCustom = true,
}: ThemeSelectorProps) {
  const t = getTranslations(lang);
  const activeLabel =
    selection.id === 'custom'
      ? `${t.themeCustomShort} (${selection.customHex.toUpperCase()})`
      : t.themes[selection.id] ?? t.themes.cream;

  return (
    <div
      className="flex flex-wrap items-center justify-between gap-2.5 w-full"
      role="group"
      aria-label={t.themeGroupAria}
    >
      {!compact && (
        <div className="flex items-baseline gap-1.5">
          <span className="text-xs font-medium text-[var(--ink-muted)]">{t.themeBgLabel}</span>
          <span className="text-xs font-semibold text-[var(--ink-primary)]">{activeLabel}</span>
        </div>
      )}

      <div className="flex flex-wrap items-center gap-1.5">
        {APP_THEMES.map((opt) => {
          const active = selection.id === opt.id;
          const localizedLabel = t.themes[opt.id];
          return (
            <button
              key={opt.id}
              type="button"
              aria-pressed={active}
              aria-label={`${t.themeColorPrefix} ${localizedLabel}`}
              title={localizedLabel}
              onClick={() => onChange({ ...selection, id: opt.id })}
              className={`relative rounded-full transition-transform duration-150 cursor-pointer shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent-gold)] ${
                compact ? 'w-5 h-5' : 'w-6 h-6'
              } ${
                active
                  ? 'scale-110 ring-2 ring-[var(--ink-primary)] ring-offset-2 ring-offset-[var(--surface-panel)]'
                  : 'ring-1 ring-black/15 hover:scale-105'
              }`}
              style={{ backgroundColor: opt.swatch }}
            />
          );
        })}

        {showCustom && (
          <label
            title={t.themeCustomTitle}
            className={`relative inline-flex items-center gap-1.5 rounded-lg border transition-colors cursor-pointer shrink-0 ${
              compact ? 'px-2 py-1 text-[11px]' : 'px-2.5 py-1 text-xs'
            } font-medium ${
              selection.id === 'custom'
                ? 'border-[var(--border-strong)] bg-[var(--btn-primary-bg)] text-[var(--btn-primary-text)]'
                : 'border-[var(--border-subtle)] bg-[var(--surface-elevated)] text-[var(--ink-primary)] hover:bg-[var(--surface-hover)]'
            }`}
          >
            <Palette className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
            <span>{compact ? t.themeCustomShort : t.themeCustom}</span>
            <span
              aria-hidden="true"
              className="w-2.5 h-2.5 rounded-full border border-black/20 shrink-0"
              style={{ backgroundColor: selection.customHex }}
            />
            <input
              type="color"
              aria-label={t.themeCustomPickerAria}
              value={selection.customHex}
              onChange={(e) =>
                onChange({
                  id: 'custom',
                  customHex: e.target.value,
                })
              }
              className="sr-only"
            />
          </label>
        )}
      </div>
    </div>
  );
}
