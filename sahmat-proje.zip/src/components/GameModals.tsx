import { useState } from 'react';
import { Check, Copy, Home, RotateCcw, Trophy } from 'lucide-react';
import {
  formatOutcomeMessage,
  getTranslations,
  translateOpeningName,
  type Language,
} from '../game/i18n';
import type { GameOutcome, GameVariant, PieceColor, PromotionPiece } from '../game/types';
import { ChessPieceSvg } from './ChessPieceSvg';

interface PromotionModalProps {
  color: PieceColor;
  lang?: Language;
  onSelect: (piece: PromotionPiece) => void;
  onCancel: () => void;
}

export function PromotionModal({
  color,
  lang = 'tr',
  onSelect,
  onCancel,
}: PromotionModalProps) {
  const t = getTranslations(lang);
  const options: Array<{ type: PromotionPiece; label: string }> = [
    { type: 'q', label: t.pieces.q },
    { type: 'r', label: t.pieces.r },
    { type: 'b', label: t.pieces.b },
    { type: 'n', label: t.pieces.n },
  ];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={t.promotionAria}
      className="fixed inset-0 z-50 bg-black/45 backdrop-blur-[2px] flex items-center justify-center p-4"
    >
      <div className="soft-panel rounded-2xl max-w-sm w-full p-5 text-center">
        <h3 className="text-lg font-bold text-[var(--ink-primary)]">{t.promotionTitle}</h3>
        <p className="text-xs text-[var(--ink-secondary)] mt-1 mb-4">{t.promotionDesc}</p>
        <div className="grid grid-cols-4 gap-2">
          {options.map((opt) => (
            <button
              key={opt.type}
              type="button"
              onClick={() => onSelect(opt.type)}
              className="flex flex-col items-center gap-1.5 p-2.5 rounded-xl border border-[var(--border-subtle)] bg-[var(--surface-elevated)] hover:bg-[var(--surface-hover)] hover:border-[var(--border-strong)] transition-colors cursor-pointer"
            >
              <div className="w-11 h-11">
                <ChessPieceSvg type={opt.type} color={color} />
              </div>
              <span className="text-xs font-semibold text-[var(--ink-primary)]">{opt.label}</span>
            </button>
          ))}
        </div>
        <button
          type="button"
          onClick={onCancel}
          className="mt-4 text-xs font-semibold text-[var(--ink-secondary)] hover:text-[var(--ink-primary)] underline cursor-pointer"
        >
          {t.dismissPromo}
        </button>
      </div>
    </div>
  );
}

interface GameOverModalProps {
  variant?: GameVariant;
  outcome: GameOutcome;
  totalMoves: number;
  openingName: string;
  isOnline: boolean;
  isSpectator: boolean;
  rematchVoted: boolean;
  rematchCount: number;
  lang?: Language;
  onPlayAgain: () => void;
  onGoToMenu: () => void;
  onDismiss: () => void;
}

export function GameOverModal({
  variant = 'chess',
  outcome,
  totalMoves,
  openingName,
  isOnline,
  isSpectator,
  rematchVoted,
  rematchCount,
  lang = 'tr',
  onPlayAgain,
  onGoToMenu,
  onDismiss,
}: GameOverModalProps) {
  const t = getTranslations(lang);
  const heading =
    outcome.winner === 'draw'
      ? t.gameDrawTitle
      : outcome.winner === 'w'
        ? t.whiteWonTitle
        : t.blackWonTitle;
  const localizedOutcomeMessage = formatOutcomeMessage(outcome, lang);
  const localizedOpening =
    variant === 'shashki' ? t.shashkiClassicLabel : translateOpeningName(openingName, lang);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={t.gameOverAria}
      className="fixed inset-0 z-50 bg-black/45 backdrop-blur-[2px] flex items-center justify-center p-4"
    >
      <div className="soft-panel rounded-2xl max-w-md w-full p-6 text-center">
        <div className="w-12 h-12 mx-auto rounded-xl border border-[var(--border-subtle)] bg-[var(--surface-elevated)] flex items-center justify-center mb-3">
          <Trophy className="w-6 h-6 text-[var(--accent-gold)]" />
        </div>
        <h3 className="text-2xl font-bold tracking-tight text-[var(--ink-primary)]">{heading}</h3>
        <p className="text-sm text-[var(--ink-secondary)] mt-1.5">{localizedOutcomeMessage}</p>

        <div className="grid grid-cols-2 gap-3 my-5 text-left">
          <div className="rounded-xl bg-[var(--surface-elevated)] border border-[var(--border-subtle)] px-3.5 py-2.5">
            <span className="block text-[11px] text-[var(--ink-muted)]">{t.totalMovesLabel}</span>
            <span className="font-mono-tabular text-base font-bold text-[var(--ink-primary)]">
              {totalMoves}
            </span>
          </div>
          <div className="rounded-xl bg-[var(--surface-elevated)] border border-[var(--border-subtle)] px-3.5 py-2.5">
            <span className="block text-[11px] text-[var(--ink-muted)]">
              {variant === 'shashki' ? t.shashkiVariantLabel : t.openingLabel}
            </span>
            <span className="text-xs font-semibold text-[var(--ink-primary)] line-clamp-1">
              {localizedOpening}
            </span>
          </div>
        </div>

        <div className="flex flex-col gap-2">
          {!isSpectator && (
            <button
              type="button"
              data-start="true"
              disabled={isOnline && rematchVoted}
              onClick={onPlayAgain}
              className="w-full py-2.5 px-4 rounded-xl bg-[var(--btn-primary-bg)] text-[var(--btn-primary-text)] text-sm font-semibold inline-flex items-center justify-center gap-2 hover:bg-[var(--btn-primary-hover)] disabled:opacity-60 cursor-pointer whitespace-nowrap"
            >
              <RotateCcw className="w-4 h-4" />
              <span>
                {isOnline
                  ? rematchVoted
                    ? t.waitingRematch(rematchCount)
                    : t.requestRematch(rematchCount)
                  : t.playAgain}
              </span>
            </button>
          )}

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={onDismiss}
              className="py-2 px-3 rounded-lg border border-[var(--border-subtle)] bg-[var(--surface-elevated)] text-[var(--ink-primary)] text-xs font-semibold hover:bg-[var(--surface-hover)] cursor-pointer whitespace-nowrap"
            >
              {t.inspectBoard}
            </button>
            <button
              type="button"
              onClick={onGoToMenu}
              className="py-2 px-3 rounded-lg border border-[var(--border-subtle)] bg-[var(--surface-elevated)] text-[var(--ink-primary)] text-xs font-semibold inline-flex items-center justify-center gap-1.5 hover:bg-[var(--surface-hover)] cursor-pointer whitespace-nowrap"
            >
              <Home className="w-3.5 h-3.5" />
              <span>{t.mainMenu}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

interface OnlineWaitingBannerProps {
  roomCode: string;
  lang?: Language;
}

export function OnlineWaitingBanner({ roomCode, lang = 'tr' }: OnlineWaitingBannerProps) {
  const t = getTranslations(lang);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    const url = `${window.location.origin}/?room=${roomCode}`;
    void navigator.clipboard?.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      className="mb-1.5 px-3 py-1.5 soft-panel rounded-xl flex flex-wrap items-center justify-between gap-2"
      data-testid="online-waiting-banner"
    >
      <div className="flex items-baseline gap-2">
        <span className="text-xs font-semibold text-[var(--ink-secondary)]">
          {t.waitingBannerPrefix}
        </span>
        <span className="font-mono-tabular text-sm font-bold tracking-widest text-[var(--ink-primary)]">
          {roomCode}
        </span>
      </div>
      <button
        type="button"
        onClick={handleCopy}
        className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-[var(--btn-primary-bg)] text-[var(--btn-primary-text)] hover:bg-[var(--btn-primary-hover)] inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0"
      >
        {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
        <span>{copied ? t.copied : t.inviteLink}</span>
      </button>
    </div>
  );
}
