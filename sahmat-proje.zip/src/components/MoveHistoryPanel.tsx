import { memo, useEffect, useRef } from 'react';
import {
  ChevronFirst,
  ChevronLast,
  ChevronLeft,
  ChevronRight,
  Flag,
  Handshake,
  Home,
  RotateCcw,
  Settings,
} from 'lucide-react';
import { getTranslations, type Language } from '../game/i18n';
import type { GameVariant, MoveRecord, PieceColor } from '../game/types';

interface MoveHistoryPanelProps {
  variant?: GameVariant;
  shashkiMandatoryCapture?: boolean;
  shashkiChainActive?: boolean;
  moves: MoveRecord[];
  viewPly: number | null;
  onSelectPly: (ply: number | null) => void;
  turn: PieceColor;
  inCheck: boolean;
  openingName: string;
  isGameOver: boolean;
  isOnline: boolean;
  isSpectator: boolean;
  myRole?: PieceColor | 'spectator' | null;
  drawOfferFrom?: PieceColor | null;
  lang?: Language;
  onFlipBoard: () => void;
  onResign: () => void;
  onOfferDraw: () => void;
  onRespondDraw: (accept: boolean) => void;
  onRestartLocal: () => void;
  onGoToMenu: () => void;
  onOpenSettings: () => void;
}

export const MoveHistoryPanel = memo(function MoveHistoryPanel({
  variant = 'chess',
  shashkiMandatoryCapture = false,
  shashkiChainActive = false,
  moves,
  viewPly,
  onSelectPly,
  turn,
  inCheck,
  isGameOver,
  isOnline,
  isSpectator,
  myRole,
  drawOfferFrom,
  lang = 'tr',
  onFlipBoard,
  onResign,
  onOfferDraw,
  onRespondDraw,
  onRestartLocal,
  onGoToMenu,
  onOpenSettings,
}: MoveHistoryPanelProps) {
  const t = getTranslations(lang);
  const listRef = useRef<HTMLDivElement>(null);
  const activePly = viewPly === null ? moves.length : viewPly;
  const isViewingHistory = viewPly !== null && viewPly < moves.length;

  useEffect(() => {
    if (viewPly === null && listRef.current) {
      listRef.current.scrollTop = listRef.current.scrollHeight;
    }
  }, [moves.length, viewPly]);

  const pairs: Array<{ moveNumber: number; white?: MoveRecord; black?: MoveRecord }> = [];
  for (let i = 0; i < moves.length; i += 2) {
    pairs.push({
      moveNumber: Math.floor(i / 2) + 1,
      white: moves[i],
      black: moves[i + 1],
    });
  }

  const statusText = isGameOver
    ? t.gameOverStatus
    : isViewingHistory
      ? t.reviewMoveStatus(activePly)
      : variant === 'shashki'
        ? shashkiChainActive
          ? t.shashkiChainCaptureStatus(turn === 'w')
          : shashkiMandatoryCapture
            ? t.shashkiMandatoryCaptureStatus(turn === 'w')
            : t.turnStatus(turn === 'w')
        : inCheck
          ? t.checkTurnStatus(turn === 'w')
          : t.turnStatus(turn === 'w');

  const incomingDrawOffer =
    isOnline &&
    !isSpectator &&
    !isGameOver &&
    drawOfferFrom !== null &&
    drawOfferFrom !== undefined &&
    drawOfferFrom !== myRole;

  const outgoingDrawOffer =
    isOnline && !isSpectator && !isGameOver && drawOfferFrom === myRole;

  return (
    <aside
      className="soft-panel rounded-2xl overflow-hidden flex flex-col w-full lg:w-[258px] xl:w-[276px] lg:h-[min(560px,calc(100dvh-5rem))] shrink-0"
      aria-label={t.moveHistoryAria}
      data-testid="move-history-panel"
    >
      {/* Live Turn / Check Status Bar — directly above Move History */}
      <div
        data-testid="turn-status-bar"
        className={`px-3 py-1.5 lg:px-3.5 lg:py-2 text-xs font-semibold border-b border-[var(--border-subtle)] flex items-center justify-between gap-2 ${
          inCheck && !isGameOver
            ? 'bg-[#8B2B1E] text-[#FBF8F1]'
            : (shashkiChainActive || shashkiMandatoryCapture) && !isGameOver && !isViewingHistory
              ? 'bg-[var(--btn-accent-bg)] text-[var(--btn-accent-text)]'
              : isViewingHistory
                ? 'bg-[var(--btn-accent-bg)] text-[var(--btn-accent-text)]'
                : 'bg-[var(--surface-elevated)] text-[var(--ink-primary)]'
        }`}
      >
        <span>{statusText}</span>
        {isViewingHistory && (
          <button
            type="button"
            onClick={() => onSelectPly(null)}
            className="underline font-semibold whitespace-nowrap shrink-0 cursor-pointer"
          >
            {t.backToLive}
          </button>
        )}
      </div>

      {/* Move History Title + Direct White / Black Column Headers */}
      <div className="px-3 pt-2 pb-1.5 lg:px-3.5 lg:pt-2.5 lg:pb-1.5 border-b border-[var(--border-subtle)]">
        <div className="flex items-center justify-between gap-2">
          <h2 className="text-sm sm:text-[15px] font-bold tracking-tight text-[var(--ink-primary)]">
            {t.moveHistoryTitle}
          </h2>
          <span className="font-mono-tabular text-[11px] text-[var(--ink-muted)]">
            {t.moveCount(moves.length)}
          </span>
        </div>

        <div className="grid grid-cols-[2rem_1fr_1fr] items-center gap-1 mt-1.5 pt-1.5 border-t border-[var(--border-subtle)]/70 text-[11px] font-semibold text-[var(--ink-secondary)]">
          <span className="text-center text-[var(--ink-muted)]">#</span>
          <span className="inline-flex items-center gap-1.5 px-1.5">
            <span
              aria-hidden="true"
              className="w-2.5 h-2.5 rounded-full bg-[#F9F5EB] border border-black/35 shrink-0"
            />
            <span className="truncate">{t.white}</span>
          </span>
          <span className="inline-flex items-center gap-1.5 px-1.5">
            <span
              aria-hidden="true"
              className="w-2.5 h-2.5 rounded-full bg-[#2E2926] border border-black/45 shrink-0"
            />
            <span className="truncate">{t.black}</span>
          </span>
        </div>
      </div>

      {/* Incoming Draw Offer */}
      {incomingDrawOffer && (
        <div className="px-3 py-1.5 lg:px-3.5 lg:py-2 bg-[var(--surface-muted)] border-b border-[var(--border-subtle)] flex items-center justify-between gap-2">
          <span className="text-xs font-semibold text-[var(--ink-primary)]">
            {t.drawOfferReceived}
          </span>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => onRespondDraw(true)}
              className="px-2.5 py-1 rounded-md text-xs font-semibold bg-[var(--btn-primary-bg)] text-[var(--btn-primary-text)] hover:bg-[var(--btn-primary-hover)] cursor-pointer whitespace-nowrap"
            >
              {t.accept}
            </button>
            <button
              type="button"
              onClick={() => onRespondDraw(false)}
              className="px-2.5 py-1 rounded-md text-xs font-semibold border border-[var(--border-subtle)] text-[var(--ink-primary)] hover:bg-[var(--surface-hover)] cursor-pointer whitespace-nowrap"
            >
              {t.decline}
            </button>
          </div>
        </div>
      )}

      {/* Move List */}
      <div
        ref={listRef}
        className="flex-1 min-h-[64px] lg:min-h-[150px] max-h-[116px] lg:max-h-none overflow-y-auto px-3 py-1 lg:py-1.5"
      >
        {pairs.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center px-3 py-2 lg:py-6 text-[var(--ink-muted)]">
            <p className="text-xs sm:text-sm font-medium text-[var(--ink-primary)]">{t.noMovesYet}</p>
            <p className="text-[11px] mt-0.5">{t.noMovesHint}</p>
          </div>
        ) : (
          <table className="w-full border-collapse text-xs sm:text-sm font-mono-tabular">
            <tbody>
              {pairs.map((pair) => (
                <tr
                  key={pair.moveNumber}
                  className="border-b border-[var(--border-subtle)]/40 last:border-b-0"
                >
                  <td className="w-8 py-0.5 lg:py-1 text-center text-[11px] text-[var(--ink-muted)] select-none">
                    {pair.moveNumber}.
                  </td>
                  <td className="py-0.5 pr-1">
                    {pair.white && (
                      <button
                        type="button"
                        onClick={() =>
                          onSelectPly(
                            pair.white!.ply === moves.length ? null : pair.white!.ply,
                          )
                        }
                        className={`w-full text-left px-1.5 py-0.5 text-xs sm:text-[13px] rounded-md transition-colors cursor-pointer ${
                          activePly === pair.white.ply
                            ? 'bg-[var(--btn-primary-bg)] text-[var(--btn-primary-text)] font-semibold'
                            : 'text-[var(--ink-primary)] hover:bg-[var(--surface-hover)]'
                        }`}
                      >
                        {pair.white.san}
                      </button>
                    )}
                  </td>
                  <td className="py-0.5 pr-1">
                    {pair.black ? (
                      <button
                        type="button"
                        onClick={() =>
                          onSelectPly(
                            pair.black!.ply === moves.length ? null : pair.black!.ply,
                          )
                        }
                        className={`w-full text-left px-1.5 py-0.5 text-xs sm:text-[13px] rounded-md transition-colors cursor-pointer ${
                          activePly === pair.black.ply
                            ? 'bg-[var(--btn-primary-bg)] text-[var(--btn-primary-text)] font-semibold'
                            : 'text-[var(--ink-primary)] hover:bg-[var(--surface-hover)]'
                        }`}
                      >
                        {pair.black.san}
                      </button>
                    ) : (
                      <span className="px-1.5 py-0.5 text-xs text-[var(--ink-muted)]">…</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* History Navigation Bar */}
      <div className="grid grid-cols-4 border-t border-[var(--border-subtle)] bg-[var(--surface-elevated)]">
        <button
          type="button"
          aria-label={t.navFirstAria}
          disabled={moves.length === 0 || activePly === 0}
          onClick={() => onSelectPly(0)}
          className="flex items-center justify-center py-1.5 lg:py-2 text-[var(--ink-primary)] hover:bg-[var(--surface-hover)] disabled:opacity-35 disabled:pointer-events-none cursor-pointer border-r border-[var(--border-subtle)]"
        >
          <ChevronFirst className="w-4 h-4" />
        </button>
        <button
          type="button"
          aria-label={t.navPrevAria}
          disabled={moves.length === 0 || activePly === 0}
          onClick={() => onSelectPly(Math.max(0, activePly - 1))}
          className="flex items-center justify-center py-1.5 lg:py-2 text-[var(--ink-primary)] hover:bg-[var(--surface-hover)] disabled:opacity-35 disabled:pointer-events-none cursor-pointer border-r border-[var(--border-subtle)]"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
        <button
          type="button"
          aria-label={t.navNextAria}
          disabled={moves.length === 0 || activePly >= moves.length}
          onClick={() => {
            const next = activePly + 1;
            onSelectPly(next >= moves.length ? null : next);
          }}
          className="flex items-center justify-center py-1.5 lg:py-2 text-[var(--ink-primary)] hover:bg-[var(--surface-hover)] disabled:opacity-35 disabled:pointer-events-none cursor-pointer border-r border-[var(--border-subtle)]"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
        <button
          type="button"
          aria-label={t.navLastAria}
          disabled={moves.length === 0 || activePly >= moves.length}
          onClick={() => onSelectPly(null)}
          className="flex items-center justify-center py-1.5 lg:py-2 text-[var(--ink-primary)] hover:bg-[var(--surface-hover)] disabled:opacity-35 disabled:pointer-events-none cursor-pointer"
        >
          <ChevronLast className="w-4 h-4" />
        </button>
      </div>

      {/* Match Action Controls */}
      <div className="p-2 lg:p-2.5 border-t border-[var(--border-subtle)] bg-[var(--surface-muted)] flex flex-wrap items-center gap-1.5">
        <button
          type="button"
          onClick={onFlipBoard}
          className="flex-1 min-w-[84px] inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border border-[var(--border-subtle)] bg-[var(--surface-panel)] text-[var(--ink-primary)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>{t.flipBoard}</span>
        </button>

        <button
          type="button"
          onClick={onOpenSettings}
          aria-label={t.openSettingsAria}
          className="inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border border-[var(--border-subtle)] bg-[var(--surface-panel)] text-[var(--ink-primary)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          <Settings className="w-3.5 h-3.5" />
          <span>{t.settings}</span>
        </button>

        {isOnline && !isSpectator && !isGameOver && (
          <button
            type="button"
            disabled={outgoingDrawOffer}
            onClick={onOfferDraw}
            className="flex-1 min-w-[88px] inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border border-[var(--border-subtle)] bg-[var(--surface-panel)] text-[var(--ink-primary)] hover:bg-[var(--surface-hover)] disabled:opacity-50 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <Handshake className="w-3.5 h-3.5" />
            <span>{outgoingDrawOffer ? t.drawOfferSent : t.drawOffer}</span>
          </button>
        )}

        {!isSpectator && !isGameOver && (
          <button
            type="button"
            onClick={onResign}
            className="flex-1 min-w-[88px] inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border border-[#991B1B] bg-[#B91C1C] text-white hover:bg-[#991B1B] transition-colors cursor-pointer whitespace-nowrap shrink-0 shadow-sm"
          >
            <Flag className="w-3.5 h-3.5" />
            <span>{t.resign}</span>
          </button>
        )}

        {!isOnline && (
          <button
            type="button"
            onClick={onRestartLocal}
            className="flex-1 min-w-[90px] inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border border-[var(--border-subtle)] bg-[var(--surface-panel)] text-[var(--ink-primary)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{t.newGame}</span>
          </button>
        )}

        <button
          type="button"
          onClick={onGoToMenu}
          className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-1.5 lg:py-2 rounded-xl text-xs font-semibold bg-[var(--btn-primary-bg)] text-[var(--btn-primary-text)] hover:bg-[var(--btn-primary-hover)] transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          <Home className="w-3.5 h-3.5" />
          <span>{t.mainMenu}</span>
        </button>
      </div>
    </aside>
  );
});
