import { useEffect, type Dispatch, type SetStateAction } from 'react';
import { Globe, Music2, RotateCcw, Settings, Volume2, X } from 'lucide-react';
import { getTranslations, LANGUAGES, type Language } from '../game/i18n';
import { DEFAULT_SETTINGS, type GameSettings } from '../game/settings';
import type { ThemeSelection } from '../game/themes';
import type { GameVariant } from '../game/types';
import { ThemeSelector } from './ThemeSelector';

interface SettingsModalProps {
  variant?: GameVariant;
  settings: GameSettings;
  onChange: Dispatch<SetStateAction<GameSettings>>;
  themeSelection: ThemeSelection;
  onThemeChange: (next: ThemeSelection) => void;
  lang: Language;
  onLanguageChange: (lang: Language) => void;
  onClose: () => void;
}

interface ToggleRowProps {
  id: string;
  label: string;
  description: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}

function ToggleRow({ id, label, description, checked, onChange }: ToggleRowProps) {
  return (
    <div className="flex items-center justify-between gap-4 py-2">
      <label htmlFor={id} className="cursor-pointer min-w-0">
        <span className="block text-sm font-semibold text-[var(--ink-primary)]">{label}</span>
        <span className="block text-xs text-[var(--ink-secondary)] mt-0.5">{description}</span>
      </label>
      <button
        id={id}
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full border transition-colors cursor-pointer ${
          checked
            ? 'bg-[var(--btn-primary-bg)] border-transparent'
            : 'bg-[var(--surface-muted)] border-[var(--border-subtle)]'
        }`}
      >
        <span
          className={`inline-block h-4 w-4 rounded-full transition-transform ${
            checked
              ? 'translate-x-6 bg-[var(--btn-primary-text)]'
              : 'translate-x-1 bg-[var(--ink-secondary)]'
          }`}
        />
      </button>
    </div>
  );
}

export function SettingsModal({
  variant = 'chess',
  settings,
  onChange,
  themeSelection,
  onThemeChange,
  lang,
  onLanguageChange,
  onClose,
}: SettingsModalProps) {
  const t = getTranslations(lang);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [onClose]);

  const update = <K extends keyof GameSettings>(key: K, value: GameSettings[K]) => {
    onChange((prev) => ({ ...prev, [key]: value }));
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={t.settingsDialogAria}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 z-50 bg-black/45 backdrop-blur-[2px] flex items-center justify-center p-4"
    >
      <div
        className="soft-panel rounded-2xl max-w-lg w-full max-h-[92vh] flex flex-col overflow-hidden"
        data-testid="settings-modal"
      >
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-[var(--border-subtle)] flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <Settings className="w-5 h-5 text-[var(--accent-gold)]" aria-hidden="true" />
            <h2 className="text-lg font-bold tracking-tight text-[var(--ink-primary)]">
              {t.settings}
            </h2>
          </div>
          <button
            type="button"
            aria-label={t.closeSettingsAria}
            onClick={onClose}
            className="p-1.5 rounded-lg text-[var(--ink-secondary)] hover:text-[var(--ink-primary)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="px-5 py-3.5 overflow-y-auto flex flex-col gap-4">
          {/* Language Section */}
          <section aria-labelledby="settings-language-heading">
            <h3
              id="settings-language-heading"
              className="text-xs font-bold uppercase tracking-wider text-[var(--ink-muted)] mb-1.5 flex items-center gap-1.5"
            >
              <Globe className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{t.settingsLanguageSection}</span>
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 rounded-xl bg-[var(--surface-elevated)] border border-[var(--border-subtle)] p-2">
              {LANGUAGES.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  aria-pressed={lang === opt.id}
                  onClick={() => onLanguageChange(opt.id)}
                  className={`py-2 px-2 rounded-lg text-xs font-semibold border transition-colors cursor-pointer whitespace-nowrap ${
                    lang === opt.id
                      ? 'bg-[var(--btn-primary-bg)] text-[var(--btn-primary-text)] border-transparent shadow-sm'
                      : 'bg-[var(--surface-panel)] text-[var(--ink-primary)] border-[var(--border-subtle)] hover:bg-[var(--surface-hover)]'
                  }`}
                >
                  {opt.nativeLabel}
                </button>
              ))}
            </div>
          </section>

          {/* Audio & Music Section */}
          <section aria-labelledby="settings-audio-heading">
            <h3
              id="settings-audio-heading"
              className="text-xs font-bold uppercase tracking-wider text-[var(--ink-muted)] mb-1.5"
            >
              {t.settingsAudioSection}
            </h3>
            <div className="rounded-xl bg-[var(--surface-elevated)] border border-[var(--border-subtle)] px-4 py-1.5 divide-y divide-[var(--border-subtle)]">
              <div className="py-1.5 flex flex-col gap-1.5">
                <ToggleRow
                  id="setting-sfx-toggle"
                  label={t.sfxLabel}
                  description={t.sfxDesc}
                  checked={settings.sfxEnabled}
                  onChange={(val) => update('sfxEnabled', val)}
                />
                {settings.sfxEnabled && (
                  <div className="flex items-center gap-3 pb-1">
                    <Volume2 className="w-4 h-4 text-[var(--ink-secondary)] shrink-0" />
                    <input
                      type="range"
                      aria-label={t.sfxVolumeAria}
                      min={0}
                      max={100}
                      value={Math.round(settings.sfxVolume * 100)}
                      onChange={(e) => update('sfxVolume', Number(e.target.value) / 100)}
                      className="flex-1 accent-[var(--btn-primary-bg)] cursor-pointer"
                    />
                    <span className="font-mono-tabular text-xs text-[var(--ink-secondary)] w-9 text-right">
                      %{Math.round(settings.sfxVolume * 100)}
                    </span>
                  </div>
                )}
              </div>

              <div className="py-1.5 flex flex-col gap-1.5">
                <ToggleRow
                  id="setting-music-toggle"
                  label={t.musicLabel}
                  description={t.musicDesc}
                  checked={settings.musicEnabled}
                  onChange={(val) => update('musicEnabled', val)}
                />
                {settings.musicEnabled && (
                  <div className="flex items-center gap-3 pb-1">
                    <Music2 className="w-4 h-4 text-[var(--ink-secondary)] shrink-0" />
                    <input
                      type="range"
                      aria-label={t.musicVolumeAria}
                      min={0}
                      max={100}
                      value={Math.round(settings.musicVolume * 100)}
                      onChange={(e) => update('musicVolume', Number(e.target.value) / 100)}
                      className="flex-1 accent-[var(--btn-primary-bg)] cursor-pointer"
                    />
                    <span className="font-mono-tabular text-xs text-[var(--ink-secondary)] w-9 text-right">
                      %{Math.round(settings.musicVolume * 100)}
                    </span>
                  </div>
                )}
              </div>
            </div>
          </section>

          {/* Board & Gameplay Section */}
          <section aria-labelledby="settings-board-heading">
            <h3
              id="settings-board-heading"
              className="text-xs font-bold uppercase tracking-wider text-[var(--ink-muted)] mb-1.5"
            >
              {t.settingsBoardSection}
            </h3>
            <div className="rounded-xl bg-[var(--surface-elevated)] border border-[var(--border-subtle)] px-4 py-1 divide-y divide-[var(--border-subtle)]">
              <ToggleRow
                id="setting-legal-moves"
                label={t.legalMovesLabel}
                description={t.legalMovesDesc}
                checked={settings.showLegalMoves}
                onChange={(val) => update('showLegalMoves', val)}
              />
              <ToggleRow
                id="setting-coordinates"
                label={t.coordsLabel}
                description={t.coordsDesc}
                checked={settings.showCoordinates}
                onChange={(val) => update('showCoordinates', val)}
              />
              <ToggleRow
                id="setting-animate-pieces"
                label={t.animatePiecesLabel}
                description={t.animatePiecesDesc}
                checked={settings.animatePieces}
                onChange={(val) => update('animatePieces', val)}
              />
              {variant !== 'shashki' && (
                <ToggleRow
                  id="setting-auto-queen"
                  label={t.autoQueenLabel}
                  description={t.autoQueenDesc}
                  checked={settings.autoPromoteQueen}
                  onChange={(val) => update('autoPromoteQueen', val)}
                />
              )}
            </div>
          </section>

          {/* Theme Section */}
          <section aria-labelledby="settings-theme-heading">
            <h3
              id="settings-theme-heading"
              className="text-xs font-bold uppercase tracking-wider text-[var(--ink-muted)] mb-1.5"
            >
              {t.settingsThemeSection}
            </h3>
            <div className="rounded-xl bg-[var(--surface-elevated)] border border-[var(--border-subtle)] px-4 py-2.5">
              <ThemeSelector selection={themeSelection} onChange={onThemeChange} lang={lang} />
            </div>
          </section>
        </div>

        {/* Footer */}
        <div className="px-5 py-3.5 border-t border-[var(--border-subtle)] bg-[var(--surface-muted)] flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => onChange({ ...DEFAULT_SETTINGS })}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold border border-[var(--border-subtle)] bg-[var(--surface-panel)] text-[var(--ink-secondary)] hover:text-[var(--ink-primary)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{t.resetDefaults}</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-lg text-xs sm:text-sm font-semibold bg-[var(--btn-primary-bg)] text-[var(--btn-primary-text)] hover:bg-[var(--btn-primary-hover)] transition-colors cursor-pointer"
          >
            {t.done}
          </button>
        </div>
      </div>
    </div>
  );
}
