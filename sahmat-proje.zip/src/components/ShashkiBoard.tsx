import { memo, useCallback, useLayoutEffect, useMemo, useRef } from 'react';
import { getTranslations, type Language } from '../game/i18n';
import {
  getMandatoryCaptureSourceSquares,
  getShashkiStepTargets,
  type ShashkiBoardState,
  type ShashkiChainState,
} from '../game/shashkiRules';
import type { PieceColor } from '../game/types';
import { ShashkiPieceSvg } from './ShashkiPieceSvg';

interface ShashkiBoardProps {
  state: ShashkiBoardState;
  chainState: ShashkiChainState | null;
  orientation: PieceColor;
  interactive: boolean;
  canMoveColor?: PieceColor | 'both' | null;
  selectedSquare: string | null;
  lastMove?: { from: string; to: string } | null;
  onSquareClick: (square: string) => void;
  onPieceDrop?: (from: string, to: string) => void;
  showLegalMoves?: boolean;
  showCoordinates?: boolean;
  animatePieces?: boolean;
  lang?: Language;
}

const FILES = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];

function getVisualCoords(square: string, orientation: PieceColor): { col: number; row: number } {
  const f = FILES.indexOf(square[0]);
  const r = 8 - Number(square[1]);
  return orientation === 'w' ? { col: f, row: r } : { col: 7 - f, row: 7 - r };
}

interface ShashkiSquareCellProps {
  square: string;
  isLight: boolean;
  pieceColor: PieceColor | null;
  pieceIsKing: boolean;
  isSelected: boolean;
  isLastFrom: boolean;
  isLastTo: boolean;
  legalKind: 0 | 1 | 2;
  isMandatorySource: boolean;
  isGhostCaptured: boolean;
  pieceCanDrag: boolean;
  interactive: boolean;
  animatePieces: boolean;
  glideId: number;
  glideDxPct: number;
  glideDyPct: number;
  rankLabel?: string;
  fileLabel?: string;
  ariaLabel: string;
  onSquareClick: (square: string) => void;
  onSquareDrop: (fromSquare: string, toSquare: string) => void;
  onDragStartSquare: (square: string) => void;
}

const ShashkiSquareCell = memo(function ShashkiSquareCell({
  square,
  isLight,
  pieceColor,
  pieceIsKing,
  isSelected,
  isLastFrom,
  isLastTo,
  legalKind,
  isMandatorySource,
  isGhostCaptured,
  pieceCanDrag,
  interactive,
  animatePieces,
  glideId,
  glideDxPct,
  glideDyPct,
  rankLabel,
  fileLabel,
  ariaLabel,
  onSquareClick,
  onSquareDrop,
  onDragStartSquare,
}: ShashkiSquareCellProps) {
  const glideRef = useRef<HTMLDivElement | null>(null);
  const lastPlayedGlideIdRef = useRef<number>(0);

  useLayoutEffect(() => {
    if (glideId === 0) {
      lastPlayedGlideIdRef.current = 0;
      return;
    }
    if (lastPlayedGlideIdRef.current === glideId) return;
    lastPlayedGlideIdRef.current = glideId;

    const el = glideRef.current;
    if (!el) return;
    if (
      typeof window !== 'undefined' &&
      window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
    ) {
      return;
    }

    el.getAnimations?.().forEach((a) => a.cancel());
    el.style.willChange = 'transform';
    const anim = el.animate(
      [
        { transform: `translate3d(${glideDxPct}%, ${glideDyPct}%, 0) scale(1)` },
        {
          transform: `translate3d(${glideDxPct * 0.42}%, ${glideDyPct * 0.42}%, 0) scale(1.08)`,
          offset: 0.45,
        },
        { transform: 'translate3d(0%, 0%, 0) scale(1)' },
      ],
      {
        duration: 210,
        easing: 'cubic-bezier(0.22, 1, 0.36, 1)',
      },
    );
    const clearWillChange = () => {
      if (glideRef.current) {
        glideRef.current.style.willChange = 'auto';
      }
    };
    anim.onfinish = clearWillChange;
    anim.oncancel = clearWillChange;
  }, [glideDxPct, glideDyPct, glideId]);

  const baseColor = isLight ? '#E6CEA8' : '#7B5236';
  let overlayTint: string | undefined;
  if (isSelected) {
    overlayTint = 'linear-gradient(rgba(222, 168, 42, 0.54), rgba(222, 168, 42, 0.54))';
  } else if (isLastFrom || isLastTo) {
    overlayTint = 'linear-gradient(rgba(226, 180, 58, 0.32), rgba(226, 180, 58, 0.32))';
  }

  return (
    <button
      type="button"
      data-square={square}
      aria-label={ariaLabel}
      onClick={() => onSquareClick(square)}
      onDragOver={(e) => {
        if (interactive) e.preventDefault();
      }}
      onDrop={(e) => {
        if (!interactive) return;
        e.preventDefault();
        const fromSq = e.dataTransfer.getData('text/plain');
        if (fromSq && fromSq !== square) {
          onSquareDrop(fromSq, square);
        }
      }}
      style={{
        backgroundColor: baseColor,
        backgroundImage: overlayTint,
      }}
      className="relative aspect-square w-full h-full flex items-center justify-center p-[7.5%] overflow-visible focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[#211912]"
    >
      {rankLabel && (
        <span
          aria-hidden="true"
          className={`absolute top-[2px] left-[3px] text-[8px] sm:text-[9.5px] font-bold leading-none pointer-events-none select-none z-10 ${
            isLight ? 'text-[#6A452B]/85' : 'text-[#EFE0C4]/85'
          }`}
        >
          {rankLabel}
        </span>
      )}

      {fileLabel && (
        <span
          aria-hidden="true"
          className={`absolute bottom-[2px] right-[3px] text-[8px] sm:text-[9.5px] font-bold leading-none pointer-events-none select-none z-10 ${
            isLight ? 'text-[#6A452B]/85' : 'text-[#EFE0C4]/85'
          }`}
        >
          {fileLabel}
        </span>
      )}

      {isLastTo && animatePieces && glideId > 0 && (
        <span
          key={`settle-${glideId}`}
          aria-hidden="true"
          className="animate-square-settle absolute inset-[8%] rounded-full border-2 border-[#E6B33D]/80 pointer-events-none z-10"
        />
      )}

      {isMandatorySource && !isSelected && (
        <span
          aria-hidden="true"
          className="absolute inset-[9%] rounded-full border-2 border-[#E6B33D]/85 pointer-events-none z-10"
        />
      )}

      {legalKind === 1 && (
        <span
          aria-hidden="true"
          className={`w-[27%] h-[27%] rounded-full bg-[#1E1610]/35 pointer-events-none z-10 ${
            animatePieces ? 'animate-hint-pop' : ''
          }`}
        />
      )}

      {legalKind === 2 && (
        <span
          aria-hidden="true"
          className={`absolute inset-[8%] rounded-full border-[3.5px] border-[#E6B33D] pointer-events-none z-10 ${
            animatePieces ? 'animate-hint-pop' : ''
          }`}
        />
      )}

      {pieceColor && (
        <div
          ref={glideRef}
          key={`sh-${pieceColor}`}
          className={`w-full h-full transition-all duration-150 ${
            isGhostCaptured
              ? 'opacity-35 scale-90 z-10'
              : glideId > 0 || isSelected
                ? 'z-30'
                : 'z-20'
          }`}
        >
          <div
            draggable={pieceCanDrag}
            onDragStart={(e) => {
              if (!pieceCanDrag) {
                e.preventDefault();
                return;
              }
              e.dataTransfer.setData('text/plain', square);
              e.dataTransfer.effectAllowed = 'move';
              onDragStartSquare(square);
            }}
            className={`w-full h-full transition-transform duration-150 ${
              isSelected ? 'scale-[1.09] -translate-y-0.5' : ''
            } ${pieceCanDrag ? 'cursor-grab active:cursor-grabbing hover:scale-[1.03]' : ''}`}
          >
            <ShashkiPieceSvg color={pieceColor} isKing={pieceIsKing} />
          </div>
        </div>
      )}
    </button>
  );
});

export const ShashkiBoard = memo(function ShashkiBoard({
  state,
  chainState,
  orientation,
  interactive,
  canMoveColor,
  selectedSquare,
  lastMove,
  onSquareClick,
  onPieceDrop,
  showLegalMoves = true,
  showCoordinates = true,
  animatePieces = true,
  lang = 'tr',
}: ShashkiBoardProps) {
  const t = getTranslations(lang);

  const legalTargets = useMemo(() => {
    if (!interactive || !selectedSquare) return new Map<string, { isCapture: boolean }>();
    const list = getShashkiStepTargets(state, selectedSquare, chainState);
    return new Map(list.map((target) => [target.to, { isCapture: target.isCapture }]));
  }, [chainState, interactive, selectedSquare, state]);

  const mandatorySources = useMemo(() => {
    if (!interactive) return new Set<string>();
    return new Set(getMandatoryCaptureSourceSquares(state, chainState));
  }, [chainState, interactive, state]);

  const capturedInChainSet = useMemo(
    () => new Set(chainState?.capturedSquares ?? []),
    [chainState],
  );

  const rows = useMemo(() => {
    const indices = [0, 1, 2, 3, 4, 5, 6, 7];
    return orientation === 'w' ? indices : [...indices].reverse();
  }, [orientation]);

  const cols = useMemo(() => {
    const indices = [0, 1, 2, 3, 4, 5, 6, 7];
    return orientation === 'w' ? indices : [...indices].reverse();
  }, [orientation]);

  // Increment glideSeq strictly when lastMove changes
  const glideSeqRef = useRef<number>(0);
  const prevLastMoveRef = useRef<{ from: string; to: string } | null>(null);
  if (
    lastMove &&
    (prevLastMoveRef.current?.from !== lastMove.from ||
      prevLastMoveRef.current?.to !== lastMove.to)
  ) {
    glideSeqRef.current += 1;
    prevLastMoveRef.current = lastMove;
  } else if (!lastMove) {
    prevLastMoveRef.current = null;
  }

  const recentDropRef = useRef<{ from: string; to: string; ts: number } | null>(null);
  const onSquareClickRef = useRef(onSquareClick);
  const onPieceDropRef = useRef(onPieceDrop);
  const selectedSquareRef = useRef(selectedSquare);
  onSquareClickRef.current = onSquareClick;
  onPieceDropRef.current = onPieceDrop;
  selectedSquareRef.current = selectedSquare;

  const handleSquareClick = useCallback((sq: string) => {
    onSquareClickRef.current(sq);
  }, []);

  const handleSquareDrop = useCallback((fromSq: string, toSq: string) => {
    recentDropRef.current = { from: fromSq, to: toSq, ts: performance.now() };
    onPieceDropRef.current?.(fromSq, toSq);
  }, []);

  const handleDragStartSquare = useCallback((sq: string) => {
    if (selectedSquareRef.current !== sq) {
      onSquareClickRef.current(sq);
    }
  }, []);

  const activeDrop = recentDropRef.current;
  const skipDroppedGlide =
    Boolean(
      activeDrop &&
        lastMove &&
        activeDrop.from === lastMove.from &&
        activeDrop.to === lastMove.to &&
        performance.now() - activeDrop.ts < 450,
    );

  return (
    <div
      className="board-shell-frame rounded-xl p-1 select-none"
      data-testid="shashki-board"
    >
      <div className="grid grid-cols-8 aspect-square w-full border border-[#322318]/80 rounded-[4px] overflow-visible shadow-[inset_0_0_0_1px_rgba(255,255,255,0.12)]">
        {rows.map((r, rIdx) =>
          cols.map((c, cIdx) => {
            const isLight = (r + c) % 2 === 0;
            const square = `${FILES[c]}${8 - r}`;
            const piece = state.board[r][c];
            const isSelected = selectedSquare === square;
            const isLastFrom = lastMove?.from === square;
            const isLastTo = lastMove?.to === square;
            const legalInfo = legalTargets.get(square);
            const legalKind: 0 | 1 | 2 =
              showLegalMoves && legalInfo ? (legalInfo.isCapture ? 2 : 1) : 0;
            const isMandatorySource = showLegalMoves && mandatorySources.has(square);
            const isGhostCaptured = capturedInChainSet.has(square);

            const pieceCanDrag =
              interactive &&
              piece !== null &&
              !isGhostCaptured &&
              (canMoveColor === 'both' || canMoveColor === piece.color) &&
              piece.color === state.turn &&
              (!chainState || chainState.activeSquare === square);

            let glideId = 0;
            let glideDxPct = 0;
            let glideDyPct = 0;
            if (
              animatePieces &&
              lastMove &&
              isLastTo &&
              piece &&
              !isGhostCaptured &&
              !skipDroppedGlide
            ) {
              const fromCoords = getVisualCoords(lastMove.from, orientation);
              const toCoords = getVisualCoords(square, orientation);
              glideId = glideSeqRef.current;
              glideDxPct = (fromCoords.col - toCoords.col) * 100;
              glideDyPct = (fromCoords.row - toCoords.row) * 100;
            }

            const labelParts = [square];
            if (piece) {
              labelParts.push(piece.color === 'w' ? t.white : t.black);
              labelParts.push(piece.isKing ? t.shashkiKingPiece : t.shashkiManPiece);
            } else {
              labelParts.push(t.emptySquare);
            }
            if (legalInfo) {
              labelParts.push(legalInfo.isCapture ? t.captureMove : t.legalMove);
            }

            return (
              <ShashkiSquareCell
                key={square}
                square={square}
                isLight={isLight}
                pieceColor={piece ? piece.color : null}
                pieceIsKing={piece ? piece.isKing : false}
                isSelected={isSelected}
                isLastFrom={isLastFrom}
                isLastTo={isLastTo}
                legalKind={legalKind}
                isMandatorySource={isMandatorySource}
                isGhostCaptured={isGhostCaptured}
                pieceCanDrag={pieceCanDrag}
                interactive={interactive}
                animatePieces={animatePieces}
                glideId={glideId}
                glideDxPct={glideDxPct}
                glideDyPct={glideDyPct}
                rankLabel={showCoordinates && cIdx === 0 ? String(8 - r) : undefined}
                fileLabel={showCoordinates && rIdx === 7 ? FILES[c] : undefined}
                ariaLabel={labelParts.join(' ')}
                onSquareClick={handleSquareClick}
                onSquareDrop={handleSquareDrop}
                onDragStartSquare={handleDragStartSquare}
              />
            );
          }),
        )}
      </div>
    </div>
  );
});
