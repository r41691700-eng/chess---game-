import { memo, useEffect, useState } from 'react';
import { getTranslations, type Language } from '../game/i18n';
import type { GameVariant, PieceColor, PieceType } from '../game/types';
import { ChessPieceSvg } from './ChessPieceSvg';
import { ShashkiPieceSvg } from './ShashkiPieceSvg';

interface PlayerBarProps {
  name: string;
  color: PieceColor;
  isTurn: boolean;
  isLocalPlayer?: boolean;
  isSeated?: boolean;
  connected?: boolean;
  showConnectionState?: boolean;
  variant?: GameVariant;
  capturedPieces: PieceType[];
  shashkiCapturedCount?: number;
  materialAdvantage: number;
  clockMs: number;
  clockRunning?: boolean;
  turnStartedAt?: number | null;
  timed: boolean;
  lang?: Language;
}

export function formatClock(ms: number): string {
  const safeMs = Math.max(0, ms);
  const totalSec = Math.ceil(safeMs / 1000);
  const mins = Math.floor(totalSec / 60);
  const secs = totalSec % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export const PlayerBar = memo(function PlayerBar({
  name,
  color,
  isTurn,
  isLocalPlayer,
  isSeated = true,
  connected = true,
  showConnectionState = false,
  variant = 'chess',
  capturedPieces,
  shashkiCapturedCount = 0,
  materialAdvantage,
  clockMs,
  clockRunning = false,
  turnStartedAt = null,
  timed,
  lang = 'tr',
}: PlayerBarProps) {
  const t = getTranslations(lang);
  const computeDisplayMs = (): number => {
    if (!timed || !clockRunning || turnStartedAt === null) return clockMs;
    return Math.max(0, clockMs - Math.max(0, Date.now() - turnStartedAt));
  };

  const [displayedSec, setDisplayedSec] = useState<number>(() =>
    Math.ceil(Math.max(0, computeDisplayMs()) / 1000),
  );

  useEffect(() => {
    setDisplayedSec(Math.ceil(Math.max(0, computeDisplayMs()) / 1000));
    if (!timed || !clockRunning || turnStartedAt === null) return;
    const id = window.setInterval(() => {
      const nextSec = Math.ceil(Math.max(0, clockMs - Math.max(0, Date.now() - turnStartedAt)) / 1000);
      setDisplayedSec((prev) => (prev === nextSec ? prev : nextSec));
    }, 200);
    return () => window.clearInterval(id);
  }, [clockMs, clockRunning, timed, turnStartedAt]);

  const displayClockMs =
    timed && clockRunning && turnStartedAt !== null ? displayedSec * 1000 : clockMs;

  const capturedColor: PieceColor = color === 'w' ? 'b' : 'w';
  const lowTime = timed && displayClockMs > 0 && displayClockMs <= 30_000;

  return (
    <div
      className={`flex items-center justify-between gap-3 px-3 py-1.5 rounded-xl border transition-colors duration-200 ${
        isTurn
          ? 'bg-[var(--surface-panel)] border-[var(--border-strong)] shadow-sm'
          : 'bg-[var(--surface-elevated)]/85 border-[var(--border-subtle)]'
      }`}
    >
      <div className="flex items-center gap-2.5 min-w-0">
        <span
          aria-hidden="true"
          className={`w-4 h-4 shrink-0 border border-black/35 ${
            variant === 'shashki' ? 'rounded-full' : 'rounded-sm'
          } ${color === 'w' ? 'bg-[#F9F5EB]' : 'bg-[#2E2926]'}`}
        />
        <div className="flex items-baseline gap-2 min-w-0">
          <span className="font-semibold text-sm sm:text-[15px] text-[var(--ink-primary)] truncate">
            {name}
          </span>
          <span className="text-xs text-[var(--ink-secondary)] whitespace-nowrap shrink-0">
            {color === 'w' ? t.white : t.black}
            {isLocalPlayer ? ` · ${t.youBadge}` : ''}
            {showConnectionState && isSeated && !connected ? ` · ${t.disconnectedBadge}` : ''}
          </span>
        </div>
      </div>

      <div className="hidden sm:flex items-center gap-1 min-w-0 overflow-hidden">
        <div className="flex items-center -space-x-1">
          {variant === 'shashki'
            ? Array.from({ length: Math.min(12, shashkiCapturedCount) }).map((_, idx) => (
                <span key={`sh-cap-${idx}`} className="w-4 h-4 inline-block">
                  <ShashkiPieceSvg color={capturedColor} />
                </span>
              ))
            : capturedPieces.slice(0, 12).map((pieceType, idx) => (
                <span key={`${pieceType}-${idx}`} className="w-4 h-4 inline-block">
                  <ChessPieceSvg type={pieceType} color={capturedColor} />
                </span>
              ))}
        </div>
        {materialAdvantage > 0 && (
          <span className="font-mono-tabular text-xs font-semibold text-[var(--ink-secondary)] pl-1">
            +{materialAdvantage}
          </span>
        )}
      </div>

      <div className="flex items-center gap-2.5 shrink-0">
        {isTurn && (
          <span className="text-[11px] font-semibold text-[var(--accent-gold)] whitespace-nowrap shrink-0">
            {t.turnPill}
          </span>
        )}
        {timed && (
          <div
            className={`font-mono-tabular text-sm sm:text-base font-semibold px-2.5 py-0.5 rounded-lg border ${
              lowTime
                ? 'bg-[#8F281C] text-[#F9F5EB] border-[#5E160E]'
                : isTurn
                  ? 'bg-[var(--btn-primary-bg)] text-[var(--btn-primary-text)] border-transparent'
                  : 'bg-[var(--surface-muted)] text-[var(--ink-primary)] border-[var(--border-subtle)]'
            }`}
          >
            {formatClock(displayClockMs)}
          </div>
        )}
      </div>
    </div>
  );
});
