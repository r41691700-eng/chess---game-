import { memo } from 'react';
import type { PieceColor } from '../game/types';

interface ShashkiPieceSvgProps {
  color: PieceColor;
  isKing?: boolean;
  className?: string;
}

export const ShashkiPieceSvg = memo(function ShashkiPieceSvg({
  color,
  isKing = false,
  className = 'w-full h-full',
}: ShashkiPieceSvgProps) {
  const isWhite = color === 'w';
  const baseDepth = isWhite ? '#CFC1A5' : '#120F0D';
  const faceOuter = isWhite ? '#F4EDE0' : '#322B26';
  const faceInner = isWhite ? '#FCF9F1' : '#241F1B';
  const rimStroke = isWhite ? '#584330' : '#0D0A08';
  const grooveStroke = isWhite ? '#C6B79A' : '#4C423A';
  const highlightArc = isWhite ? 'rgba(255,255,255,0.85)' : 'rgba(255,255,255,0.14)';

  return (
    <svg viewBox="0 0 64 64" className={`${className} select-none`} aria-hidden="true">
      {/* Crisp zero-blur contact shadow (avoids CSS drop-shadow filter stutter) */}
      <circle cx="32" cy="36.4" r="24.6" fill="rgba(16,11,7,0.22)" />

      {/* Subtle 3D thickness edge */}
      <circle cx="32" cy="34.5" r="24.5" fill={baseDepth} stroke={rimStroke} strokeWidth="1.5" />

      {/* Main turned disc body */}
      <circle cx="32" cy="31" r="24.5" fill={faceOuter} stroke={rimStroke} strokeWidth="1.6" />

      {/* Recessed center well */}
      <circle cx="32" cy="31" r="19.5" fill={faceInner} stroke={grooveStroke} strokeWidth="1.35" />

      {/* Concentric lathe rings matching classic Şaşki discs */}
      <circle cx="32" cy="31" r="14.5" fill="none" stroke={grooveStroke} strokeWidth="1.2" />
      <circle cx="32" cy="31" r="9.4" fill="none" stroke={grooveStroke} strokeWidth="1.1" />
      {!isKing && <circle cx="32" cy="31" r="4.2" fill="none" stroke={grooveStroke} strokeWidth="1" />}

      {/* Top rim light sheen */}
      <path
        d="M 14 23 A 21 21 0 0 1 50 23"
        fill="none"
        stroke={highlightArc}
        strokeWidth="1.5"
        strokeLinecap="round"
      />

      {/* Damka (King) crown medallion */}
      {isKing && (
        <g className="animate-crown-pop">
          <circle
            cx="32"
            cy="31"
            r="11.5"
            fill={isWhite ? '#D1A045' : '#C8963B'}
            stroke={isWhite ? '#7A5416' : '#F3D693'}
            strokeWidth="1.4"
          />
          <path
            d="M24.5 35.5h15l1.3-7.4-4.6 3.3L32 25.4l-4.2 6-4.6-3.3 1.3 7.4z"
            fill={isWhite ? '#FFF9EC' : '#1E1813'}
            stroke={isWhite ? '#6E4B12' : '#FCE4A6'}
            strokeWidth="1.1"
            strokeLinejoin="round"
          />
          <rect
            x="24.5"
            y="36.3"
            width="15"
            height="2.1"
            rx="0.9"
            fill={isWhite ? '#FFF9EC' : '#1E1813'}
          />
        </g>
      )}
    </svg>
  );
});
