import type { GameVariant } from '../game/types';

interface GameBrandTitleProps {
  variant: GameVariant;
  title: string;
  size?: 'sm' | 'lg';
}

export function GameBrandTitle({ variant, title, size = 'sm' }: GameBrandTitleProps) {
  const isLarge = size === 'lg';

  return (
    <div className={`inline-flex items-center ${isLarge ? 'gap-3 sm:gap-4' : 'gap-2.5 sm:gap-3'} min-w-0`}>
      <div
        className={`relative flex items-center justify-center shrink-0 border border-[var(--border-strong)] bg-[var(--surface-panel)] shadow-sm overflow-hidden ${
          isLarge ? 'w-12 h-12 sm:w-16 sm:h-16 rounded-xl sm:rounded-2xl' : 'w-8 h-8 sm:w-9 sm:h-9 rounded-lg'
        }`}
        aria-hidden="true"
      >
        <div
          className="absolute inset-0 opacity-[0.14] pointer-events-none"
          style={{
            background:
              'radial-gradient(circle at 30% 25%, var(--accent-gold), transparent 72%)',
          }}
        />
        {variant === 'shashki' ? (
          <svg
            viewBox="0 0 36 36"
            className={isLarge ? 'w-8 h-8 sm:w-9 sm:h-9 relative' : 'w-5 h-5 sm:w-[22px] sm:h-[22px] relative'}
          >
            {/* Outer wooden checker ring */}
            <circle
              cx="18"
              cy="18"
              r="13.5"
              fill="var(--ink-primary)"
              stroke="var(--accent-gold)"
              strokeWidth="1.5"
            />
            {/* Concentric lathe grooves */}
            <circle
              cx="18"
              cy="18"
              r="9.8"
              fill="none"
              stroke="var(--surface-panel)"
              strokeOpacity="0.45"
              strokeWidth="1.1"
            />
            <circle
              cx="18"
              cy="18"
              r="6.2"
              fill="none"
              stroke="var(--accent-gold)"
              strokeWidth="1.2"
            />
            {/* Crown center emblem */}
            <path
              d="M13.6 20.4l1.1-4.6 3.3 2.3 3.3-2.3 1.1 4.6h-8.8z"
              fill="var(--accent-gold)"
            />
            <circle cx="18" cy="14.2" r="1.05" fill="var(--surface-panel)" />
          </svg>
        ) : (
          <svg
            viewBox="0 0 48 48"
            className={isLarge ? 'w-8 h-8 sm:w-9 sm:h-9 relative' : 'w-5 h-5 sm:w-[22px] sm:h-[22px] relative'}
          >
            <path
              d="M24 6v6M21 9h6"
              stroke="var(--accent-gold)"
              strokeWidth="2.4"
              strokeLinecap="round"
            />
            <path
              d="M16 18l8-4 8 4-2 9H18l-2-9zM14 31h20l2 5H12l2-5zM11 39h26v3H11v-3z"
              fill="var(--ink-primary)"
              stroke="var(--ink-primary)"
              strokeWidth="1.4"
              strokeLinejoin="round"
            />
            <path d="M16 28.5h16" stroke="var(--accent-gold)" strokeWidth="2" strokeLinecap="round" />
            <circle cx="24" cy="21" r="2.2" fill="var(--accent-gold)" />
          </svg>
        )}
      </div>

      <div className="flex flex-col min-w-0">
        <h1
          className={`font-display font-bold text-[var(--ink-primary)] leading-none truncate ${
            isLarge
              ? 'text-[28px] sm:text-5xl tracking-[0.08em] sm:tracking-[0.12em]'
              : 'text-[19px] sm:text-[22px] tracking-[0.12em]'
          }`}
        >
          {title}
        </h1>
        <span
          aria-hidden="true"
          className={`block rounded-full ${isLarge ? 'mt-1.5 h-[2.5px] w-16' : 'mt-1 h-[2px] w-9'}`}
          style={{
            background: 'linear-gradient(90deg, var(--accent-gold) 0%, transparent 100%)',
          }}
        />
      </div>
    </div>
  );
}
