import { memo } from 'react';
import type { PieceColor, PieceType } from '../game/types';

interface ChessPieceSvgProps {
  type: PieceType;
  color: PieceColor;
  className?: string;
}

export const ChessPieceSvg = memo(function ChessPieceSvg({
  type,
  color,
  className = 'w-full h-full',
}: ChessPieceSvgProps) {
  const isWhite = color === 'w';
  const fill = isWhite ? '#F9F5EB' : '#332E2B';
  const fillShadow = isWhite ? '#E5DBC7' : '#231F1D';
  const outerStroke = isWhite ? '#201913' : '#14110E';
  const innerStroke = isWhite ? '#201913' : '#B5AA9B';

  return (
    <svg viewBox="0 0 45 45" className={`${className} select-none`} aria-hidden="true">
      {/* Crisp zero-blur ground contact shadow (avoids CSS drop-shadow filter stutter) */}
      <ellipse cx="22.5" cy="40.3" rx="13.5" ry="2.1" fill="rgba(20,14,10,0.22)" />

      {type === 'p' && (
        <g strokeLinecap="round" strokeLinejoin="round">
          <path
            d="M22.5 9c-2.21 0-4 1.79-4 4 0 .89.29 1.71.78 2.38C17.33 16.5 16 18.59 16 21c0 2.03.94 3.84 2.41 5.03-3 1.06-7.41 5.55-7.41 13.47h23c0-7.92-4.41-12.41-7.41-13.47 1.47-1.19 2.41-3 2.41-5.03 0-2.41-1.33-4.5-3.28-5.62.49-.67.78-1.49.78-2.38 0-2.21-1.79-4-4-4z"
            fill={fill}
            stroke={outerStroke}
            strokeWidth="1.65"
          />
          <path d="M14 37.5h17" fill="none" stroke={innerStroke} strokeWidth="1.35" />
          <path
            d="M18.2 26.2c1.4.45 2.85.65 4.3.65s2.9-.2 4.3-.65"
            fill="none"
            stroke={innerStroke}
            strokeWidth="1.2"
          />
        </g>
      )}

      {type === 'r' && (
        <g strokeLinecap="round" strokeLinejoin="round">
          <path
            d="M9 39h27v-3H9v3zM12 36v-4h21v4H12zM11 14V9h4v2h5V9h5v2h5V9h4v5"
            fill={fill}
            stroke={outerStroke}
            strokeWidth="1.6"
          />
          <path d="M34 14l-3 3H14l-3-3" fill={fillShadow} stroke={outerStroke} strokeWidth="1.55" />
          <path d="M31 17v12.5H14V17" fill={fill} stroke={outerStroke} strokeWidth="1.6" />
          <path
            d="M31 29.5l1.5 2.5h-20l1.5-2.5"
            fill={fillShadow}
            stroke={outerStroke}
            strokeWidth="1.55"
          />
          <path d="M11 14h23" fill="none" stroke={innerStroke} strokeWidth="1.25" />
          <path
            d="M14 17h17M14 29.5h17M12.5 32h20"
            fill="none"
            stroke={innerStroke}
            strokeWidth="1.15"
          />
        </g>
      )}

      {type === 'n' && (
        <g strokeLinecap="round" strokeLinejoin="round">
          <path
            d="M 22,10 C 32.5,11 38.5,18 38,39 L 15,39 C 15,30 25,32.5 23,18"
            fill={fill}
            stroke={outerStroke}
            strokeWidth="1.65"
          />
          <path
            d="M 24,18 C 24.38,20.91 18.45,25.37 16,27 C 13,29 13.18,31.34 11,31 C 9.958,30.06 12.41,27.96 11,28 C 10,28 11.19,29.23 10,30 C 9,30 5.997,31 6,26 C 6,24 12,14 12,14 C 12,14 13.89,12.1 14,10.5 C 13.27,9.506 13.5,8.5 13.5,7.5 C 14.5,6.5 16.5,10 16.5,10 L 18.5,10 C 18.5,10 19.28,8.008 21,7 C 22,7 22,10 22,10"
            fill={fill}
            stroke={outerStroke}
            strokeWidth="1.65"
          />
          <circle cx="15" cy="15.5" r="1.1" fill={innerStroke} />
          <path
            d="M 9.2,25.5 A 0.5 0.5 0 1 1 8.4,26.1 A 0.5 0.5 0 1 1 9.2,25.5 z"
            fill={innerStroke}
          />
          <path
            d="M 24.55,10.4 L 24.1,11.85 L 24.6,12 C 27.75,13 30.25,14.49 32.5,18.75 C 34.75,23.01 35.75,29.06 35.25,39 L 35.2,39.5 L 37.45,39.5 L 37.5,39 C 38,28.94 36.62,22.15 34.25,17.66 C 31.88,13.17 28.46,11.02 25.06,10.5 L 24.55,10.4 z"
            fill={isWhite ? '#E5DBC7' : '#857A6D'}
            stroke="none"
            opacity={isWhite ? '0.65' : '0.45'}
          />
          <path d="M15 36.5h22.5" fill="none" stroke={innerStroke} strokeWidth="1.25" />
        </g>
      )}

      {type === 'b' && (
        <g strokeLinecap="round" strokeLinejoin="round">
          <path
            d="M9 36c3.39-.97 10.11.43 13.5-2 3.39 2.43 10.11 1.03 13.5 2 0 0 1.65.54 3 2-.68.97-1.65.99-3 .5-3.39-.97-10.11.46-13.5-1-3.39 1.46-10.11.03-13.5 1-1.354.49-2.323.47-3-.5 1.354-1.94 3-2 3-2z"
            fill={fill}
            stroke={outerStroke}
            strokeWidth="1.6"
          />
          <path
            d="M15 32c2.5 2.5 12.5 2.5 15 0 .5-1.5 0-2 0-2 0-2.5-2.5-4-2.5-4 5.5-1.5 6-11.5-5-15.5-11 4-10.5 14-5 15.5 0 0-2.5 1.5-2.5 4 0 0-.5.5 0 2z"
            fill={fill}
            stroke={outerStroke}
            strokeWidth="1.6"
          />
          <circle cx="22.5" cy="8" r="2.5" fill={fill} stroke={outerStroke} strokeWidth="1.6" />
          <path
            d="M17.5 26h10M15 30h15m-7.5-14.5v5M20 18h5"
            fill="none"
            stroke={innerStroke}
            strokeWidth="1.35"
          />
        </g>
      )}

      {type === 'q' && (
        <g strokeLinecap="round" strokeLinejoin="round">
          <circle cx="6" cy="12" r="2.4" fill={fill} stroke={outerStroke} strokeWidth="1.5" />
          <circle cx="14" cy="9" r="2.4" fill={fill} stroke={outerStroke} strokeWidth="1.5" />
          <circle cx="22.5" cy="8" r="2.4" fill={fill} stroke={outerStroke} strokeWidth="1.5" />
          <circle cx="31" cy="9" r="2.4" fill={fill} stroke={outerStroke} strokeWidth="1.5" />
          <circle cx="39" cy="12" r="2.4" fill={fill} stroke={outerStroke} strokeWidth="1.5" />
          <path
            d="M9 26c8.5-1.5 21-1.5 27 0l2.5-12.5L31 25l-.3-14.1-5.2 13.6-3-14.5-3 14.5-5.2-13.6L14 25 6.5 13.5 9 26z"
            fill={fill}
            stroke={outerStroke}
            strokeWidth="1.6"
          />
          <path
            d="M9 26c0 2 1.5 2 2.5 4 1 1.5 1 1 .5 3.5-1.5 1-1.5 2.5-1.5 2.5-1.5 1.5.5 2.5.5 2.5 6.5 1 16.5 1 23 0 0 0 1.5-1 0-2.5 0 0 .5-1.5-1-2.5-.5-2.5-.5-2 .5-3.5 1-2 2.5-2 2.5-4-8.5-1.5-18.5-1.5-27 0z"
            fill={fill}
            stroke={outerStroke}
            strokeWidth="1.6"
          />
          <path
            d="M11.5 30c3.5-1 18.5-1 22 0M12 33.5c6-1 15-1 21 0M11 36.5c6-1 17-1 23 0"
            fill="none"
            stroke={innerStroke}
            strokeWidth="1.25"
          />
        </g>
      )}

      {type === 'k' && (
        <g strokeLinecap="round" strokeLinejoin="round">
          <path d="M22.5 11.63V6M20 8h5" fill="none" stroke={outerStroke} strokeWidth="1.8" />
          <path
            d="M22.5 25s4.5-7.5 3-10.5c0 0-1-2.5-3-2.5s-3 2.5-3 2.5c-1.5 3 3 10.5 3 10.5"
            fill={fill}
            stroke={outerStroke}
            strokeWidth="1.6"
          />
          <path
            d="M11.5 37c5.5 3.5 15.5 3.5 21 0v-7s9-4.5 6-10.5c-4-6.5-13.5-3.5-16 4V27v-3.5c-3.5-7.5-13-10.5-16-4-3 6 5 10 5 10V37z"
            fill={fill}
            stroke={outerStroke}
            strokeWidth="1.6"
          />
          <path
            d="M11.5 30c5.5-3 15.5-3 21 0m-21 3.5c5.5-3 15.5-3 21 0m-21 3.5c5.5-3 15.5-3 21 0"
            fill="none"
            stroke={innerStroke}
            strokeWidth="1.3"
          />
        </g>
      )}
    </svg>
  );
});
