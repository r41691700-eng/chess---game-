import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ChessBoard } from './components/ChessBoard';
import { GameBrandTitle } from './components/GameBrandTitle';
import { GameOverModal, OnlineWaitingBanner, PromotionModal } from './components/GameModals';
import { MainMenu } from './components/MainMenu';
import { MoveHistoryPanel } from './components/MoveHistoryPanel';
import { PlayerBar } from './components/PlayerBar';
import { SettingsModal } from './components/SettingsModal';
import { ShashkiBoard } from './components/ShashkiBoard';
import {
  getSavedLanguage,
  getTranslations,
  saveLanguage,
  translateServerError,
  type Language,
} from './game/i18n';
import {
  getSavedSettings,
  saveSettings,
  type GameSettings,
} from './game/settings';
import {
  getCustomThemeCssVars,
  getSavedThemeSelection,
  saveThemeSelection,
  type ThemeSelection,
} from './game/themes';
import {
  applyMove,
  chooseBotMove,
  detectOpeningName,
  getCapturedAndMaterial,
  getLegalMovesForSquare,
  getPieceAtSquare,
  getTurn,
  INITIAL_FEN,
  isInCheck,
  isPromotionMove,
} from './game/chessRules';
import {
  applyInteractiveShashkiStep,
  chooseShashkiBotMove,
  countShashkiPieces,
  createInitialShashkiState,
  deserializeShashkiState,
  getShashkiStepTargets,
  hasMandatoryCapture,
  serializeShashkiState,
  squareToRc,
  type ShashkiBoardState,
  type ShashkiChainState,
  type ShashkiFullMove,
} from './game/shashkiRules';
import type { BotWorkerRequest, BotWorkerResponse } from './game/botWorker';
import {
  TIME_CONTROLS,
  type BotDifficulty,
  type ClientWsMessage,
  type GameMode,
  type GameOutcome,
  type GameVariant,
  type MoveRecord,
  type PieceColor,
  type PromotionPiece,
  type RoomPublicState,
  type ServerWsMessage,
  type SidePreference,
  type TimeControlKey,
} from './game/types';
import {
  applyAudioSettings,
  playCaptureSound,
  playCastleSound,
  playCheckSound,
  playGameOverSound,
  playGameStartMusic,
  playMoveSound,
  playSelectSound,
  startBackgroundMusic,
  stopBackgroundMusic,
  warmupAudio,
} from './utils/sound';

type ScreenState = 'title' | 'playing' | 'gameover';

function getOrCreatePlayerToken(): string {
  try {
    const existing = sessionStorage.getItem('sahmat_player_token');
    if (existing) return existing;
    const next =
      typeof crypto !== 'undefined' && crypto.randomUUID
        ? crypto.randomUUID()
        : `tok-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
    sessionStorage.setItem('sahmat_player_token', next);
    return next;
  } catch {
    return `tok-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  }
}

function getInitialQueryParams(): { autostart: boolean; roomCode: string } {
  if (typeof window === 'undefined') return { autostart: false, roomCode: '' };
  const params = new URLSearchParams(window.location.search);
  return {
    autostart: params.get('autostart') === '1',
    roomCode: (params.get('room') ?? '').trim().toUpperCase(),
  };
}

const CUSTOM_CSS_KEYS = Object.keys(getCustomThemeCssVars('#E8EFF5'));

export default function App() {
  const initialQuery = useMemo(() => getInitialQueryParams(), []);
  const playerTokenRef = useRef<string>(getOrCreatePlayerToken());

  const [screen, setScreen] = useState<ScreenState>(
    initialQuery.autostart ? 'playing' : 'title',
  );
  const [gameVariant, setGameVariant] = useState<GameVariant>('chess');
  const [gameMode, setGameMode] = useState<GameMode>('bot');
  const [playerName, setPlayerName] = useState<string>('Oyuncu');
  const playerNameRef = useRef<string>(playerName);
  const [lang, setLang] = useState<Language>(() => getSavedLanguage());
  const langRef = useRef<Language>(lang);
  const [settings, setSettings] = useState<GameSettings>(() => getSavedSettings());
  const [showSettingsModal, setShowSettingsModal] = useState<boolean>(false);
  const [themeSelection, setThemeSelection] = useState<ThemeSelection>(() =>
    getSavedThemeSelection(),
  );

  // Offline / Local / Bot game state
  const [botDifficulty, setBotDifficulty] = useState<BotDifficulty>('medium');
  const [humanBotSide, setHumanBotSide] = useState<PieceColor>('w');
  const [timeControl, setTimeControl] = useState<TimeControlKey>('10+0');
  const [localFen, setLocalFen] = useState<string>(INITIAL_FEN);
  const [shashkiState, setShashkiState] = useState<ShashkiBoardState>(() =>
    createInitialShashkiState(),
  );
  const [shashkiChain, setShashkiChain] = useState<ShashkiChainState | null>(null);
  const [shashkiLastStep, setShashkiLastStep] = useState<{ from: string; to: string } | null>(
    null,
  );
  const [localMoves, setLocalMoves] = useState<MoveRecord[]>([]);
  const [localClocks, setLocalClocks] = useState<{ w: number; b: number }>({
    w: TIME_CONTROLS['10+0'].initialMs,
    b: TIME_CONTROLS['10+0'].initialMs,
  });
  const [localTurnStartedAt, setLocalTurnStartedAt] = useState<number | null>(null);
  const [localOutcome, setLocalOutcome] = useState<GameOutcome | null>(null);

  const shashkiStateRef = useRef(shashkiState);
  const shashkiChainRef = useRef(shashkiChain);
  const localMovesRef = useRef(localMoves);
  const localTurnStartedAtRef = useRef(localTurnStartedAt);
  const timeControlRef = useRef(timeControl);
  useEffect(() => {
    shashkiStateRef.current = shashkiState;
  }, [shashkiState]);
  useEffect(() => {
    shashkiChainRef.current = shashkiChain;
  }, [shashkiChain]);
  useEffect(() => {
    localMovesRef.current = localMoves;
  }, [localMoves]);
  useEffect(() => {
    localTurnStartedAtRef.current = localTurnStartedAt;
  }, [localTurnStartedAt]);
  useEffect(() => {
    timeControlRef.current = timeControl;
  }, [timeControl]);

  // Online WebSocket state
  const wsRef = useRef<WebSocket | null>(null);
  const [wsConnected, setWsConnected] = useState<boolean>(false);
  const [onlineRoom, setOnlineRoom] = useState<RoomPublicState | null>(null);
  const [onlineRole, setOnlineRole] = useState<PieceColor | 'spectator' | null>(null);
  const [onlineClockSyncedAt, setOnlineClockSyncedAt] = useState<number | null>(null);
  const [matchmakingWaiting, setMatchmakingWaiting] = useState<boolean>(false);
  const [onlineError, setOnlineError] = useState<string | null>(null);
  const onlineRoomRef = useRef<RoomPublicState | null>(null);
  const onlineRoleRef = useRef<PieceColor | 'spectator' | null>(null);
  const autoJoinedRoomRef = useRef<boolean>(false);
  const prevOnlineMoveCountRef = useRef<number>(0);
  const prevOnlineStatusRef = useRef<RoomPublicState['status'] | null>(null);

  // Persistent Bot Web Worker refs
  const botWorkerRef = useRef<Worker | null>(null);
  const botRequestIdRef = useRef<number>(0);

  // Shared UI board interaction state
  const [orientation, setOrientation] = useState<PieceColor>('w');
  const [selectedSquare, setSelectedSquare] = useState<string | null>(null);
  const [viewPly, setViewPly] = useState<number | null>(null);
  const [pendingPromotion, setPendingPromotion] = useState<{
    from: string;
    to: string;
    color: PieceColor;
  } | null>(null);
  const [showGameOverModal, setShowGameOverModal] = useState<boolean>(false);

  useEffect(() => {
    playerNameRef.current = playerName;
  }, [playerName]);

  useEffect(() => {
    langRef.current = lang;
    saveLanguage(lang);
    document.documentElement.lang = lang;
    setPlayerName((prev) => {
      if (prev === 'Oyuncu' || prev === 'Player' || prev === 'Игрок' || prev === 'Oyunçu') {
        return getTranslations(lang).defaultPlayerName;
      }
      return prev;
    });
  }, [lang]);

  const ensureBotWorker = useCallback((): Worker | null => {
    if (typeof Worker !== 'undefined' && !botWorkerRef.current) {
      botWorkerRef.current = new Worker(
        new URL('./game/botWorker.ts', import.meta.url),
        { type: 'module' },
      );
    }
    return botWorkerRef.current;
  }, []);

  useEffect(() => {
    document.body.dataset.state = screen;
    window.scrollTo(0, 0);
  }, [screen]);

  useEffect(() => {
    saveSettings(settings);
    applyAudioSettings({
      sfxEnabled: settings.sfxEnabled,
      sfxVolume: settings.sfxVolume,
      musicEnabled: settings.musicEnabled,
      musicVolume: settings.musicVolume,
    });
    if (screen === 'playing' && settings.musicEnabled) {
      startBackgroundMusic();
    } else if (!settings.musicEnabled || screen === 'title') {
      stopBackgroundMusic();
    }
  }, [screen, settings]);

  useEffect(() => {
    const root = document.documentElement;
    root.dataset.theme = themeSelection.id;
    if (themeSelection.id === 'custom') {
      const vars = getCustomThemeCssVars(themeSelection.customHex);
      for (const [k, v] of Object.entries(vars)) {
        root.style.setProperty(k, v);
      }
    } else {
      for (const key of CUSTOM_CSS_KEYS) {
        root.style.removeProperty(key);
      }
    }
    saveThemeSelection(themeSelection);
  }, [themeSelection]);

  const isOnline = gameMode === 'online' && onlineRoom !== null;
  const activeFen = isOnline ? onlineRoom.fen : localFen;
  const activeMoves = isOnline ? onlineRoom.moves : localMoves;
  const activeShashkiChain =
    isOnline && onlineRoom?.variant === 'shashki'
      ? (onlineRoom.shashkiChain ?? null)
      : shashkiChain;
  const activeTurn = isOnline
    ? onlineRoom.turn
    : gameVariant === 'shashki'
      ? shashkiState.turn
      : getTurn(localFen);
  const activeOutcome = isOnline ? onlineRoom.outcome : localOutcome;
  const activeTimeControl = isOnline ? onlineRoom.timeControl : timeControl;
  const activeOpeningName =
    gameVariant === 'shashki'
      ? 'Klasik Şaşki'
      : isOnline
        ? onlineRoom.openingName
        : detectOpeningName(localMoves.map((m) => m.san));

  const displayedFen = useMemo(() => {
    if (viewPly === null || viewPly >= activeMoves.length) return activeFen;
    if (viewPly <= 0) return INITIAL_FEN;
    return activeMoves[viewPly - 1]?.fen ?? activeFen;
  }, [activeFen, activeMoves, viewPly]);

  const displayedShashkiState = useMemo(() => {
    if (gameVariant !== 'shashki') return shashkiState;
    if (viewPly === null || viewPly >= activeMoves.length) return shashkiState;
    if (viewPly <= 0) return createInitialShashkiState();
    const key = activeMoves[viewPly - 1]?.fen;
    return key ? deserializeShashkiState(key) : shashkiState;
  }, [activeMoves, gameVariant, shashkiState, viewPly]);

  const displayedLastMove = useMemo(() => {
    if (gameVariant === 'shashki' && viewPly === null && shashkiLastStep) {
      return shashkiLastStep;
    }
    const idx = viewPly === null ? activeMoves.length - 1 : viewPly - 1;
    if (idx < 0 || !activeMoves[idx]) return null;
    return { from: activeMoves[idx].from, to: activeMoves[idx].to };
  }, [activeMoves, gameVariant, shashkiLastStep, viewPly]);

  const isViewingHistory = viewPly !== null && viewPly < activeMoves.length;
  const displayedInCheck = useMemo(
    () => (gameVariant === 'chess' ? isInCheck(displayedFen) : false),
    [displayedFen, gameVariant],
  );
  const capturedSummary = useMemo(
    () =>
      gameVariant === 'chess'
        ? getCapturedAndMaterial(displayedFen)
        : {
            capturedByWhite: [],
            capturedByBlack: [],
            whiteAdvantage: 0,
            blackAdvantage: 0,
          },
    [displayedFen, gameVariant],
  );
  const shashkiCounts = useMemo(
    () => (gameVariant === 'shashki' ? countShashkiPieces(displayedShashkiState) : null),
    [displayedShashkiState, gameVariant],
  );
  const shashkiMandatoryCapture = useMemo(
    () =>
      gameVariant === 'shashki' &&
      !isViewingHistory &&
      !activeOutcome &&
      (!isOnline || onlineRoom?.status === 'playing') &&
      hasMandatoryCapture(shashkiState),
    [activeOutcome, gameVariant, isOnline, isViewingHistory, onlineRoom?.status, shashkiState],
  );

  const activeClocks = useMemo(() => {
    if (activeTimeControl === 'unlimited') return { w: 0, b: 0 };
    if (isOnline && onlineRoom) return onlineRoom.clocks;
    return localClocks;
  }, [activeTimeControl, isOnline, localClocks, onlineRoom]);

  const activeTurnStartedAt = isOnline
    ? onlineClockSyncedAt
    : localTurnStartedAt;

  const isLocalWinOutcome = useCallback(
    (outcome: GameOutcome): boolean => {
      if (outcome.winner === 'draw') return false;
      if (gameMode === 'bot') return outcome.winner === humanBotSide;
      if (gameMode === 'online' && (onlineRole === 'w' || onlineRole === 'b')) {
        return outcome.winner === onlineRole;
      }
      return true;
    },
    [gameMode, humanBotSide, onlineRole],
  );

  const triggerMoveAudio = useCallback(
    (move: MoveRecord, outcome: GameOutcome | null) => {
      if (outcome) {
        playGameOverSound(isLocalWinOutcome(outcome));
        return;
      }
      if (move.isCheck) {
        playCheckSound();
      } else if (move.isCastle) {
        playCastleSound();
      } else if (move.captured) {
        playCaptureSound();
      } else {
        playMoveSound();
      }
    },
    [isLocalWinOutcome],
  );

  const triggerMoveAudioRef = useRef(triggerMoveAudio);
  useEffect(() => {
    triggerMoveAudioRef.current = triggerMoveAudio;
  }, [triggerMoveAudio]);

  const sendWs = useCallback((payload: ClientWsMessage): boolean => {
    const ws = wsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(payload));
      return true;
    }
    setOnlineError(getTranslations(langRef.current).wsWaitError);
    return false;
  }, []);

  useEffect(() => {
    let closedByCleanup = false;
    let reconnectTimer: number | null = null;

    function connect() {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${protocol}//${window.location.host}/ws`);
      wsRef.current = ws;

      ws.onopen = () => {
        setWsConnected(true);
        setOnlineError(null);

        // Reconnect into active online room or ?room=CODE from URL
        const resumeCode =
          onlineRoomRef.current?.roomCode ??
          (!autoJoinedRoomRef.current ? initialQuery.roomCode : '');
        if (resumeCode) {
          autoJoinedRoomRef.current = true;
          ws.send(
            JSON.stringify({
              type: 'room:join',
              roomCode: resumeCode,
              playerName: playerNameRef.current || 'Oyuncu',
              playerToken: playerTokenRef.current,
            } satisfies ClientWsMessage),
          );
        }
      };

      ws.onmessage = (event) => {
        let msg: ServerWsMessage;
        try {
          msg = JSON.parse(event.data as string) as ServerWsMessage;
        } catch {
          return;
        }

        if (msg.type === 'room:joined') {
          setMatchmakingWaiting(false);
          setOnlineError(null);
          setGameVariant(msg.room.variant);
          if (msg.room.variant === 'shashki') {
            try {
              setShashkiState(deserializeShashkiState(msg.room.fen));
              setShashkiChain(msg.room.shashkiChain ?? null);
            } catch {
              // ignore
            }
          } else {
            setShashkiChain(null);
          }
          setGameMode('online');
          setShashkiLastStep(null);
          onlineRoomRef.current = msg.room;
          onlineRoleRef.current = msg.role;
          setOnlineRoom(msg.room);
          setOnlineClockSyncedAt(Date.now());
          setOnlineRole(msg.role);
          setOrientation(msg.role === 'b' ? 'b' : 'w');
          setSelectedSquare(
            msg.room.variant === 'shashki' &&
              msg.room.shashkiChain &&
              msg.role === msg.room.turn
              ? msg.room.shashkiChain.activeSquare
              : null,
          );
          setViewPly(null);
          setPendingPromotion(null);
          prevOnlineMoveCountRef.current = msg.room.moves.length;
          prevOnlineStatusRef.current = msg.room.status;
          setShowGameOverModal(msg.room.status === 'finished');
          setScreen(msg.room.status === 'finished' ? 'gameover' : 'playing');

          if (msg.room.status === 'playing') {
            warmupAudio();
            playGameStartMusic();
            startBackgroundMusic(950);
          }

          // Keep room code in URL so browser refresh seamlessly restores seat
          const targetUrl = `/?room=${msg.room.roomCode}`;
          if (window.location.search !== `?room=${msg.room.roomCode}`) {
            window.history.replaceState({}, '', targetUrl);
          }
          return;
        }

        if (msg.type === 'room:state') {
          const prevCount = prevOnlineMoveCountRef.current;
          const prevStatus = prevOnlineStatusRef.current;
          const prevFen = onlineRoomRef.current?.fen;
          const nextCount = msg.room.moves.length;
          if (prevStatus === 'waiting' && msg.room.status === 'playing') {
            warmupAudio();
            playGameStartMusic();
            startBackgroundMusic(950);
          }
          if (nextCount > prevCount) {
            const latestMove = msg.room.moves[nextCount - 1];
            triggerMoveAudioRef.current(latestMove, msg.room.outcome);
            setSelectedSquare(null);
            setShashkiLastStep(null);
            setViewPly(null);
          } else if (
            msg.room.variant === 'shashki' &&
            msg.room.shashkiChain &&
            prevFen !== msg.room.fen
          ) {
            playCaptureSound();
            setViewPly(null);
            setSelectedSquare(
              onlineRoleRef.current === msg.room.turn
                ? msg.room.shashkiChain.activeSquare
                : null,
            );
          } else if (nextCount === 0 && prevCount > 0) {
            setSelectedSquare(null);
            setShashkiLastStep(null);
            setViewPly(null);
            setShowGameOverModal(false);
          } else if (
            prevStatus !== 'finished' &&
            msg.room.status === 'finished' &&
            msg.room.outcome
          ) {
            // Game ended via timeout, resignation, or draw agreement
            const roleNow = onlineRoleRef.current;
            const win =
              msg.room.outcome.winner !== 'draw' &&
              (roleNow === 'w' || roleNow === 'b'
                ? msg.room.outcome.winner === roleNow
                : true);
            playGameOverSound(win);
          }

          setGameVariant(msg.room.variant);
          if (msg.room.variant === 'shashki') {
            try {
              setShashkiState(deserializeShashkiState(msg.room.fen));
              setShashkiChain(msg.room.shashkiChain ?? null);
            } catch {
              // ignore
            }
          } else {
            setShashkiChain(null);
          }

          prevOnlineMoveCountRef.current = nextCount;
          prevOnlineStatusRef.current = msg.room.status;
          onlineRoomRef.current = msg.room;
          setOnlineRoom(msg.room);
          setOnlineClockSyncedAt(Date.now());
          setOnlineError(null);
          if (msg.room.status === 'finished') {
            setPendingPromotion(null);
            setScreen('gameover');
            setShowGameOverModal(true);
          } else {
            setScreen('playing');
          }
          return;
        }

        if (msg.type === 'matchmaking:waiting') {
          setMatchmakingWaiting(true);
          setOnlineError(null);
          return;
        }

        if (msg.type === 'matchmaking:canceled') {
          setMatchmakingWaiting(false);
          return;
        }

        if (msg.type === 'error') {
          setMatchmakingWaiting(false);
          setOnlineError(translateServerError(msg.message, langRef.current));
        }
      };

      ws.onclose = () => {
        setWsConnected(false);
        if (!closedByCleanup) {
          reconnectTimer = window.setTimeout(connect, 1500);
        }
      };
    }

    connect();
    return () => {
      closedByCleanup = true;
      if (reconnectTimer) window.clearTimeout(reconnectTimer);
      wsRef.current?.close();
    };
  }, [initialQuery.roomCode]);

  // Local/bot game timeout detection using a single scheduled timeout (zero 250ms App re-renders)
  useEffect(() => {
    if (
      screen !== 'playing' ||
      isOnline ||
      timeControl === 'unlimited' ||
      localMoves.length === 0 ||
      localOutcome ||
      localTurnStartedAt === null
    ) {
      return;
    }
    const elapsed = Math.max(0, Date.now() - localTurnStartedAt);
    const remainingMs = Math.max(0, localClocks[activeTurn] - elapsed);

    const timer = window.setTimeout(() => {
      const winner: PieceColor = activeTurn === 'w' ? 'b' : 'w';
      const timeoutOutcome: GameOutcome = {
        winner,
        reason: 'timeout',
        message: `${activeTurn === 'w' ? 'Beyaz' : 'Siyah'} oyuncunun süresi doldu. ${winner === 'w' ? 'Beyaz' : 'Siyah'} kazandı!`,
      };
      setLocalClocks((prev) => ({ ...prev, [activeTurn]: 0 }));
      setLocalOutcome(timeoutOutcome);
      setPendingPromotion(null);
      setScreen('gameover');
      setShowGameOverModal(true);
      playGameOverSound(isLocalWinOutcome(timeoutOutcome));
    }, remainingMs);

    return () => window.clearTimeout(timer);
  }, [
    activeTurn,
    isOnline,
    localClocks,
    localMoves.length,
    localOutcome,
    localTurnStartedAt,
    screen,
    timeControl,
  ]);

  const handleStartBotGame = useCallback(
    (params: {
      difficulty: BotDifficulty;
      side: SidePreference;
      timeControl: TimeControlKey;
    }) => {
      if (document.activeElement instanceof HTMLElement) {
        document.activeElement.blur();
      }
      botRequestIdRef.current++;
      const chosenSide: PieceColor =
        params.side === 'random' ? (Math.random() < 0.5 ? 'w' : 'b') : params.side;
      const tc = TIME_CONTROLS[params.timeControl];

      setGameVariant('chess');
      setGameMode('bot');
      onlineRoomRef.current = null;
      onlineRoleRef.current = null;
      setOnlineRoom(null);
      setOnlineRole(null);
      setOnlineClockSyncedAt(null);
      setOnlineError(null);
      setBotDifficulty(params.difficulty);
      setHumanBotSide(chosenSide);
      setTimeControl(params.timeControl);
      setOrientation(chosenSide);
      setLocalFen(INITIAL_FEN);
      setShashkiChain(null);
      setShashkiLastStep(null);
      setLocalMoves([]);
      setLocalClocks({ w: tc.initialMs, b: tc.initialMs });
      setLocalTurnStartedAt(null);
      setLocalOutcome(null);
      setSelectedSquare(null);
      setViewPly(null);
      setPendingPromotion(null);
      setShowGameOverModal(false);
      setScreen('playing');
      ensureBotWorker();
      warmupAudio();
      playGameStartMusic();
      startBackgroundMusic(950);
    },
    [ensureBotWorker],
  );

  const handleStartShashkiGame = useCallback(
    (params: {
      difficulty: BotDifficulty;
      side: SidePreference;
      timeControl: TimeControlKey;
    }) => {
      if (document.activeElement instanceof HTMLElement) {
        document.activeElement.blur();
      }
      botRequestIdRef.current++;
      const chosenSide: PieceColor =
        params.side === 'random' ? (Math.random() < 0.5 ? 'w' : 'b') : params.side;
      const tc = TIME_CONTROLS[params.timeControl];

      setGameVariant('shashki');
      setGameMode('bot');
      onlineRoomRef.current = null;
      onlineRoleRef.current = null;
      setOnlineRoom(null);
      setOnlineRole(null);
      setOnlineClockSyncedAt(null);
      setOnlineError(null);
      setBotDifficulty(params.difficulty);
      setHumanBotSide(chosenSide);
      setTimeControl(params.timeControl);
      setOrientation(chosenSide);
      setShashkiState(createInitialShashkiState());
      setShashkiChain(null);
      setShashkiLastStep(null);
      setLocalMoves([]);
      setLocalClocks({ w: tc.initialMs, b: tc.initialMs });
      setLocalTurnStartedAt(null);
      setLocalOutcome(null);
      setSelectedSquare(null);
      setViewPly(null);
      setPendingPromotion(null);
      setShowGameOverModal(false);
      setScreen('playing');
      ensureBotWorker();
      warmupAudio();
      playGameStartMusic();
      startBackgroundMusic(950);
    },
    [ensureBotWorker],
  );

  const executeLocalMove = useCallback(
    (from: string, to: string, promotion?: PromotionPiece) => {
      const res = applyMove(
        localFen,
        { from, to, promotion },
        localMoves.length,
        localMoves.map((m) => m.fen),
      );
      if (!res.valid || !res.move) return false;

      const now = Date.now();
      const movingColor = res.move.color;
      const tc = TIME_CONTROLS[timeControl];
      if (timeControl !== 'unlimited' && localMoves.length > 0 && localTurnStartedAt !== null) {
        const elapsed = Math.max(0, now - localTurnStartedAt);
        setLocalClocks((prev) => ({
          ...prev,
          [movingColor]: Math.max(0, prev[movingColor] - elapsed) + tc.incrementMs,
        }));
      }
      setLocalTurnStartedAt(now);
      setLocalFen(res.fen);
      setLocalMoves((prev) => [...prev, res.move!]);
      setSelectedSquare(null);
      setViewPly(null);
      triggerMoveAudio(res.move, res.outcome ?? null);

      if (res.outcome) {
        setLocalOutcome(res.outcome);
        setScreen('gameover');
        setShowGameOverModal(true);
      }
      return true;
    },
    [localFen, localMoves.length, localTurnStartedAt, timeControl, triggerMoveAudio],
  );

  const executeShashkiStep = useCallback(
    (from: string, to: string, chainOverride?: ShashkiChainState | null) => {
      const currentState = shashkiStateRef.current;
      const currentChain = chainOverride !== undefined ? chainOverride : shashkiChainRef.current;
      const currentMoves = localMovesRef.current;
      const res = applyInteractiveShashkiStep(
        currentState,
        from,
        to,
        currentChain,
        currentMoves.length,
        currentMoves.map((m) => m.fen),
      );
      if (!res.valid) return { valid: false, completed: false };

      shashkiStateRef.current = res.nextState;
      shashkiChainRef.current = res.nextChain;
      setShashkiState(res.nextState);
      setShashkiChain(res.nextChain);
      setShashkiLastStep({ from, to });

      if (!res.completed) {
        setSelectedSquare(to);
        playCaptureSound();
        return { valid: true, completed: false };
      }

      const now = Date.now();
      const tcKey = timeControlRef.current;
      const tc = TIME_CONTROLS[tcKey];
      const movingColor = currentState.turn;
      if (
        tcKey !== 'unlimited' &&
        currentMoves.length > 0 &&
        localTurnStartedAtRef.current !== null
      ) {
        const elapsed = Math.max(0, now - localTurnStartedAtRef.current);
        setLocalClocks((prev) => ({
          ...prev,
          [movingColor]: Math.max(0, prev[movingColor] - elapsed) + tc.incrementMs,
        }));
      }
      localTurnStartedAtRef.current = now;
      setLocalTurnStartedAt(now);
      if (res.moveRecord) {
        const nextMoves = [...currentMoves, res.moveRecord];
        localMovesRef.current = nextMoves;
        setLocalMoves(nextMoves);
      }
      setSelectedSquare(null);
      setViewPly(null);

      if (res.outcome) {
        playGameOverSound(isLocalWinOutcome(res.outcome));
        setLocalOutcome(res.outcome);
        setScreen('gameover');
        setShowGameOverModal(true);
      } else if (res.capturedNow) {
        playCaptureSound();
      } else {
        playMoveSound();
      }
      return { valid: true, completed: true };
    },
    [isLocalWinOutcome],
  );

  // Run Chess Bot move search in a dedicated Web Worker
  useEffect(() => {
    if (gameVariant !== 'chess' || screen !== 'playing' || gameMode !== 'bot' || localOutcome) {
      return;
    }
    const currentTurn = getTurn(localFen);
    if (currentTurn === humanBotSide) return;

    const reqId = ++botRequestIdRef.current;
    const startedAt = performance.now();
    let delayTimer: number | null = null;
    let fallbackTimer: number | null = null;

    const applyResult = (move: { from: string; to: string; promotion?: PromotionPiece } | null) => {
      if (botRequestIdRef.current !== reqId || !move) return;
      const elapsed = performance.now() - startedAt;
      const remainingWait = Math.max(0, 340 - elapsed);
      if (remainingWait > 12) {
        delayTimer = window.setTimeout(() => {
          if (botRequestIdRef.current === reqId) {
            executeLocalMove(move.from, move.to, move.promotion);
          }
        }, remainingWait);
      } else {
        executeLocalMove(move.from, move.to, move.promotion);
      }
    };

    if (typeof Worker !== 'undefined') {
      if (!botWorkerRef.current) {
        botWorkerRef.current = new Worker(
          new URL('./game/botWorker.ts', import.meta.url),
          { type: 'module' },
        );
      }
      const worker = botWorkerRef.current;
      const onMessage = (event: MessageEvent<BotWorkerResponse>) => {
        if (event.data.requestId === reqId && event.data.kind !== 'shashki') {
          applyResult(event.data.move as { from: string; to: string; promotion?: PromotionPiece } | null);
        }
      };
      const onError = () => {
        if (botRequestIdRef.current !== reqId) return;
        const botMove = chooseBotMove(localFen, botDifficulty);
        applyResult(botMove);
      };
      worker.addEventListener('message', onMessage);
      worker.addEventListener('error', onError);
      worker.postMessage({
        kind: 'chess',
        requestId: reqId,
        fen: localFen,
        difficulty: botDifficulty,
      } satisfies BotWorkerRequest);

      return () => {
        botRequestIdRef.current++;
        worker.removeEventListener('message', onMessage);
        worker.removeEventListener('error', onError);
        if (delayTimer !== null) window.clearTimeout(delayTimer);
      };
    }

    fallbackTimer = window.setTimeout(() => {
      const botMove = chooseBotMove(localFen, botDifficulty);
      applyResult(botMove);
    }, 340);

    return () => {
      botRequestIdRef.current++;
      if (fallbackTimer !== null) window.clearTimeout(fallbackTimer);
      if (delayTimer !== null) window.clearTimeout(delayTimer);
    };
  }, [botDifficulty, executeLocalMove, gameMode, gameVariant, humanBotSide, localFen, localOutcome, screen]);

  // Run Şaşki Bot move search in Web Worker and animate multi-jump hops cleanly
  useEffect(() => {
    if (
      gameVariant !== 'shashki' ||
      screen !== 'playing' ||
      gameMode !== 'bot' ||
      localOutcome ||
      shashkiState.turn === humanBotSide
    ) {
      return;
    }

    const reqId = ++botRequestIdRef.current;
    const startedAt = performance.now();
    const stepTimers: number[] = [];

    const runBotSequence = (move: ShashkiFullMove | null) => {
      if (botRequestIdRef.current !== reqId || !move || move.steps.length === 0) return;

      const elapsed = performance.now() - startedAt;
      const initialDelay = Math.max(0, 340 - elapsed);

      const playStepAt = (stepIdx: number) => {
        if (botRequestIdRef.current !== reqId || stepIdx >= move.steps.length) return;
        const step = move.steps[stepIdx];
        executeShashkiStep(step.from, step.to);
        if (stepIdx + 1 < move.steps.length) {
          const nextTimer = window.setTimeout(() => playStepAt(stepIdx + 1), 280);
          stepTimers.push(nextTimer);
        }
      };

      if (initialDelay > 12) {
        stepTimers.push(window.setTimeout(() => playStepAt(0), initialDelay));
      } else {
        playStepAt(0);
      }
    };

    const stateSnapshot = shashkiStateRef.current;
    if (typeof Worker !== 'undefined') {
      if (!botWorkerRef.current) {
        botWorkerRef.current = new Worker(
          new URL('./game/botWorker.ts', import.meta.url),
          { type: 'module' },
        );
      }
      const worker = botWorkerRef.current;
      const onMessage = (event: MessageEvent<BotWorkerResponse>) => {
        if (event.data.requestId === reqId && event.data.kind === 'shashki') {
          runBotSequence(event.data.move);
        }
      };
      const onError = () => {
        if (botRequestIdRef.current !== reqId) return;
        runBotSequence(chooseShashkiBotMove(stateSnapshot, botDifficulty));
      };
      worker.addEventListener('message', onMessage);
      worker.addEventListener('error', onError);
      worker.postMessage({
        kind: 'shashki',
        requestId: reqId,
        stateKey: serializeShashkiState(stateSnapshot),
        difficulty: botDifficulty,
      } satisfies BotWorkerRequest);

      return () => {
        botRequestIdRef.current++;
        worker.removeEventListener('message', onMessage);
        worker.removeEventListener('error', onError);
        for (const tid of stepTimers) window.clearTimeout(tid);
      };
    }

    stepTimers.push(
      window.setTimeout(() => {
        runBotSequence(chooseShashkiBotMove(stateSnapshot, botDifficulty));
      }, 340),
    );

    return () => {
      botRequestIdRef.current++;
      for (const tid of stepTimers) window.clearTimeout(tid);
    };
  }, [
    botDifficulty,
    executeShashkiStep,
    gameMode,
    gameVariant,
    humanBotSide,
    localOutcome,
    screen,
    shashkiState.turn,
  ]);

  useEffect(() => {
    return () => {
      botWorkerRef.current?.terminate();
      botWorkerRef.current = null;
    };
  }, []);

  const canMoveColor: PieceColor | null = useMemo(() => {
    if (screen !== 'playing' || isViewingHistory || activeOutcome) return null;
    if (isOnline) {
      if (!onlineRoom || onlineRoom.status !== 'playing') return null;
      if (onlineRole !== 'w' && onlineRole !== 'b') return null;
      return onlineRoom.turn === onlineRole ? onlineRole : null;
    }
    return activeTurn === humanBotSide ? humanBotSide : null;
  }, [
    activeOutcome,
    activeTurn,
    humanBotSide,
    isOnline,
    isViewingHistory,
    onlineRole,
    onlineRoom,
    screen,
  ]);

  const submitMove = useCallback(
    (from: string, to: string, promotion?: PromotionPiece) => {
      if (gameMode === 'online' && onlineRoom) {
        sendWs({
          type: 'game:move',
          roomCode: onlineRoom.roomCode,
          from,
          to,
          promotion,
          playerToken: playerTokenRef.current,
        });
        setSelectedSquare(null);
      } else {
        executeLocalMove(from, to, promotion);
      }
    },
    [executeLocalMove, gameMode, onlineRoom, sendWs],
  );

  const attemptMove = useCallback(
    (from: string, to: string) => {
      if (!canMoveColor) return;
      if (gameVariant === 'shashki') {
        if (activeShashkiChain && from !== activeShashkiChain.activeSquare) return;
        if (isOnline && onlineRoom) {
          const targets = getShashkiStepTargets(shashkiState, from, activeShashkiChain);
          if (!targets.some((t) => t.to === to)) return;
          sendWs({
            type: 'game:move',
            roomCode: onlineRoom.roomCode,
            from,
            to,
            playerToken: playerTokenRef.current,
          });
          setSelectedSquare(null);
          return;
        }
        executeShashkiStep(from, to);
        return;
      }
      const legal = getLegalMovesForSquare(activeFen, from);
      const isLegal = legal.some((m) => m.to === to);
      if (!isLegal) return;

      if (isPromotionMove(activeFen, from, to)) {
        if (settings.autoPromoteQueen) {
          submitMove(from, to, 'q');
          return;
        }
        setPendingPromotion({ from, to, color: activeTurn });
        return;
      }
      submitMove(from, to);
    },
    [
      activeFen,
      activeShashkiChain,
      activeTurn,
      canMoveColor,
      executeShashkiStep,
      gameVariant,
      isOnline,
      onlineRoom,
      sendWs,
      settings.autoPromoteQueen,
      shashkiState,
      submitMove,
    ],
  );

  const handleSquareClick = useCallback(
    (square: string) => {
      if (isViewingHistory && screen === 'playing' && !activeOutcome) {
        setViewPly(null);
        setSelectedSquare(null);
        return;
      }
      if (!canMoveColor) return;

      if (gameVariant === 'shashki') {
        if (activeShashkiChain) {
          if (square !== activeShashkiChain.activeSquare) {
            if (isOnline && onlineRoom) {
              const targets = getShashkiStepTargets(
                shashkiState,
                activeShashkiChain.activeSquare,
                activeShashkiChain,
              );
              if (targets.some((t) => t.to === square)) {
                sendWs({
                  type: 'game:move',
                  roomCode: onlineRoom.roomCode,
                  from: activeShashkiChain.activeSquare,
                  to: square,
                  playerToken: playerTokenRef.current,
                });
                setSelectedSquare(null);
              }
            } else {
              executeShashkiStep(activeShashkiChain.activeSquare, square);
            }
          }
          return;
        }
        if (selectedSquare && selectedSquare !== square) {
          const targets = getShashkiStepTargets(shashkiState, selectedSquare, null);
          if (targets.some((t) => t.to === square)) {
            if (isOnline && onlineRoom) {
              sendWs({
                type: 'game:move',
                roomCode: onlineRoom.roomCode,
                from: selectedSquare,
                to: square,
                playerToken: playerTokenRef.current,
              });
              setSelectedSquare(null);
            } else {
              executeShashkiStep(selectedSquare, square);
            }
            return;
          }
        }
        const rc = squareToRc(square);
        const piece = rc ? shashkiState.board[rc.r][rc.c] : null;
        if (
          piece &&
          piece.color === shashkiState.turn &&
          canMoveColor === piece.color
        ) {
          setSelectedSquare((prev) => {
            const next = prev === square ? null : square;
            if (next !== null) playSelectSound();
            return next;
          });
        } else {
          setSelectedSquare(null);
        }
        return;
      }

      if (selectedSquare && selectedSquare !== square) {
        const legal = getLegalMovesForSquare(activeFen, selectedSquare);
        if (legal.some((m) => m.to === square)) {
          attemptMove(selectedSquare, square);
          return;
        }
      }

      const piece = getPieceAtSquare(activeFen, square);

      if (
        piece &&
        piece.color === activeTurn &&
        canMoveColor === piece.color
      ) {
        setSelectedSquare((prev) => {
          const next = prev === square ? null : square;
          if (next !== null) {
            playSelectSound();
          }
          return next;
        });
      } else {
        setSelectedSquare(null);
      }
    },
    [
      activeFen,
      activeOutcome,
      activeShashkiChain,
      activeTurn,
      attemptMove,
      canMoveColor,
      executeShashkiStep,
      gameVariant,
      isOnline,
      isViewingHistory,
      onlineRoom,
      screen,
      selectedSquare,
      sendWs,
      shashkiState,
    ],
  );

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (showSettingsModal || pendingPromotion) return;
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;

      if (screen === 'title') {
        if (tag === 'BUTTON' || tag === 'LABEL') return;
        if (e.key === 'Enter') {
          e.preventDefault();
          handleStartBotGame({ difficulty: 'medium', side: 'w', timeControl: '10+0' });
        }
        return;
      }

      if (screen === 'playing' || screen === 'gameover') {
        if (e.key === 'ArrowLeft') {
          e.preventDefault();
          setViewPly((prev) => {
            const current = prev === null ? activeMoves.length : prev;
            return Math.max(0, current - 1);
          });
        } else if (e.key === 'ArrowRight') {
          e.preventDefault();
          setViewPly((prev) => {
            if (prev === null) return null;
            const next = prev + 1;
            return next >= activeMoves.length ? null : next;
          });
        } else if (e.key === 'f' || e.key === 'F') {
          setOrientation((o) => (o === 'w' ? 'b' : 'w'));
        }
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [activeMoves.length, handleStartBotGame, pendingPromotion, screen, showSettingsModal]);

  const handleGoToMenu = useCallback(() => {
    botRequestIdRef.current++;
    if (gameMode === 'online' && onlineRoom) {
      sendWs({
        type: 'room:leave',
        roomCode: onlineRoom.roomCode,
        playerToken: playerTokenRef.current,
      });
    }
    onlineRoomRef.current = null;
    onlineRoleRef.current = null;
    setOnlineRoom(null);
    setOnlineRole(null);
    setOnlineClockSyncedAt(null);
    setOnlineError(null);
    prevOnlineMoveCountRef.current = 0;
    prevOnlineStatusRef.current = null;
    setMatchmakingWaiting(false);
    setPendingPromotion(null);
    setShowGameOverModal(false);
    setSelectedSquare(null);
    setShashkiChain(null);
    setShashkiLastStep(null);
    setViewPly(null);
    stopBackgroundMusic();
    setScreen('title');
    if (window.location.search.includes('room=')) {
      window.history.replaceState({}, '', '/');
    }
  }, [gameMode, onlineRoom, sendWs]);

  const handleResign = useCallback(() => {
    if (activeOutcome) return;
    if (gameMode === 'online' && onlineRoom) {
      sendWs({
        type: 'game:resign',
        roomCode: onlineRoom.roomCode,
        playerToken: playerTokenRef.current,
      });
      return;
    }
    const resigningSide: PieceColor = humanBotSide;
    const winner: PieceColor = resigningSide === 'w' ? 'b' : 'w';
    const outcome: GameOutcome = {
      winner,
      reason: 'resignation',
      message: `${resigningSide === 'w' ? 'Beyaz' : 'Siyah'} terk etti. ${winner === 'w' ? 'Beyaz' : 'Siyah'} kazandı!`,
    };
    botRequestIdRef.current++;
    setLocalOutcome(outcome);
    setScreen('gameover');
    setShowGameOverModal(true);
    playGameOverSound(false);
  }, [activeOutcome, gameMode, humanBotSide, onlineRoom, sendWs]);

  const handlePlayAgain = useCallback(() => {
    if (gameMode === 'online' && onlineRoom) {
      sendWs({
        type: 'game:rematch',
        roomCode: onlineRoom.roomCode,
        playerToken: playerTokenRef.current,
      });
      return;
    }
    if (gameVariant === 'shashki') {
      handleStartShashkiGame({
        difficulty: botDifficulty,
        side: humanBotSide === 'w' ? 'b' : 'w',
        timeControl,
      });
      return;
    }
    handleStartBotGame({
      difficulty: botDifficulty,
      side: humanBotSide === 'w' ? 'b' : 'w',
      timeControl,
    });
  }, [
    botDifficulty,
    gameMode,
    gameVariant,
    handleStartBotGame,
    handleStartShashkiGame,
    humanBotSide,
    onlineRoom,
    sendWs,
    timeControl,
  ]);

  const handleSelectPly = useCallback((ply: number | null) => {
    setSelectedSquare(null);
    setViewPly(ply);
  }, []);

  const handleFlipBoard = useCallback(() => {
    setOrientation((o) => (o === 'w' ? 'b' : 'w'));
  }, []);

  const handleOfferDraw = useCallback(() => {
    if (isOnline && onlineRoom) {
      sendWs({
        type: 'game:draw_offer',
        roomCode: onlineRoom.roomCode,
        playerToken: playerTokenRef.current,
      });
    }
  }, [isOnline, onlineRoom, sendWs]);

  const handleRespondDraw = useCallback(
    (accept: boolean) => {
      if (isOnline && onlineRoom) {
        sendWs({
          type: 'game:draw_respond',
          roomCode: onlineRoom.roomCode,
          accept,
          playerToken: playerTokenRef.current,
        });
      }
    },
    [isOnline, onlineRoom, sendWs],
  );

  const handleOpenSettings = useCallback(() => {
    setShowSettingsModal(true);
  }, []);

  const t = getTranslations(lang);

  if (screen === 'title') {
    return (
      <>
        <MainMenu
          variant={gameVariant}
          onVariantChange={setGameVariant}
          playerName={playerName}
          onPlayerNameChange={setPlayerName}
          lang={lang}
          onOpenSettings={() => setShowSettingsModal(true)}
          wsConnected={wsConnected}
          matchmakingWaiting={matchmakingWaiting}
          onlineError={onlineError}
          initialRoomCode={initialQuery.roomCode}
          onStartBotGame={handleStartBotGame}
          onStartShashkiGame={handleStartShashkiGame}
          onCreateOnlineRoom={({ variant, timeControl: tc, sidePreference }) => {
            setOnlineError(null);
            sendWs({
              type: 'room:create',
              playerName: playerName || t.defaultPlayerName,
              variant,
              timeControl: tc,
              sidePreference,
              playerToken: playerTokenRef.current,
            });
          }}
          onJoinOnlineRoom={(code) => {
            setOnlineError(null);
            sendWs({
              type: 'room:join',
              roomCode: code,
              playerName: playerName || t.defaultPlayerName,
              playerToken: playerTokenRef.current,
            });
          }}
          onJoinMatchmaking={({ variant, timeControl: tc }) => {
            setOnlineError(null);
            sendWs({
              type: 'matchmaking:join',
              playerName: playerName || t.defaultPlayerName,
              variant,
              timeControl: tc,
              playerToken: playerTokenRef.current,
            });
          }}
          onCancelMatchmaking={() => {
            sendWs({ type: 'matchmaking:cancel' });
          }}
          onClearError={() => setOnlineError(null)}
        />
        {showSettingsModal && (
          <SettingsModal
            variant={gameVariant}
            settings={settings}
            onChange={setSettings}
            themeSelection={themeSelection}
            onThemeChange={setThemeSelection}
            lang={lang}
            onLanguageChange={setLang}
            onClose={() => setShowSettingsModal(false)}
          />
        )}
      </>
    );
  }

  const topColor: PieceColor = orientation === 'w' ? 'b' : 'w';
  const bottomColor: PieceColor = orientation;

  const getSeatLabel = (
    color: PieceColor,
  ): { name: string; connected: boolean; isLocal: boolean; isSeated: boolean } => {
    if (isOnline && onlineRoom) {
      const seat = onlineRoom.players[color];
      return {
        name: seat ? seat.name : t.waitingOpponent,
        connected: seat ? seat.connected : false,
        isLocal: onlineRole === color,
        isSeated: seat !== null,
      };
    }
    const diffName =
      botDifficulty === 'easy'
        ? t.diffEasy
        : botDifficulty === 'medium'
          ? t.diffMedium
          : t.diffHard;
    if (color === humanBotSide) {
      return { name: playerName || t.youBadge, connected: true, isLocal: true, isSeated: true };
    }
    return {
      name: gameVariant === 'shashki' ? t.shashkiBotPlayerLabel(diffName) : t.botPlayerLabel(diffName),
      connected: true,
      isLocal: false,
      isSeated: true,
    };
  };

  const topSeat = getSeatLabel(topColor);
  const bottomSeat = getSeatLabel(bottomColor);
  const isTimed = activeTimeControl !== 'unlimited';
  const isSpectator = isOnline && onlineRole === 'spectator';

  const modeBadgeText =
    isOnline && onlineRoom
      ? `${t.onlineLabel} · ${t.roomLabel}${isSpectator ? ` · ${t.spectatorLabel}` : ''}`
      : null;

  const clocksActive =
    isTimed &&
    !activeOutcome &&
    activeMoves.length > 0 &&
    activeTurnStartedAt !== null &&
    (!isOnline || onlineRoom?.status === 'playing');

  const isWaitingOnline = isOnline && onlineRoom?.status === 'waiting';

  const getShashkiCapturedBy = (color: PieceColor): number => {
    if (!shashkiCounts) return 0;
    return color === 'w' ? 12 - shashkiCounts.bTotal : 12 - shashkiCounts.wTotal;
  };
  const getShashkiAdvantage = (color: PieceColor): number => {
    if (!shashkiCounts) return 0;
    return color === 'w'
      ? Math.max(0, shashkiCounts.wTotal - shashkiCounts.bTotal)
      : Math.max(0, shashkiCounts.bTotal - shashkiCounts.wTotal);
  };

  return (
    <div className="min-h-dvh parchment-texture flex flex-col px-1.5 sm:px-4 py-1.5 sm:py-2.5 lg:py-1.5">
      <div className="max-w-[1480px] w-full mx-auto my-auto flex flex-col lg:flex-row items-center justify-center gap-3 sm:gap-4 lg:gap-5 xl:gap-6">
        <section
          className={`flex flex-col shrink-0 ${
            isWaitingOnline
              ? 'w-[min(calc(100vw-0.5rem),calc(100dvh-11.6rem),760px)] lg:w-[min(900px,calc(100dvh-11.6rem),calc(100vw-308px))] xl:w-[min(920px,calc(100dvh-11.6rem),calc(100vw-328px))]'
              : 'w-[min(calc(100vw-0.5rem),calc(100dvh-8.85rem),760px)] lg:w-[min(940px,calc(100dvh-8.85rem),calc(100vw-308px))] xl:w-[min(960px,calc(100dvh-8.85rem),calc(100vw-328px))]'
          }`}
        >
          <div className="flex items-center justify-between gap-4 pb-0.5 px-0.5">
            <GameBrandTitle
              variant={gameVariant}
              title={gameVariant === 'shashki' ? t.shashkiTitle : 'ŞAHMAT'}
              size="sm"
            />
            {modeBadgeText && (
              <span className="text-xs font-medium text-[var(--ink-secondary)] truncate leading-none">
                {modeBadgeText}
              </span>
            )}
          </div>

          {isWaitingOnline && onlineRoom && (
            <OnlineWaitingBanner roomCode={onlineRoom.roomCode} lang={lang} />
          )}

          <PlayerBar
            name={topSeat.name}
            color={topColor}
            isTurn={!activeOutcome && activeTurn === topColor}
            isLocalPlayer={topSeat.isLocal}
            isSeated={topSeat.isSeated}
            connected={topSeat.connected}
            showConnectionState={isOnline}
            variant={gameVariant}
            capturedPieces={
              topColor === 'w'
                ? capturedSummary.capturedByWhite
                : capturedSummary.capturedByBlack
            }
            shashkiCapturedCount={getShashkiCapturedBy(topColor)}
            materialAdvantage={
              gameVariant === 'shashki'
                ? getShashkiAdvantage(topColor)
                : topColor === 'w'
                  ? capturedSummary.whiteAdvantage
                  : capturedSummary.blackAdvantage
            }
            clockMs={activeClocks[topColor]}
            clockRunning={clocksActive && activeTurn === topColor}
            turnStartedAt={activeTurnStartedAt}
            timed={isTimed}
            lang={lang}
          />

          <div className="my-1">
            {gameVariant === 'shashki' ? (
              <ShashkiBoard
                state={displayedShashkiState}
                chainState={isViewingHistory ? null : activeShashkiChain}
                orientation={orientation}
                interactive={Boolean(canMoveColor) || (isViewingHistory && screen === 'playing' && !activeOutcome)}
                canMoveColor={canMoveColor}
                selectedSquare={selectedSquare}
                lastMove={displayedLastMove}
                onSquareClick={handleSquareClick}
                onPieceDrop={attemptMove}
                showLegalMoves={settings.showLegalMoves}
                showCoordinates={settings.showCoordinates}
                animatePieces={settings.animatePieces}
                lang={lang}
              />
            ) : (
              <ChessBoard
                fen={displayedFen}
                orientation={orientation}
                interactive={Boolean(canMoveColor) || (isViewingHistory && screen === 'playing' && !activeOutcome)}
                canMoveColor={canMoveColor}
                selectedSquare={selectedSquare}
                lastMove={displayedLastMove}
                inCheck={displayedInCheck}
                onSquareClick={handleSquareClick}
                onPieceDrop={attemptMove}
                showLegalMoves={settings.showLegalMoves}
                showCoordinates={settings.showCoordinates}
                animatePieces={settings.animatePieces}
                lang={lang}
              />
            )}
          </div>

          <PlayerBar
            name={bottomSeat.name}
            color={bottomColor}
            isTurn={!activeOutcome && activeTurn === bottomColor}
            isLocalPlayer={bottomSeat.isLocal}
            isSeated={bottomSeat.isSeated}
            connected={bottomSeat.connected}
            showConnectionState={isOnline}
            variant={gameVariant}
            capturedPieces={
              bottomColor === 'w'
                ? capturedSummary.capturedByWhite
                : capturedSummary.capturedByBlack
            }
            shashkiCapturedCount={getShashkiCapturedBy(bottomColor)}
            materialAdvantage={
              gameVariant === 'shashki'
                ? getShashkiAdvantage(bottomColor)
                : bottomColor === 'w'
                  ? capturedSummary.whiteAdvantage
                  : capturedSummary.blackAdvantage
            }
            clockMs={activeClocks[bottomColor]}
            clockRunning={clocksActive && activeTurn === bottomColor}
            turnStartedAt={activeTurnStartedAt}
            timed={isTimed}
            lang={lang}
          />
        </section>

        <div className="w-full lg:w-auto">
          <MoveHistoryPanel
            variant={gameVariant}
            shashkiMandatoryCapture={shashkiMandatoryCapture}
            shashkiChainActive={Boolean(activeShashkiChain)}
            moves={activeMoves}
            viewPly={viewPly}
            onSelectPly={handleSelectPly}
            turn={activeTurn}
            inCheck={displayedInCheck}
            openingName={activeOpeningName}
            isGameOver={Boolean(activeOutcome)}
            isOnline={isOnline}
            isSpectator={isSpectator}
            myRole={onlineRole}
            drawOfferFrom={onlineRoom?.drawOfferFrom}
            lang={lang}
            onFlipBoard={handleFlipBoard}
            onResign={handleResign}
            onOfferDraw={handleOfferDraw}
            onRespondDraw={handleRespondDraw}
            onRestartLocal={handlePlayAgain}
            onGoToMenu={handleGoToMenu}
            onOpenSettings={handleOpenSettings}
          />
        </div>
      </div>

      {showSettingsModal && (
        <SettingsModal
          variant={gameVariant}
          settings={settings}
          onChange={setSettings}
          themeSelection={themeSelection}
          onThemeChange={setThemeSelection}
          lang={lang}
          onLanguageChange={setLang}
          onClose={() => setShowSettingsModal(false)}
        />
      )}

      {pendingPromotion && (
        <PromotionModal
          color={pendingPromotion.color}
          lang={lang}
          onSelect={(piece) => {
            const { from, to } = pendingPromotion;
            setPendingPromotion(null);
            submitMove(from, to, piece);
          }}
          onCancel={() => setPendingPromotion(null)}
        />
      )}

      {activeOutcome && showGameOverModal && (
        <GameOverModal
          variant={gameVariant}
          outcome={activeOutcome}
          totalMoves={Math.ceil(activeMoves.length / 2)}
          openingName={activeOpeningName}
          isOnline={isOnline}
          isSpectator={isSpectator}
          rematchVoted={
            Boolean(
              isOnline &&
                onlineRoom &&
                (onlineRole === 'w' || onlineRole === 'b') &&
                onlineRoom.rematchVotes.includes(onlineRole),
            )
          }
          rematchCount={onlineRoom?.rematchVotes.length ?? 0}
          lang={lang}
          onPlayAgain={handlePlayAgain}
          onGoToMenu={handleGoToMenu}
          onDismiss={() => setShowGameOverModal(false)}
        />
      )}
    </div>
  );
}
