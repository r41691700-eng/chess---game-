import express from 'express';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { WebSocket, WebSocketServer } from 'ws';
import { RoomManager } from './src/game/roomManager';
import { buildZipArchive, collectProjectFiles } from './src/utils/projectArchive';
import {
  TIME_CONTROLS,
  type ClientWsMessage,
  type GameVariant,
  type PromotionPiece,
  type ServerWsMessage,
  type SidePreference,
  type TimeControlKey,
} from './src/game/types';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const isProd = process.env.NODE_ENV === 'production';

interface ClientMeta {
  ws: WebSocket;
  playerToken: string | null;
  roomCode: string | null;
}

function isNonEmptyString(val: unknown, maxLen = 64): val is string {
  return typeof val === 'string' && val.trim().length > 0 && val.length <= maxLen;
}

function isValidTimeControl(val: unknown): val is TimeControlKey {
  return typeof val === 'string' && Object.prototype.hasOwnProperty.call(TIME_CONTROLS, val);
}

function isValidSidePref(val: unknown): val is SidePreference {
  return val === 'w' || val === 'b' || val === 'random';
}

function isValidVariant(val: unknown): val is GameVariant {
  return val === 'chess' || val === 'shashki';
}

function isValidPromotion(val: unknown): val is PromotionPiece | undefined {
  return val === undefined || val === 'q' || val === 'r' || val === 'b' || val === 'n';
}

async function startServer() {
  const app = express();
  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });
  const roomManager = new RoomManager();

  const clientsBySocket = new Map<WebSocket, ClientMeta>();
  const socketsByRoom = new Map<string, Set<WebSocket>>();
  const socketByToken = new Map<string, WebSocket>();
  const aliveSockets = new Set<WebSocket>();

  function sendJson(ws: WebSocket, payload: ServerWsMessage) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(payload));
    }
  }

  function broadcastRoom(roomCode: string, payload: ServerWsMessage) {
    const members = socketsByRoom.get(roomCode);
    if (!members) return;
    for (const memberWs of members) {
      sendJson(memberWs, payload);
    }
  }

  function attachSocketToRoom(ws: WebSocket, roomCode: string, playerToken: string) {
    const meta = clientsBySocket.get(ws);
    if (meta) {
      if (meta.roomCode && meta.roomCode !== roomCode) {
        const prevMembers = socketsByRoom.get(meta.roomCode);
        prevMembers?.delete(ws);
        if (prevMembers && prevMembers.size === 0) {
          socketsByRoom.delete(meta.roomCode);
        }
      }
      meta.roomCode = roomCode;
      meta.playerToken = playerToken;
    }
    socketByToken.set(playerToken, ws);
    if (!socketsByRoom.has(roomCode)) {
      socketsByRoom.set(roomCode, new Set());
    }
    socketsByRoom.get(roomCode)!.add(ws);
  }

  function detachSocketFromRoom(ws: WebSocket, options?: { leaving?: boolean }) {
    const meta = clientsBySocket.get(ws);
    if (!meta || !meta.roomCode || !meta.playerToken) return;
    const { roomCode, playerToken } = meta;
    meta.roomCode = null;

    const members = socketsByRoom.get(roomCode);
    if (members) {
      members.delete(ws);
      if (members.size === 0) {
        socketsByRoom.delete(roomCode);
      }
    }

    // Guard against stale socket close overwriting a newer active socket for the same playerToken
    const activeWsForToken = socketByToken.get(playerToken);
    const activeMeta = activeWsForToken ? clientsBySocket.get(activeWsForToken) : undefined;
    const tokenHasNewerSocketInSameRoom =
      activeWsForToken !== undefined &&
      activeWsForToken !== ws &&
      activeMeta?.roomCode === roomCode &&
      activeWsForToken.readyState === WebSocket.OPEN;

    if (tokenHasNewerSocketInSameRoom) {
      return;
    }

    const updated = options?.leaving
      ? roomManager.leaveRoom(roomCode, playerToken)
      : roomManager.setConnectionStatus(roomCode, playerToken, false);
    if (updated) {
      broadcastRoom(roomCode, { type: 'room:state', room: updated });
    }
  }

  wss.on('connection', (ws) => {
    clientsBySocket.set(ws, { ws, playerToken: null, roomCode: null });
    aliveSockets.add(ws);

    ws.on('pong', () => {
      aliveSockets.add(ws);
    });

    ws.on('message', (raw) => {
      aliveSockets.add(ws);

      let msg: ClientWsMessage;
      try {
        const parsed: unknown = JSON.parse(raw.toString());
        if (!parsed || typeof parsed !== 'object' || typeof (parsed as { type?: unknown }).type !== 'string') {
          sendJson(ws, { type: 'error', code: 'BAD_JSON', message: 'Geçersiz mesaj biçimi.' });
          return;
        }
        msg = parsed as ClientWsMessage;
      } catch {
        sendJson(ws, { type: 'error', code: 'BAD_JSON', message: 'Geçersiz mesaj biçimi.' });
        return;
      }

      if (msg.type === 'room:create') {
        if (
          !isNonEmptyString(msg.playerToken, 128) ||
          !isValidVariant(msg.variant) ||
          !isValidTimeControl(msg.timeControl) ||
          !isValidSidePref(msg.sidePreference)
        ) {
          sendJson(ws, { type: 'error', code: 'BAD_PAYLOAD', message: 'Eksik veya geçersiz oda bilgisi.' });
          return;
        }
        const meta = clientsBySocket.get(ws);
        detachSocketFromRoom(ws, { leaving: true });
        if (meta?.playerToken) roomManager.cancelMatchmaking(meta.playerToken);
        roomManager.cancelMatchmaking(msg.playerToken);

        const created = roomManager.createRoom({
          playerName: typeof msg.playerName === 'string' ? msg.playerName : 'Oyuncu',
          playerToken: msg.playerToken,
          variant: msg.variant,
          timeControl: msg.timeControl,
          sidePreference: msg.sidePreference,
        });
        attachSocketToRoom(ws, created.room.roomCode, msg.playerToken);
        sendJson(ws, {
          type: 'room:joined',
          room: created.room,
          role: created.role,
          playerToken: msg.playerToken,
        });
        return;
      }

      if (msg.type === 'room:join') {
        if (!isNonEmptyString(msg.roomCode, 16) || !isNonEmptyString(msg.playerToken, 128)) {
          sendJson(ws, { type: 'error', code: 'BAD_PAYLOAD', message: 'Geçersiz oda kodu.' });
          return;
        }
        const meta = clientsBySocket.get(ws);
        const normalizedCode = msg.roomCode.trim().toUpperCase();
        if (meta?.roomCode && meta.roomCode !== normalizedCode) {
          detachSocketFromRoom(ws, { leaving: true });
        }
        if (meta?.playerToken) roomManager.cancelMatchmaking(meta.playerToken);
        roomManager.cancelMatchmaking(msg.playerToken);

        const res = roomManager.joinRoom({
          roomCode: normalizedCode,
          playerName: typeof msg.playerName === 'string' ? msg.playerName : 'Oyuncu',
          playerToken: msg.playerToken,
        });
        if (!res.ok || !res.room || !res.role) {
          sendJson(ws, {
            type: 'error',
            code: 'JOIN_FAILED',
            message: res.error ?? 'Odaya katılınamadı.',
          });
          return;
        }
        attachSocketToRoom(ws, res.room.roomCode, msg.playerToken);
        sendJson(ws, {
          type: 'room:joined',
          room: res.room,
          role: res.role,
          playerToken: msg.playerToken,
        });
        broadcastRoom(res.room.roomCode, { type: 'room:state', room: res.room });
        return;
      }

      if (msg.type === 'matchmaking:join') {
        if (
          !isNonEmptyString(msg.playerToken, 128) ||
          !isValidVariant(msg.variant) ||
          !isValidTimeControl(msg.timeControl)
        ) {
          sendJson(ws, { type: 'error', code: 'BAD_PAYLOAD', message: 'Geçersiz eşleşme isteği.' });
          return;
        }
        detachSocketFromRoom(ws, { leaving: true });
        const meta = clientsBySocket.get(ws);
        if (meta) {
          meta.playerToken = msg.playerToken;
        }
        socketByToken.set(msg.playerToken, ws);
        const result = roomManager.enqueueMatchmaking({
          playerName: typeof msg.playerName === 'string' ? msg.playerName : 'Oyuncu',
          playerToken: msg.playerToken,
          variant: msg.variant,
          timeControl: msg.timeControl,
        });

        if (!result.matched) {
          sendJson(ws, {
            type: 'matchmaking:waiting',
            timeControl: msg.timeControl,
            queuePosition: result.queuePosition,
          });
          return;
        }

        const whiteWs = socketByToken.get(result.whiteToken);
        const blackWs = socketByToken.get(result.blackToken);

        let roomSnapshot = result.room;
        if (!whiteWs || whiteWs.readyState !== WebSocket.OPEN) {
          roomSnapshot =
            roomManager.setConnectionStatus(result.room.roomCode, result.whiteToken, false) ??
            roomSnapshot;
        }
        if (!blackWs || blackWs.readyState !== WebSocket.OPEN) {
          roomSnapshot =
            roomManager.setConnectionStatus(result.room.roomCode, result.blackToken, false) ??
            roomSnapshot;
        }

        if (whiteWs && whiteWs.readyState === WebSocket.OPEN) {
          attachSocketToRoom(whiteWs, roomSnapshot.roomCode, result.whiteToken);
          sendJson(whiteWs, {
            type: 'room:joined',
            room: roomSnapshot,
            role: 'w',
            playerToken: result.whiteToken,
          });
        }
        if (blackWs && blackWs.readyState === WebSocket.OPEN) {
          attachSocketToRoom(blackWs, roomSnapshot.roomCode, result.blackToken);
          sendJson(blackWs, {
            type: 'room:joined',
            room: roomSnapshot,
            role: 'b',
            playerToken: result.blackToken,
          });
        }
        return;
      }

      if (msg.type === 'matchmaking:cancel') {
        const meta = clientsBySocket.get(ws);
        if (meta?.playerToken) {
          roomManager.cancelMatchmaking(meta.playerToken);
        }
        sendJson(ws, { type: 'matchmaking:canceled' });
        return;
      }

      if (msg.type === 'game:move') {
        if (
          !isNonEmptyString(msg.roomCode, 16) ||
          !isNonEmptyString(msg.playerToken, 128) ||
          !isNonEmptyString(msg.from, 4) ||
          !isNonEmptyString(msg.to, 4) ||
          !isValidPromotion(msg.promotion)
        ) {
          sendJson(ws, { type: 'error', code: 'BAD_PAYLOAD', message: 'Geçersiz hamle verisi.' });
          return;
        }
        const res = roomManager.makeMove({
          roomCode: msg.roomCode,
          playerToken: msg.playerToken,
          from: msg.from,
          to: msg.to,
          promotion: msg.promotion,
        });
        if (!res.ok || !res.room) {
          sendJson(ws, {
            type: 'error',
            code: 'INVALID_MOVE',
            message: res.error ?? 'Hamle geçersiz.',
          });
          return;
        }
        broadcastRoom(res.room.roomCode, { type: 'room:state', room: res.room });
        return;
      }

      if (msg.type === 'game:resign') {
        if (!isNonEmptyString(msg.roomCode, 16) || !isNonEmptyString(msg.playerToken, 128)) return;
        const res = roomManager.resign({
          roomCode: msg.roomCode,
          playerToken: msg.playerToken,
        });
        if (res.ok && res.room) {
          broadcastRoom(res.room.roomCode, { type: 'room:state', room: res.room });
        } else {
          sendJson(ws, {
            type: 'error',
            code: 'ACTION_FAILED',
            message: res.error ?? 'Terk etme işlemi tamamlanamadı.',
          });
        }
        return;
      }

      if (msg.type === 'game:draw_offer') {
        if (!isNonEmptyString(msg.roomCode, 16) || !isNonEmptyString(msg.playerToken, 128)) return;
        const res = roomManager.offerDraw({
          roomCode: msg.roomCode,
          playerToken: msg.playerToken,
        });
        if (res.ok && res.room) {
          broadcastRoom(res.room.roomCode, { type: 'room:state', room: res.room });
        } else {
          sendJson(ws, {
            type: 'error',
            code: 'ACTION_FAILED',
            message: res.error ?? 'Beraberlik teklifi gönderilemedi.',
          });
        }
        return;
      }

      if (msg.type === 'game:draw_respond') {
        if (
          !isNonEmptyString(msg.roomCode, 16) ||
          !isNonEmptyString(msg.playerToken, 128) ||
          typeof msg.accept !== 'boolean'
        ) {
          return;
        }
        const res = roomManager.respondDraw({
          roomCode: msg.roomCode,
          playerToken: msg.playerToken,
          accept: msg.accept,
        });
        if (res.ok && res.room) {
          broadcastRoom(res.room.roomCode, { type: 'room:state', room: res.room });
        } else {
          sendJson(ws, {
            type: 'error',
            code: 'ACTION_FAILED',
            message: res.error ?? 'Beraberlik yanıtı işlenemedi.',
          });
        }
        return;
      }

      if (msg.type === 'game:rematch') {
        if (!isNonEmptyString(msg.roomCode, 16) || !isNonEmptyString(msg.playerToken, 128)) return;
        const res = roomManager.voteRematch({
          roomCode: msg.roomCode,
          playerToken: msg.playerToken,
        });
        if (res.ok && res.room) {
          if (res.rematchStarted) {
            const tokens = roomManager.getRoomPlayerTokens(res.room.roomCode);
            const whiteWs = tokens?.w ? socketByToken.get(tokens.w) : undefined;
            const blackWs = tokens?.b ? socketByToken.get(tokens.b) : undefined;
            const members = socketsByRoom.get(res.room.roomCode);
            if (members) {
              for (const memberWs of members) {
                if (memberWs === whiteWs && tokens?.w) {
                  sendJson(memberWs, {
                    type: 'room:joined',
                    room: res.room,
                    role: 'w',
                    playerToken: tokens.w,
                  });
                } else if (memberWs === blackWs && tokens?.b) {
                  sendJson(memberWs, {
                    type: 'room:joined',
                    room: res.room,
                    role: 'b',
                    playerToken: tokens.b,
                  });
                } else {
                  sendJson(memberWs, { type: 'room:state', room: res.room });
                }
              }
            }
          } else {
            broadcastRoom(res.room.roomCode, { type: 'room:state', room: res.room });
          }
        } else {
          sendJson(ws, {
            type: 'error',
            code: 'ACTION_FAILED',
            message: res.error ?? 'Rövanş isteği işlenemedi.',
          });
        }
        return;
      }

      if (msg.type === 'room:leave') {
        detachSocketFromRoom(ws, { leaving: true });
      }
    });

    ws.on('close', () => {
      aliveSockets.delete(ws);
      const meta = clientsBySocket.get(ws);
      if (meta?.playerToken) {
        if (socketByToken.get(meta.playerToken) === ws) {
          roomManager.cancelMatchmaking(meta.playerToken);
          socketByToken.delete(meta.playerToken);
        }
      }
      detachSocketFromRoom(ws);
      clientsBySocket.delete(ws);
    });
  });

  // Sweep active clocks once per second
  setInterval(() => {
    const expiredRooms = roomManager.sweepExpiredClocks(Date.now());
    for (const room of expiredRooms) {
      broadcastRoom(room.roomCode, { type: 'room:state', room });
    }
  }, 1000);

  // WebSocket ping/pong heartbeat every 25s to keep proxy connections healthy
  setInterval(() => {
    for (const client of wss.clients) {
      if (!aliveSockets.has(client)) {
        client.terminate();
        continue;
      }
      aliveSockets.delete(client);
      client.ping();
    }
  }, 25_000);

  // Prune stale abandoned rooms every 5 minutes
  setInterval(() => {
    roomManager.pruneStaleRooms(Date.now());
    for (const [roomCode, members] of socketsByRoom.entries()) {
      if (members.size === 0 && !roomManager.getRoomState(roomCode)) {
        socketsByRoom.delete(roomCode);
      }
    }
  }, 5 * 60 * 1000);

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true });
  });

  app.get('/api/download-project', (_req, res) => {
    try {
      const files = collectProjectFiles(__dirname);
      const zipBuffer = buildZipArchive(files);
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="sahmat-proje.zip"');
      res.setHeader('Content-Length', String(zipBuffer.length));
      res.setHeader('Cache-Control', 'no-store');
      res.send(zipBuffer);
    } catch {
      res.status(500).json({ error: 'Arşiv oluşturulamadı.' });
    }
  });

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true' },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`ŞAHMAT server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start ŞAHMAT server:', err);
  process.exit(1);
});
